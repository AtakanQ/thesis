exampleRoadLC1;

% Add radius R = 500
deltaY = 3.7;
R = 500;
n = 5;
Drho = (1/R-1/(R-deltaY))/(4*n+8);
thetaAll = Sall/R;
thetaVecAll = unique([0:.01:thetaAll thetaAll]);
plot(sin(thetaVecAll)*R,R*(1-cos(thetaVecAll)) );
hold all;

% Lane change and arc
CircleDataNew = [];
LineDataNew = [];
PS = [0;0];
thetaS = 0;
Srun = 0;
rhoAdd = 0;
for jj = 1:size(LineData,2)+size(CircleData,2)
   lineIndex = find(LineData(end,:) == jj);
   circleIndex = find(CircleData(end,:) == jj);
   if ~isempty(lineIndex)
       Rnew = R;
       SL = LineData(5,lineIndex);
       Srun = Srun+SL;
       if Srun >= 200 && Srun <= 200+SLC
%           Rnew = 1/(1/Rnew-rhoAdd);
          rhoAdd = rhoAdd + Drho;
       elseif Srun > 200+SLC
          Rnew = R-deltaY;
       end
       % Compute arc data
       CX = PS(1) + Rnew*(-sin(thetaS));
       CY = PS(2) + Rnew*cos(thetaS);
       thetaF = SL/Rnew + thetaS;
       CircleDataNew = [CircleDataNew [CX; CY; Rnew; thetaS; thetaF; jj] ];
       thetaS = thetaF;
       PS = [CX+Rnew*sin(thetaF); CY-Rnew*cos(thetaF)];
   else
       Rnew = 1/(1/R+1/CircleData(3,circleIndex));
       SC = CircleData(6,circleIndex);
       Srun = Srun+SC;
       if Srun >= 200 && Srun <= 200+SLC
%           Rnew = 1/(1/Rnew-rhoAdd);
          rhoAdd = rhoAdd + Drho;
       elseif Srun > 200+SLC
          Rnew = R-deltaY;
       end
       % Compute arc data
       CX = PS(1) + Rnew*(-sin(thetaS));
       CY = PS(2) + Rnew*(cos(thetaS));
       thetaF = SC/Rnew + thetaS;
       CircleDataNew = [CircleDataNew [CX; CY; Rnew; thetaS; thetaF; jj] ];
       thetaS = thetaF;
       PS = [CX+Rnew*sin(thetaF); CY-Rnew*cos(thetaF)];       
   end
end

[arcVec,xVec,yVec] = plotBiElementaryAcrSpline(CircleDataNew,LineDataNew);
plot(xVec,yVec);
