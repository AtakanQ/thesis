clc
v = 20;
dx0 = v;
y0 = 0;
dy0 = 0;
dpsi0 = 0;
kappaf = 0;
a = 1.421;
b = 1.029;
m = 1480;
g = 9.81;
Izz = 1950;
cf = -1.5E5;
cr = -1.5E5;

arclength = 40;
sigma = 0.005/20;
lambda = 0;
qStart = 0;

D = -1.688E4/1.5*2.5;
C = 1.65;
B = 3.22;
E = -0.5;

l_S = 10;

% Controller Parameters
taui = .2;

Kp1 = 0.1;
Kd1 = 0.04;
Kp2 = 0.3;
% Test controller for Ls = 12
Kp1 = .1;
Kd1 = .05;
Kp2 = .3;
Kd2 = 0;
% Test controller for Ls = 2 and steering 0.01
l_S = 2;
Kp1 = .3;
Kd1 = 0.0;
Kp2 = .3;
Kd2 = .0;
% Test controller for Ls = 4 and steering 0.05 and dyL
l_S = 4;
Kp1 = .01;
Kd1 = 0.01;
Kp2 = .005;
Kd2 = .01;
% Test controller for Ls = 4 and steering 0.05 and ddeltaPsi
l_S = 4;
Kp1 = .7;
Kd1 = 0.1;
Kp2 = .02;
Kd2 = .01;
