/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF_2013a_sfun.h"
#include "c2_laneKeepingArcSplinesFF_2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF_2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c2_debug_family_names[55] = { "a", "b", "CXvec", "CYvec",
  "Rvec", "thetaSvec", "thetaRvec", "lineLength", "Svec", "Evec", "psi1", "j",
  "theta1", "thetaRnew", "thetaSnew", "distVec1", "n1", "intVec1", "distNew1",
  "v", "n", "dir1", "f", "lineIndex", "circleIndex", "alpha", "theta", "distVec",
  "intVec", "distNew", "dir", "nargin", "nargout", "CircleData", "LineData",
  "X1", "Y1", "Psi", "dPsi", "delta", "vel", "l_S", "jMin", "dist", "dist1",
  "deltaPsi", "deltadPsi", "rho", "rho1", "PX", "PY", "r", "Srem", "rho1new",
  "segNum" };

/* Function Declarations */
static void initialize_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void initialize_params_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void enable_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void disable_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void c2_update_debugger_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void set_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_st);
static void finalize_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void sf_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void c2_chartstep_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void initSimStructsc2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void registerMessagesc2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber);
static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData);
static real_T c2_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_segNum, const char_T *c2_identifier);
static real_T c2_b_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static void c2_c_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[2]);
static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, real_T
  c2_inData_data[52], int32_T c2_inData_sizes[2]);
static void c2_d_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y_data[52],
   int32_T c2_y_sizes[2]);
static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, real_T c2_outData_data[52],
  int32_T c2_outData_sizes[2]);
static const mxArray *c2_f_sf_marshallOut(void *chartInstanceVoid, real_T
  c2_inData_data[13], int32_T c2_inData_sizes[2]);
static void c2_e_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y_data[13],
   int32_T c2_y_sizes[2]);
static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, real_T c2_outData_data[13],
  int32_T c2_outData_sizes[2]);
static const mxArray *c2_g_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static void c2_f_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[26]);
static void c2_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_h_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static void c2_g_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[52]);
static void c2_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static void c2_info_helper(c2_ResolvedFunctionInfo c2_info[80]);
static void c2_b_info_helper(c2_ResolvedFunctionInfo c2_info[80]);
static real_T c2_sign(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x);
static real_T c2_atan2(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance, real_T c2_y, real_T c2_x);
static void c2_eml_scalar_eg(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance);
static real_T c2_mod(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                     *chartInstance, real_T c2_x, real_T c2_y);
static void c2_b_eml_scalar_eg(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *
  chartInstance);
static real_T c2_sqrt(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x);
static void c2_eml_error(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance);
static real_T c2_abs(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                     *chartInstance, real_T c2_x);
static real_T c2_norm(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x[2]);
static real_T c2_mpower(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance, real_T c2_a);
static const mxArray *c2_i_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static int32_T c2_h_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static uint8_T c2_i_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_b_is_active_c2_laneKeepingArcSplinesFF_2013a, const char_T
   *c2_identifier);
static uint8_T c2_j_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_b_sign(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T *c2_x);
static void c2_b_sqrt(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T *c2_x);
static void init_dsm_address_info
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c2_is_active_c2_laneKeepingArcSplinesFF_2013a = 0U;
}

static void initialize_params_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

static void enable_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c2_update_debugger_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  const mxArray *c2_st;
  const mxArray *c2_y = NULL;
  real_T c2_hoistedGlobal;
  real_T c2_u;
  const mxArray *c2_b_y = NULL;
  real_T c2_b_hoistedGlobal;
  real_T c2_b_u;
  const mxArray *c2_c_y = NULL;
  real_T c2_c_hoistedGlobal;
  real_T c2_c_u;
  const mxArray *c2_d_y = NULL;
  real_T c2_d_hoistedGlobal;
  real_T c2_d_u;
  const mxArray *c2_e_y = NULL;
  real_T c2_e_hoistedGlobal;
  real_T c2_e_u;
  const mxArray *c2_f_y = NULL;
  real_T c2_f_hoistedGlobal;
  real_T c2_f_u;
  const mxArray *c2_g_y = NULL;
  real_T c2_g_hoistedGlobal;
  real_T c2_g_u;
  const mxArray *c2_h_y = NULL;
  real_T c2_h_hoistedGlobal;
  real_T c2_h_u;
  const mxArray *c2_i_y = NULL;
  real_T c2_i_hoistedGlobal;
  real_T c2_i_u;
  const mxArray *c2_j_y = NULL;
  real_T c2_j_hoistedGlobal;
  real_T c2_j_u;
  const mxArray *c2_k_y = NULL;
  real_T c2_k_hoistedGlobal;
  real_T c2_k_u;
  const mxArray *c2_l_y = NULL;
  real_T c2_l_hoistedGlobal;
  real_T c2_l_u;
  const mxArray *c2_m_y = NULL;
  uint8_T c2_m_hoistedGlobal;
  uint8_T c2_m_u;
  const mxArray *c2_n_y = NULL;
  real_T *c2_PX;
  real_T *c2_PY;
  real_T *c2_Srem;
  real_T *c2_deltaPsi;
  real_T *c2_deltadPsi;
  real_T *c2_dist;
  real_T *c2_dist1;
  real_T *c2_r;
  real_T *c2_rho;
  real_T *c2_rho1;
  real_T *c2_rho1new;
  real_T *c2_segNum;
  c2_segNum = (real_T *)ssGetOutputPortSignal(chartInstance->S, 12);
  c2_rho1new = (real_T *)ssGetOutputPortSignal(chartInstance->S, 11);
  c2_Srem = (real_T *)ssGetOutputPortSignal(chartInstance->S, 10);
  c2_r = (real_T *)ssGetOutputPortSignal(chartInstance->S, 9);
  c2_PY = (real_T *)ssGetOutputPortSignal(chartInstance->S, 8);
  c2_PX = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c2_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c2_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c2_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c2_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c2_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c2_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c2_st = NULL;
  c2_st = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellarray(13), FALSE);
  c2_hoistedGlobal = *c2_PX;
  c2_u = c2_hoistedGlobal;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 0, c2_b_y);
  c2_b_hoistedGlobal = *c2_PY;
  c2_b_u = c2_b_hoistedGlobal;
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_b_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 1, c2_c_y);
  c2_c_hoistedGlobal = *c2_Srem;
  c2_c_u = c2_c_hoistedGlobal;
  c2_d_y = NULL;
  sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_c_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 2, c2_d_y);
  c2_d_hoistedGlobal = *c2_deltaPsi;
  c2_d_u = c2_d_hoistedGlobal;
  c2_e_y = NULL;
  sf_mex_assign(&c2_e_y, sf_mex_create("y", &c2_d_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 3, c2_e_y);
  c2_e_hoistedGlobal = *c2_deltadPsi;
  c2_e_u = c2_e_hoistedGlobal;
  c2_f_y = NULL;
  sf_mex_assign(&c2_f_y, sf_mex_create("y", &c2_e_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 4, c2_f_y);
  c2_f_hoistedGlobal = *c2_dist;
  c2_f_u = c2_f_hoistedGlobal;
  c2_g_y = NULL;
  sf_mex_assign(&c2_g_y, sf_mex_create("y", &c2_f_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 5, c2_g_y);
  c2_g_hoistedGlobal = *c2_dist1;
  c2_g_u = c2_g_hoistedGlobal;
  c2_h_y = NULL;
  sf_mex_assign(&c2_h_y, sf_mex_create("y", &c2_g_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 6, c2_h_y);
  c2_h_hoistedGlobal = *c2_r;
  c2_h_u = c2_h_hoistedGlobal;
  c2_i_y = NULL;
  sf_mex_assign(&c2_i_y, sf_mex_create("y", &c2_h_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 7, c2_i_y);
  c2_i_hoistedGlobal = *c2_rho;
  c2_i_u = c2_i_hoistedGlobal;
  c2_j_y = NULL;
  sf_mex_assign(&c2_j_y, sf_mex_create("y", &c2_i_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 8, c2_j_y);
  c2_j_hoistedGlobal = *c2_rho1;
  c2_j_u = c2_j_hoistedGlobal;
  c2_k_y = NULL;
  sf_mex_assign(&c2_k_y, sf_mex_create("y", &c2_j_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 9, c2_k_y);
  c2_k_hoistedGlobal = *c2_rho1new;
  c2_k_u = c2_k_hoistedGlobal;
  c2_l_y = NULL;
  sf_mex_assign(&c2_l_y, sf_mex_create("y", &c2_k_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 10, c2_l_y);
  c2_l_hoistedGlobal = *c2_segNum;
  c2_l_u = c2_l_hoistedGlobal;
  c2_m_y = NULL;
  sf_mex_assign(&c2_m_y, sf_mex_create("y", &c2_l_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 11, c2_m_y);
  c2_m_hoistedGlobal =
    chartInstance->c2_is_active_c2_laneKeepingArcSplinesFF_2013a;
  c2_m_u = c2_m_hoistedGlobal;
  c2_n_y = NULL;
  sf_mex_assign(&c2_n_y, sf_mex_create("y", &c2_m_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c2_y, 12, c2_n_y);
  sf_mex_assign(&c2_st, c2_y, FALSE);
  return c2_st;
}

static void set_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_st)
{
  const mxArray *c2_u;
  real_T *c2_PX;
  real_T *c2_PY;
  real_T *c2_Srem;
  real_T *c2_deltaPsi;
  real_T *c2_deltadPsi;
  real_T *c2_dist;
  real_T *c2_dist1;
  real_T *c2_r;
  real_T *c2_rho;
  real_T *c2_rho1;
  real_T *c2_rho1new;
  real_T *c2_segNum;
  c2_segNum = (real_T *)ssGetOutputPortSignal(chartInstance->S, 12);
  c2_rho1new = (real_T *)ssGetOutputPortSignal(chartInstance->S, 11);
  c2_Srem = (real_T *)ssGetOutputPortSignal(chartInstance->S, 10);
  c2_r = (real_T *)ssGetOutputPortSignal(chartInstance->S, 9);
  c2_PY = (real_T *)ssGetOutputPortSignal(chartInstance->S, 8);
  c2_PX = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c2_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c2_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c2_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c2_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c2_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c2_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c2_doneDoubleBufferReInit = TRUE;
  c2_u = sf_mex_dup(c2_st);
  *c2_PX = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 0)),
    "PX");
  *c2_PY = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 1)),
    "PY");
  *c2_Srem = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u,
    2)), "Srem");
  *c2_deltaPsi = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c2_u, 3)), "deltaPsi");
  *c2_deltadPsi = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c2_u, 4)), "deltadPsi");
  *c2_dist = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u,
    5)), "dist");
  *c2_dist1 = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u,
    6)), "dist1");
  *c2_r = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 7)),
    "r");
  *c2_rho = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 8)),
    "rho");
  *c2_rho1 = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u,
    9)), "rho1");
  *c2_rho1new = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c2_u, 10)), "rho1new");
  *c2_segNum = c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u,
    11)), "segNum");
  chartInstance->c2_is_active_c2_laneKeepingArcSplinesFF_2013a =
    c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 12)),
    "is_active_c2_laneKeepingArcSplinesFF_2013a");
  sf_mex_destroy(&c2_u);
  c2_update_debugger_state_c2_laneKeepingArcSplinesFF_2013a(chartInstance);
  sf_mex_destroy(&c2_st);
}

static void finalize_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

static void sf_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  int32_T c2_i0;
  int32_T c2_i1;
  real_T *c2_dist;
  real_T *c2_X1;
  real_T *c2_Y1;
  real_T *c2_Psi;
  real_T *c2_dPsi;
  real_T *c2_delta;
  real_T *c2_vel;
  real_T *c2_l_S;
  real_T *c2_dist1;
  real_T *c2_deltaPsi;
  real_T *c2_deltadPsi;
  real_T *c2_rho;
  real_T *c2_rho1;
  real_T *c2_PX;
  real_T *c2_PY;
  real_T *c2_r;
  real_T *c2_Srem;
  real_T *c2_rho1new;
  real_T *c2_segNum;
  real_T *c2_jMin;
  real_T (*c2_LineData)[65];
  real_T (*c2_CircleData)[312];
  c2_jMin = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c2_segNum = (real_T *)ssGetOutputPortSignal(chartInstance->S, 12);
  c2_rho1new = (real_T *)ssGetOutputPortSignal(chartInstance->S, 11);
  c2_Srem = (real_T *)ssGetOutputPortSignal(chartInstance->S, 10);
  c2_r = (real_T *)ssGetOutputPortSignal(chartInstance->S, 9);
  c2_PY = (real_T *)ssGetOutputPortSignal(chartInstance->S, 8);
  c2_PX = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c2_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c2_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c2_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c2_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c2_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c2_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c2_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c2_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c2_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c2_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c2_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c2_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c2_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
  c2_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c2_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  for (c2_i0 = 0; c2_i0 < 312; c2_i0++) {
    _SFD_DATA_RANGE_CHECK((*c2_CircleData)[c2_i0], 0U);
  }

  _SFD_DATA_RANGE_CHECK(*c2_dist, 1U);
  for (c2_i1 = 0; c2_i1 < 65; c2_i1++) {
    _SFD_DATA_RANGE_CHECK((*c2_LineData)[c2_i1], 2U);
  }

  _SFD_DATA_RANGE_CHECK(*c2_X1, 3U);
  _SFD_DATA_RANGE_CHECK(*c2_Y1, 4U);
  _SFD_DATA_RANGE_CHECK(*c2_Psi, 5U);
  _SFD_DATA_RANGE_CHECK(*c2_dPsi, 6U);
  _SFD_DATA_RANGE_CHECK(*c2_delta, 7U);
  _SFD_DATA_RANGE_CHECK(*c2_vel, 8U);
  _SFD_DATA_RANGE_CHECK(*c2_l_S, 9U);
  _SFD_DATA_RANGE_CHECK(*c2_dist1, 10U);
  _SFD_DATA_RANGE_CHECK(*c2_deltaPsi, 11U);
  _SFD_DATA_RANGE_CHECK(*c2_deltadPsi, 12U);
  _SFD_DATA_RANGE_CHECK(*c2_rho, 13U);
  _SFD_DATA_RANGE_CHECK(*c2_rho1, 14U);
  _SFD_DATA_RANGE_CHECK(*c2_PX, 15U);
  _SFD_DATA_RANGE_CHECK(*c2_PY, 16U);
  _SFD_DATA_RANGE_CHECK(*c2_r, 17U);
  _SFD_DATA_RANGE_CHECK(*c2_Srem, 18U);
  _SFD_DATA_RANGE_CHECK(*c2_rho1new, 19U);
  _SFD_DATA_RANGE_CHECK(*c2_segNum, 20U);
  _SFD_DATA_RANGE_CHECK(*c2_jMin, 21U);
  chartInstance->c2_sfEvent = CALL_EVENT;
  c2_chartstep_c2_laneKeepingArcSplinesFF_2013a(chartInstance);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY
    (_laneKeepingArcSplinesFF_2013aMachineNumber_, chartInstance->chartNumber,
     chartInstance->instanceNumber);
}

static void c2_chartstep_c2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
  real_T c2_hoistedGlobal;
  real_T c2_b_hoistedGlobal;
  real_T c2_c_hoistedGlobal;
  real_T c2_d_hoistedGlobal;
  real_T c2_e_hoistedGlobal;
  real_T c2_f_hoistedGlobal;
  real_T c2_g_hoistedGlobal;
  real_T c2_h_hoistedGlobal;
  int32_T c2_i2;
  real_T c2_CircleData[312];
  int32_T c2_i3;
  real_T c2_LineData[65];
  real_T c2_X1;
  real_T c2_Y1;
  real_T c2_Psi;
  real_T c2_dPsi;
  real_T c2_delta;
  real_T c2_vel;
  real_T c2_l_S;
  real_T c2_jMin;
  uint32_T c2_debug_family_var_map[55];
  real_T c2_a;
  real_T c2_b;
  real_T c2_CXvec[52];
  real_T c2_CYvec[52];
  real_T c2_Rvec[52];
  real_T c2_thetaSvec[52];
  real_T c2_thetaRvec[52];
  real_T c2_lineLength;
  real_T c2_Svec[26];
  real_T c2_Evec[26];
  real_T c2_psi1;
  real_T c2_j;
  real_T c2_theta1;
  real_T c2_thetaRnew;
  real_T c2_thetaSnew;
  real_T c2_distVec1[2];
  real_T c2_n1[2];
  real_T c2_intVec1[2];
  real_T c2_distNew1;
  real_T c2_v[2];
  real_T c2_n[2];
  real_T c2_dir1[2];
  real_T c2_f;
  int32_T c2_lineIndex_sizes[2];
  real_T c2_lineIndex_data[13];
  int32_T c2_circleIndex_sizes[2];
  real_T c2_circleIndex_data[52];
  real_T c2_alpha;
  real_T c2_theta;
  real_T c2_distVec[2];
  real_T c2_intVec[2];
  real_T c2_distNew;
  real_T c2_dir[2];
  real_T c2_nargin = 10.0;
  real_T c2_nargout = 12.0;
  real_T c2_dist;
  real_T c2_dist1;
  real_T c2_deltaPsi;
  real_T c2_deltadPsi;
  real_T c2_rho;
  real_T c2_rho1;
  real_T c2_PX;
  real_T c2_PY;
  real_T c2_r;
  real_T c2_Srem;
  real_T c2_rho1new;
  real_T c2_segNum;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_b_j;
  real_T c2_b_a;
  real_T c2_b_b;
  real_T c2_y;
  real_T c2_d0;
  real_T c2_c_a;
  real_T c2_c_b;
  real_T c2_b_y;
  int32_T c2_i22;
  real_T c2_d_a[2];
  int32_T c2_i23;
  real_T c2_A[2];
  real_T c2_c_y;
  int32_T c2_k;
  int32_T c2_b_k;
  int32_T c2_i24;
  real_T c2_B;
  real_T c2_d_y;
  real_T c2_e_y;
  int32_T c2_i25;
  real_T c2_d_b;
  int32_T c2_i26;
  real_T c2_b_B;
  real_T c2_f_y;
  real_T c2_g_y;
  int32_T c2_i27;
  real_T c2_e_a;
  int32_T c2_i28;
  int32_T c2_i29;
  real_T c2_b_CXvec[2];
  int32_T c2_i30;
  real_T c2_b_X1[2];
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_c_k;
  int32_T c2_d_k;
  real_T c2_c_B;
  real_T c2_h_y;
  real_T c2_i_y;
  real_T c2_f_a;
  real_T c2_e_b;
  real_T c2_j_y;
  real_T c2_g_a;
  real_T c2_f_b;
  real_T c2_k_y;
  real_T c2_h_a;
  real_T c2_g_b;
  real_T c2_l_y;
  real_T c2_i_a;
  real_T c2_h_b;
  real_T c2_m_y;
  int32_T c2_c_j;
  int32_T c2_d_j;
  int32_T c2_e_j;
  int32_T c2_i33;
  int32_T c2_i34;
  real_T c2_b_v[2];
  real_T c2_d_B;
  real_T c2_n_y;
  real_T c2_o_y;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  real_T c2_p_y;
  int32_T c2_e_k;
  int32_T c2_f_k;
  real_T c2_b_A;
  int32_T c2_i38;
  real_T c2_c_v[2];
  real_T c2_e_B;
  real_T c2_x;
  real_T c2_q_y;
  real_T c2_b_x;
  real_T c2_r_y;
  int32_T c2_i39;
  int32_T c2_i40;
  int32_T c2_g_k;
  int32_T c2_h_k;
  real_T c2_j_a;
  real_T c2_i_b;
  real_T c2_b_segNum;
  int32_T c2_i41;
  int32_T c2_i42;
  boolean_T c2_c_x[13];
  int32_T c2_idx;
  int32_T c2_i43;
  int32_T c2_ii_sizes[2];
  int32_T c2_ii;
  int32_T c2_b_ii;
  int32_T c2_k_a;
  int32_T c2_ii_data[13];
  boolean_T c2_b0;
  boolean_T c2_b1;
  boolean_T c2_b2;
  int32_T c2_i44;
  int32_T c2_tmp_sizes;
  int32_T c2_loop_ub;
  int32_T c2_i45;
  int32_T c2_tmp_data[13];
  int32_T c2_iv0[2];
  int32_T c2_b_ii_sizes[2];
  int32_T c2_b_loop_ub;
  int32_T c2_i46;
  int32_T c2_c_loop_ub;
  int32_T c2_i47;
  int32_T c2_b_ii_data[13];
  int32_T c2_d_loop_ub;
  int32_T c2_i48;
  int32_T c2_lineIndex;
  int32_T c2_b_lineIndex;
  int32_T c2_e_loop_ub;
  int32_T c2_i49;
  boolean_T c2_b3;
  real_T c2_c_segNum;
  int32_T c2_i50;
  int32_T c2_i51;
  boolean_T c2_d_x[52];
  int32_T c2_b_idx;
  int32_T c2_i52;
  int32_T c2_c_ii_sizes[2];
  int32_T c2_c_ii;
  int32_T c2_d_ii;
  int32_T c2_l_a;
  int32_T c2_c_ii_data[52];
  boolean_T c2_b4;
  boolean_T c2_b5;
  boolean_T c2_b6;
  int32_T c2_i53;
  int32_T c2_b_tmp_sizes;
  int32_T c2_f_loop_ub;
  int32_T c2_i54;
  int32_T c2_b_tmp_data[52];
  int32_T c2_iv1[2];
  int32_T c2_d_ii_sizes[2];
  int32_T c2_g_loop_ub;
  int32_T c2_i55;
  int32_T c2_h_loop_ub;
  int32_T c2_i56;
  int32_T c2_d_ii_data[52];
  int32_T c2_i_loop_ub;
  int32_T c2_i57;
  int32_T c2_circleIndex;
  int32_T c2_b_circleIndex;
  int32_T c2_j_loop_ub;
  int32_T c2_i58;
  boolean_T c2_b7;
  real_T c2_f_B;
  real_T c2_s_y;
  real_T c2_t_y;
  real_T c2_e_x;
  real_T c2_f_x;
  real_T c2_m_a;
  real_T c2_j_b;
  real_T c2_u_y;
  real_T c2_g_x;
  real_T c2_h_x;
  real_T c2_n_a;
  real_T c2_k_b;
  real_T c2_v_y;
  real_T c2_i_x;
  real_T c2_j_x;
  real_T c2_o_a;
  real_T c2_l_b;
  real_T c2_w_y;
  real_T c2_k_x;
  real_T c2_l_x;
  real_T c2_p_a;
  real_T c2_m_b;
  real_T c2_x_y;
  real_T c2_g_B;
  real_T c2_y_y;
  real_T c2_ab_y;
  real_T c2_c_A;
  real_T c2_h_B;
  real_T c2_m_x;
  real_T c2_bb_y;
  real_T c2_n_x;
  real_T c2_cb_y;
  real_T c2_o_x;
  real_T c2_p_x;
  real_T c2_q_x;
  real_T c2_r_x;
  real_T c2_q_a;
  real_T c2_n_b;
  real_T c2_db_y;
  real_T c2_s_x;
  real_T c2_t_x;
  real_T c2_u_x;
  real_T c2_v_x;
  real_T c2_r_a;
  real_T c2_o_b;
  real_T c2_eb_y;
  real_T c2_i_B;
  real_T c2_fb_y;
  real_T c2_gb_y;
  real_T c2_d_A;
  real_T c2_j_B;
  real_T c2_w_x;
  real_T c2_hb_y;
  real_T c2_x_x;
  real_T c2_ib_y;
  real_T c2_y_x;
  real_T c2_ab_x;
  real_T c2_bb_x;
  real_T c2_cb_x;
  real_T c2_s_a;
  real_T c2_p_b;
  real_T c2_jb_y;
  real_T c2_db_x;
  real_T c2_eb_x;
  real_T c2_fb_x;
  real_T c2_gb_x;
  real_T c2_t_a;
  real_T c2_q_b;
  real_T c2_kb_y;
  real_T c2_k_B;
  real_T c2_lb_y;
  real_T c2_mb_y;
  real_T c2_e_A;
  real_T c2_l_B;
  real_T c2_hb_x;
  real_T c2_nb_y;
  real_T c2_ib_x;
  real_T c2_ob_y;
  real_T c2_jb_x;
  real_T c2_kb_x;
  real_T c2_lb_x;
  real_T c2_mb_x;
  real_T c2_u_a;
  real_T c2_r_b;
  real_T c2_pb_y;
  real_T c2_nb_x;
  real_T c2_ob_x;
  real_T c2_pb_x;
  real_T c2_qb_x;
  real_T c2_v_a;
  real_T c2_s_b;
  real_T c2_qb_y;
  real_T c2_rb_x;
  real_T c2_sb_x;
  real_T c2_w_a;
  real_T c2_t_b;
  real_T c2_rb_y;
  real_T c2_tb_x;
  real_T c2_ub_x;
  real_T c2_x_a;
  real_T c2_u_b;
  real_T c2_sb_y;
  real_T c2_m_B;
  real_T c2_tb_y;
  real_T c2_ub_y;
  real_T c2_f_A;
  real_T c2_n_B;
  real_T c2_vb_x;
  real_T c2_vb_y;
  real_T c2_wb_x;
  real_T c2_wb_y;
  real_T c2_xb_x;
  real_T c2_yb_x;
  real_T c2_ac_x;
  real_T c2_bc_x;
  real_T c2_y_a;
  real_T c2_v_b;
  real_T c2_xb_y;
  real_T c2_cc_x;
  real_T c2_dc_x;
  real_T c2_ec_x;
  real_T c2_fc_x;
  real_T c2_ab_a;
  real_T c2_w_b;
  real_T c2_yb_y;
  real_T c2_o_B;
  real_T c2_ac_y;
  real_T c2_bc_y;
  real_T c2_g_A;
  real_T c2_p_B;
  real_T c2_gc_x;
  real_T c2_cc_y;
  real_T c2_hc_x;
  real_T c2_dc_y;
  real_T c2_ic_x;
  real_T c2_jc_x;
  real_T c2_kc_x;
  real_T c2_lc_x;
  real_T c2_bb_a;
  real_T c2_x_b;
  real_T c2_ec_y;
  real_T c2_mc_x;
  real_T c2_nc_x;
  real_T c2_oc_x;
  real_T c2_pc_x;
  real_T c2_cb_a;
  real_T c2_y_b;
  real_T c2_fc_y;
  int32_T c2_f_j;
  real_T c2_db_a;
  real_T c2_ab_b;
  real_T c2_gc_y;
  real_T c2_d1;
  real_T c2_eb_a;
  real_T c2_bb_b;
  real_T c2_hc_y;
  int32_T c2_i59;
  int32_T c2_i60;
  real_T c2_ic_y;
  int32_T c2_i_k;
  int32_T c2_j_k;
  int32_T c2_i61;
  real_T c2_q_B;
  real_T c2_jc_y;
  real_T c2_kc_y;
  int32_T c2_i62;
  real_T c2_cb_b;
  int32_T c2_i63;
  real_T c2_r_B;
  real_T c2_lc_y;
  real_T c2_mc_y;
  int32_T c2_i64;
  real_T c2_fb_a;
  int32_T c2_i65;
  int32_T c2_i66;
  real_T c2_c_CXvec[2];
  int32_T c2_i67;
  real_T c2_b_PX[2];
  int32_T c2_i68;
  int32_T c2_i69;
  int32_T c2_k_k;
  int32_T c2_l_k;
  real_T c2_s_B;
  real_T c2_nc_y;
  real_T c2_oc_y;
  real_T c2_t_B;
  real_T c2_pc_y;
  real_T c2_qc_y;
  real_T c2_rc_y;
  real_T c2_gb_a;
  real_T c2_db_b;
  real_T c2_sc_y;
  int32_T c2_g_j;
  int32_T c2_h_j;
  int32_T c2_i_j;
  int32_T c2_i70;
  int32_T c2_i71;
  real_T c2_d_v[2];
  real_T c2_u_B;
  real_T c2_tc_y;
  real_T c2_uc_y;
  int32_T c2_i72;
  int32_T c2_i73;
  int32_T c2_i74;
  real_T c2_vc_y;
  int32_T c2_m_k;
  int32_T c2_n_k;
  real_T c2_h_A;
  int32_T c2_i75;
  real_T c2_e_v[2];
  real_T c2_v_B;
  real_T c2_qc_x;
  real_T c2_wc_y;
  real_T c2_rc_x;
  real_T c2_xc_y;
  int32_T c2_i76;
  int32_T c2_i77;
  int32_T c2_o_k;
  int32_T c2_p_k;
  real_T c2_eb_b;
  real_T *c2_c_X1;
  real_T *c2_b_Y1;
  real_T *c2_b_Psi;
  real_T *c2_b_dPsi;
  real_T *c2_b_delta;
  real_T *c2_b_vel;
  real_T *c2_b_l_S;
  real_T *c2_b_jMin;
  real_T *c2_b_dist;
  real_T *c2_b_dist1;
  real_T *c2_b_deltaPsi;
  real_T *c2_b_deltadPsi;
  real_T *c2_b_rho;
  real_T *c2_b_rho1;
  real_T *c2_c_PX;
  real_T *c2_b_PY;
  real_T *c2_b_r;
  real_T *c2_b_Srem;
  real_T *c2_b_rho1new;
  real_T *c2_d_segNum;
  real_T (*c2_b_LineData)[65];
  real_T (*c2_b_CircleData)[312];
  boolean_T guard1 = FALSE;
  boolean_T guard2 = FALSE;
  boolean_T guard3 = FALSE;
  boolean_T guard4 = FALSE;
  boolean_T guard5 = FALSE;
  boolean_T guard6 = FALSE;
  boolean_T guard7 = FALSE;
  boolean_T guard8 = FALSE;
  boolean_T guard9 = FALSE;
  boolean_T guard10 = FALSE;
  boolean_T guard11 = FALSE;
  boolean_T guard12 = FALSE;
  boolean_T guard13 = FALSE;
  boolean_T guard14 = FALSE;
  boolean_T guard15 = FALSE;
  boolean_T guard16 = FALSE;
  boolean_T guard17 = FALSE;
  boolean_T exitg1;
  boolean_T exitg2;
  boolean_T guard112 = FALSE;
  boolean_T guard21 = FALSE;
  c2_b_jMin = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c2_d_segNum = (real_T *)ssGetOutputPortSignal(chartInstance->S, 12);
  c2_b_rho1new = (real_T *)ssGetOutputPortSignal(chartInstance->S, 11);
  c2_b_Srem = (real_T *)ssGetOutputPortSignal(chartInstance->S, 10);
  c2_b_r = (real_T *)ssGetOutputPortSignal(chartInstance->S, 9);
  c2_b_PY = (real_T *)ssGetOutputPortSignal(chartInstance->S, 8);
  c2_c_PX = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
  c2_b_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c2_b_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c2_b_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c2_b_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c2_b_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c2_b_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c2_b_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c2_b_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c2_b_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c2_b_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c2_b_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c2_c_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c2_b_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
  c2_b_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c2_b_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  c2_hoistedGlobal = *c2_c_X1;
  c2_b_hoistedGlobal = *c2_b_Y1;
  c2_c_hoistedGlobal = *c2_b_Psi;
  c2_d_hoistedGlobal = *c2_b_dPsi;
  c2_e_hoistedGlobal = *c2_b_delta;
  c2_f_hoistedGlobal = *c2_b_vel;
  c2_g_hoistedGlobal = *c2_b_l_S;
  c2_h_hoistedGlobal = *c2_b_jMin;
  for (c2_i2 = 0; c2_i2 < 312; c2_i2++) {
    c2_CircleData[c2_i2] = (*c2_b_CircleData)[c2_i2];
  }

  for (c2_i3 = 0; c2_i3 < 65; c2_i3++) {
    c2_LineData[c2_i3] = (*c2_b_LineData)[c2_i3];
  }

  c2_X1 = c2_hoistedGlobal;
  c2_Y1 = c2_b_hoistedGlobal;
  c2_Psi = c2_c_hoistedGlobal;
  c2_dPsi = c2_d_hoistedGlobal;
  c2_delta = c2_e_hoistedGlobal;
  c2_vel = c2_f_hoistedGlobal;
  c2_l_S = c2_g_hoistedGlobal;
  c2_jMin = c2_h_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 55U, 55U, c2_debug_family_names,
    c2_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_a, 0U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b, 1U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_CXvec, 2U, c2_h_sf_marshallOut,
    c2_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_CYvec, 3U, c2_h_sf_marshallOut,
    c2_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_Rvec, 4U, c2_h_sf_marshallOut,
    c2_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_thetaSvec, 5U, c2_h_sf_marshallOut,
    c2_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_thetaRvec, 6U, c2_h_sf_marshallOut,
    c2_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_lineLength, 7U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_Svec, 8U, c2_g_sf_marshallOut,
    c2_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_Evec, 9U, c2_g_sf_marshallOut,
    c2_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_psi1, 10U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_j, 11U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_theta1, 12U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_thetaRnew, 13U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_thetaSnew, 14U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_distVec1, 15U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_n1, 16U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_intVec1, 17U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_distNew1, 18U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_v, 19U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_n, 20U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_dir1, 21U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_f, 22U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_DYN_IMPORTABLE(c2_lineIndex_data, (const int32_T *)
    &c2_lineIndex_sizes, NULL, 0, 23, (void *)c2_f_sf_marshallOut, (void *)
    c2_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_DYN_IMPORTABLE(c2_circleIndex_data, (const int32_T *)
    &c2_circleIndex_sizes, NULL, 0, 24, (void *)c2_e_sf_marshallOut, (void *)
    c2_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_alpha, 25U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_theta, 26U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_distVec, 27U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_intVec, 28U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_distNew, 29U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c2_dir, 30U, c2_d_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 31U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 32U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(c2_CircleData, 33U, c2_c_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c2_LineData, 34U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_X1, 35U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_Y1, 36U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_Psi, 37U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_dPsi, 38U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_delta, 39U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_vel, 40U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_l_S, 41U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_jMin, 42U, c2_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_dist, 43U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_dist1, 44U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_deltaPsi, 45U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_deltadPsi, 46U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_rho, 47U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_rho1, 48U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_PX, 49U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_PY, 50U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_r, 51U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_Srem, 52U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_rho1new, 53U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_segNum, 54U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 3);
  c2_a = 1.421;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 4);
  c2_b = 1.029;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 6);
  c2_dist = 1.0E+6;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 7);
  c2_dist1 = 1.0E+6;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 8);
  c2_deltaPsi = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 9);
  c2_deltadPsi = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 10);
  c2_i4 = 0;
  for (c2_i5 = 0; c2_i5 < 52; c2_i5++) {
    c2_CXvec[c2_i5] = c2_CircleData[c2_i4];
    c2_i4 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 11);
  c2_i6 = 0;
  for (c2_i7 = 0; c2_i7 < 52; c2_i7++) {
    c2_CYvec[c2_i7] = c2_CircleData[c2_i6 + 1];
    c2_i6 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 12);
  c2_i8 = 0;
  for (c2_i9 = 0; c2_i9 < 52; c2_i9++) {
    c2_Rvec[c2_i9] = c2_CircleData[c2_i8 + 2];
    c2_i8 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 13);
  c2_i10 = 0;
  for (c2_i11 = 0; c2_i11 < 52; c2_i11++) {
    c2_thetaSvec[c2_i11] = c2_CircleData[c2_i10 + 3];
    c2_i10 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 14);
  c2_i12 = 0;
  for (c2_i13 = 0; c2_i13 < 52; c2_i13++) {
    c2_thetaRvec[c2_i13] = c2_CircleData[c2_i12 + 4];
    c2_i12 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 15);
  c2_rho = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 16);
  c2_rho1 = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 17);
  c2_lineLength = 100.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 18);
  c2_i14 = 0;
  c2_i15 = 0;
  for (c2_i16 = 0; c2_i16 < 13; c2_i16++) {
    for (c2_i17 = 0; c2_i17 < 2; c2_i17++) {
      c2_Svec[c2_i17 + c2_i14] = c2_LineData[c2_i17 + c2_i15];
    }

    c2_i14 += 2;
    c2_i15 += 5;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 19);
  c2_i18 = 0;
  c2_i19 = 0;
  for (c2_i20 = 0; c2_i20 < 13; c2_i20++) {
    for (c2_i21 = 0; c2_i21 < 2; c2_i21++) {
      c2_Evec[c2_i21 + c2_i18] = c2_LineData[(c2_i21 + c2_i19) + 2];
    }

    c2_i18 += 2;
    c2_i19 += 5;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 20);
  c2_segNum = 1.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 21);
  c2_psi1 = c2_Psi;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 22);
  c2_Srem = c2_l_S;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 24);
  c2_j = 1.0;
  c2_b_j = 0;
  while (c2_b_j < 52) {
    c2_j = 1.0 + (real_T)c2_b_j;
    CV_EML_FOR(0, 1, 0, 1);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 27);
    c2_b_a = c2_Rvec[(int32_T)c2_j - 1];
    c2_b_sign(chartInstance, &c2_b_a);
    c2_b_b = c2_X1 - c2_CXvec[(int32_T)c2_j - 1];
    c2_y = c2_b_a * c2_b_b;
    c2_d0 = c2_Rvec[(int32_T)c2_j - 1];
    c2_b_sign(chartInstance, &c2_d0);
    c2_c_a = -c2_d0;
    c2_c_b = c2_Y1 - c2_CYvec[(int32_T)c2_j - 1];
    c2_b_y = c2_c_a * c2_c_b;
    c2_theta1 = c2_mod(chartInstance, c2_atan2(chartInstance, c2_y, c2_b_y),
                       6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 28);
    c2_thetaRnew = c2_mod(chartInstance, c2_thetaRvec[(int32_T)c2_j - 1],
                          6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 29);
    c2_thetaSnew = c2_mod(chartInstance, c2_thetaSvec[(int32_T)c2_j - 1],
                          6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 31);
    guard11 = FALSE;
    guard12 = FALSE;
    guard13 = FALSE;
    guard14 = FALSE;
    guard15 = FALSE;
    guard16 = FALSE;
    guard17 = FALSE;
    if (CV_EML_IF(0, 1, 0, c2_thetaSvec[(int32_T)c2_j - 1] < c2_thetaRvec
                  [(int32_T)c2_j - 1])) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 32);
      if (CV_EML_IF(0, 1, 1, c2_thetaSnew < c2_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 33);
        if (CV_EML_COND(0, 1, 0, c2_theta1 < c2_thetaSnew)) {
          guard13 = TRUE;
        } else if (CV_EML_COND(0, 1, 1, c2_theta1 >= c2_thetaRnew)) {
          guard13 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 0, FALSE);
          CV_EML_IF(0, 1, 2, FALSE);
          guard15 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 37);
        if (CV_EML_COND(0, 1, 2, c2_theta1 < c2_thetaSnew)) {
          if (CV_EML_COND(0, 1, 3, c2_theta1 > c2_thetaRnew)) {
            CV_EML_MCDC(0, 1, 1, TRUE);
            CV_EML_IF(0, 1, 3, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 38);
          } else {
            guard17 = TRUE;
          }
        } else {
          guard17 = TRUE;
        }
      }
    } else {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 42);
      if (CV_EML_IF(0, 1, 4, c2_thetaSnew > c2_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 43);
        if (CV_EML_COND(0, 1, 4, c2_theta1 > c2_thetaSnew)) {
          guard12 = TRUE;
        } else if (CV_EML_COND(0, 1, 5, c2_theta1 <= c2_thetaRnew)) {
          guard12 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 2, FALSE);
          CV_EML_IF(0, 1, 5, FALSE);
          guard14 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 47);
        if (CV_EML_COND(0, 1, 6, c2_theta1 > c2_thetaSnew)) {
          if (CV_EML_COND(0, 1, 7, c2_theta1 < c2_thetaRnew)) {
            CV_EML_MCDC(0, 1, 3, TRUE);
            CV_EML_IF(0, 1, 6, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 48);
          } else {
            guard16 = TRUE;
          }
        } else {
          guard16 = TRUE;
        }
      }
    }

    if (guard17 == TRUE) {
      CV_EML_MCDC(0, 1, 1, FALSE);
      CV_EML_IF(0, 1, 3, FALSE);
      guard15 = TRUE;
    }

    if (guard16 == TRUE) {
      CV_EML_MCDC(0, 1, 3, FALSE);
      CV_EML_IF(0, 1, 6, FALSE);
      guard14 = TRUE;
    }

    if (guard15 == TRUE) {
      guard11 = TRUE;
    }

    if (guard14 == TRUE) {
      guard11 = TRUE;
    }

    if (guard13 == TRUE) {
      CV_EML_MCDC(0, 1, 0, TRUE);
      CV_EML_IF(0, 1, 2, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 34);
    }

    if (guard12 == TRUE) {
      CV_EML_MCDC(0, 1, 2, TRUE);
      CV_EML_IF(0, 1, 5, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 44);
    }

    if (guard11 == TRUE) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 53);
      c2_distVec1[0] = c2_X1 - c2_CXvec[(int32_T)c2_j - 1];
      c2_distVec1[1] = c2_Y1 - c2_CYvec[(int32_T)c2_j - 1];
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 54);
      for (c2_i22 = 0; c2_i22 < 2; c2_i22++) {
        c2_d_a[c2_i22] = c2_distVec1[c2_i22];
      }

      for (c2_i23 = 0; c2_i23 < 2; c2_i23++) {
        c2_A[c2_i23] = c2_distVec1[c2_i23];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_c_y = 0.0;
      for (c2_k = 1; c2_k < 3; c2_k++) {
        c2_b_k = c2_k - 1;
        c2_c_y += c2_d_a[c2_b_k] * c2_A[c2_b_k];
      }

      for (c2_i24 = 0; c2_i24 < 2; c2_i24++) {
        c2_A[c2_i24] = c2_distVec1[c2_i24];
      }

      c2_B = c2_c_y;
      c2_b_sqrt(chartInstance, &c2_B);
      c2_d_y = c2_B;
      c2_e_y = c2_d_y;
      for (c2_i25 = 0; c2_i25 < 2; c2_i25++) {
        c2_A[c2_i25] /= c2_e_y;
      }

      c2_d_b = c2_Rvec[(int32_T)c2_j - 1];
      for (c2_i26 = 0; c2_i26 < 2; c2_i26++) {
        c2_A[c2_i26] *= c2_d_b;
      }

      c2_b_B = c2_abs(chartInstance, c2_Rvec[(int32_T)c2_j - 1]);
      c2_f_y = c2_b_B;
      c2_g_y = c2_f_y;
      for (c2_i27 = 0; c2_i27 < 2; c2_i27++) {
        c2_n1[c2_i27] = c2_A[c2_i27] / c2_g_y;
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 55);
      c2_e_a = c2_Rvec[(int32_T)c2_j - 1];
      for (c2_i28 = 0; c2_i28 < 2; c2_i28++) {
        c2_A[c2_i28] = c2_n1[c2_i28];
      }

      for (c2_i29 = 0; c2_i29 < 2; c2_i29++) {
        c2_A[c2_i29] *= c2_e_a;
      }

      c2_b_CXvec[0] = c2_CXvec[(int32_T)c2_j - 1];
      c2_b_CXvec[1] = c2_CYvec[(int32_T)c2_j - 1];
      for (c2_i30 = 0; c2_i30 < 2; c2_i30++) {
        c2_intVec1[c2_i30] = c2_b_CXvec[c2_i30] + c2_A[c2_i30];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 56);
      c2_b_X1[0] = c2_X1;
      c2_b_X1[1] = c2_Y1;
      for (c2_i31 = 0; c2_i31 < 2; c2_i31++) {
        c2_d_a[c2_i31] = -(c2_b_X1[c2_i31] - c2_intVec1[c2_i31]);
      }

      for (c2_i32 = 0; c2_i32 < 2; c2_i32++) {
        c2_A[c2_i32] = c2_n1[c2_i32];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_distNew1 = 0.0;
      for (c2_c_k = 1; c2_c_k < 3; c2_c_k++) {
        c2_d_k = c2_c_k - 1;
        c2_distNew1 += c2_d_a[c2_d_k] * c2_A[c2_d_k];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 57);
      if (CV_EML_IF(0, 1, 7, c2_abs(chartInstance, c2_distNew1) < c2_abs
                    (chartInstance, c2_dist1))) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 58);
        c2_c_B = c2_Rvec[(int32_T)c2_j - 1];
        c2_h_y = c2_c_B;
        c2_i_y = c2_h_y;
        c2_rho1 = 1.0 / c2_i_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 59);
        c2_dist1 = c2_distNew1;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 60);
        c2_psi1 = c2_theta1;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 61);
        c2_segNum = c2_CircleData[5 + 6 * ((int32_T)c2_j - 1)];
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 62);
        c2_deltaPsi = c2_theta1 - c2_Psi;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 63);
        if (CV_EML_IF(0, 1, 8, c2_thetaSvec[(int32_T)c2_j - 1] < c2_thetaRvec
                      [(int32_T)c2_j - 1])) {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 64);
          if (CV_EML_IF(0, 1, 9, c2_theta1 > c2_thetaRnew)) {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 65);
            c2_f_a = (c2_thetaRnew + 6.2831853071795862) - c2_theta1;
            c2_e_b = c2_Rvec[(int32_T)c2_j - 1];
            c2_j_y = c2_f_a * c2_e_b;
            c2_Srem = c2_abs(chartInstance, c2_j_y);
          } else {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 67);
            c2_g_a = c2_thetaRnew - c2_theta1;
            c2_f_b = c2_Rvec[(int32_T)c2_j - 1];
            c2_k_y = c2_g_a * c2_f_b;
            c2_Srem = c2_abs(chartInstance, c2_k_y);
          }
        } else {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 70);
          if (CV_EML_IF(0, 1, 10, c2_theta1 > c2_thetaRnew)) {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 71);
            c2_h_a = c2_thetaRnew - c2_theta1;
            c2_g_b = c2_Rvec[(int32_T)c2_j - 1];
            c2_l_y = c2_h_a * c2_g_b;
            c2_Srem = c2_abs(chartInstance, c2_l_y);
          } else {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 73);
            c2_i_a = (c2_thetaRnew - c2_theta1) - 6.2831853071795862;
            c2_h_b = c2_Rvec[(int32_T)c2_j - 1];
            c2_m_y = c2_i_a * c2_h_b;
            c2_Srem = c2_abs(chartInstance, c2_m_y);
          }
        }
      }
    }

    c2_b_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 0, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 87);
  c2_j = 1.0;
  c2_c_j = 0;
  while (c2_c_j < 13) {
    c2_j = 1.0 + (real_T)c2_c_j;
    CV_EML_FOR(0, 1, 1, 1);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 88);
    c2_d_j = (int32_T)c2_j - 1;
    c2_e_j = (int32_T)c2_j - 1;
    for (c2_i33 = 0; c2_i33 < 2; c2_i33++) {
      c2_v[c2_i33] = c2_Evec[c2_i33 + (c2_d_j << 1)] - c2_Svec[c2_i33 + (c2_e_j <<
        1)];
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 89);
    c2_A[0] = -c2_v[1];
    c2_A[1] = c2_v[0];
    for (c2_i34 = 0; c2_i34 < 2; c2_i34++) {
      c2_b_v[c2_i34] = c2_v[c2_i34];
    }

    c2_d_B = c2_norm(chartInstance, c2_b_v);
    c2_n_y = c2_d_B;
    c2_o_y = c2_n_y;
    for (c2_i35 = 0; c2_i35 < 2; c2_i35++) {
      c2_n[c2_i35] = c2_A[c2_i35] / c2_o_y;
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 90);
    c2_dir1[0] = c2_X1 - c2_Svec[((int32_T)c2_j - 1) << 1];
    c2_dir1[1] = c2_Y1 - c2_Svec[1 + (((int32_T)c2_j - 1) << 1)];
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 91);
    for (c2_i36 = 0; c2_i36 < 2; c2_i36++) {
      c2_d_a[c2_i36] = c2_v[c2_i36];
    }

    for (c2_i37 = 0; c2_i37 < 2; c2_i37++) {
      c2_A[c2_i37] = c2_dir1[c2_i37];
    }

    c2_b_eml_scalar_eg(chartInstance);
    c2_b_eml_scalar_eg(chartInstance);
    c2_p_y = 0.0;
    for (c2_e_k = 1; c2_e_k < 3; c2_e_k++) {
      c2_f_k = c2_e_k - 1;
      c2_p_y += c2_d_a[c2_f_k] * c2_A[c2_f_k];
    }

    c2_b_A = c2_p_y;
    for (c2_i38 = 0; c2_i38 < 2; c2_i38++) {
      c2_c_v[c2_i38] = c2_v[c2_i38];
    }

    c2_e_B = c2_mpower(chartInstance, c2_norm(chartInstance, c2_c_v));
    c2_x = c2_b_A;
    c2_q_y = c2_e_B;
    c2_b_x = c2_x;
    c2_r_y = c2_q_y;
    c2_f = c2_b_x / c2_r_y;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 92);
    guard10 = FALSE;
    if (CV_EML_COND(0, 1, 8, c2_f < 0.0)) {
      guard10 = TRUE;
    } else if (CV_EML_COND(0, 1, 9, c2_f > 1.0)) {
      guard10 = TRUE;
    } else {
      CV_EML_MCDC(0, 1, 4, FALSE);
      CV_EML_IF(0, 1, 11, FALSE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 95);
      for (c2_i39 = 0; c2_i39 < 2; c2_i39++) {
        c2_d_a[c2_i39] = c2_dir1[c2_i39];
      }

      for (c2_i40 = 0; c2_i40 < 2; c2_i40++) {
        c2_A[c2_i40] = c2_n[c2_i40];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_distNew1 = 0.0;
      for (c2_g_k = 1; c2_g_k < 3; c2_g_k++) {
        c2_h_k = c2_g_k - 1;
        c2_distNew1 += c2_d_a[c2_h_k] * c2_A[c2_h_k];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 96);
      if (CV_EML_IF(0, 1, 12, c2_abs(chartInstance, c2_distNew1) < c2_abs
                    (chartInstance, c2_dist1))) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 97);
        c2_rho1 = 0.0;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 98);
        c2_dist1 = c2_distNew1;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 99);
        c2_segNum = c2_LineData[4 + 5 * ((int32_T)c2_j - 1)];
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 100);
        c2_j_a = 1.0 - c2_f;
        c2_i_b = c2_LineData[4 + 5 * ((int32_T)c2_j - 1)];
        c2_Srem = c2_j_a * c2_i_b;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 101);
        c2_psi1 = c2_atan2(chartInstance, c2_v[1], c2_v[0]);
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 102);
        c2_deltaPsi = c2_atan2(chartInstance, c2_v[1], c2_v[0]) - c2_Psi;
      }
    }

    if (guard10 == TRUE) {
      CV_EML_MCDC(0, 1, 4, TRUE);
      CV_EML_IF(0, 1, 11, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 93);
    }

    c2_c_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 1, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 114);
  c2_b_segNum = c2_segNum + 1.0;
  c2_i41 = 0;
  for (c2_i42 = 0; c2_i42 < 13; c2_i42++) {
    c2_c_x[c2_i42] = (c2_LineData[c2_i41 + 4] == c2_b_segNum);
    c2_i41 += 5;
  }

  c2_idx = 0;
  for (c2_i43 = 0; c2_i43 < 2; c2_i43++) {
    c2_ii_sizes[c2_i43] = 1 + 12 * c2_i43;
  }

  c2_ii = 1;
  exitg2 = FALSE;
  while ((exitg2 == FALSE) && (c2_ii < 14)) {
    c2_b_ii = c2_ii;
    guard21 = FALSE;
    if (c2_c_x[c2_b_ii - 1]) {
      c2_k_a = c2_idx + 1;
      c2_idx = c2_k_a;
      c2_ii_data[c2_idx - 1] = c2_b_ii;
      if (c2_idx >= 13) {
        exitg2 = TRUE;
      } else {
        guard21 = TRUE;
      }
    } else {
      guard21 = TRUE;
    }

    if (guard21 == TRUE) {
      c2_ii++;
    }
  }

  c2_b0 = (1 > c2_idx);
  c2_b1 = c2_b0;
  c2_b2 = c2_b1;
  if (c2_b2) {
    c2_i44 = 0;
  } else {
    c2_i44 = _SFD_EML_ARRAY_BOUNDS_CHECK("", c2_idx, 1, 13, 0, 0);
  }

  c2_tmp_sizes = c2_i44;
  c2_loop_ub = c2_i44 - 1;
  for (c2_i45 = 0; c2_i45 <= c2_loop_ub; c2_i45++) {
    c2_tmp_data[c2_i45] = 1 + c2_i45;
  }

  c2_iv0[0] = 1;
  c2_iv0[1] = c2_tmp_sizes;
  c2_b_ii_sizes[0] = c2_iv0[0];
  c2_b_ii_sizes[1] = c2_iv0[1];
  c2_b_loop_ub = c2_iv0[1] - 1;
  for (c2_i46 = 0; c2_i46 <= c2_b_loop_ub; c2_i46++) {
    c2_c_loop_ub = c2_iv0[0] - 1;
    for (c2_i47 = 0; c2_i47 <= c2_c_loop_ub; c2_i47++) {
      c2_b_ii_data[c2_i47 + c2_b_ii_sizes[0] * c2_i46] =
        c2_ii_data[c2_tmp_data[c2_i47 + c2_iv0[0] * c2_i46] - 1];
    }
  }

  c2_ii_sizes[0] = 1;
  c2_ii_sizes[1] = c2_b_ii_sizes[1];
  c2_d_loop_ub = c2_b_ii_sizes[1] - 1;
  for (c2_i48 = 0; c2_i48 <= c2_d_loop_ub; c2_i48++) {
    c2_ii_data[c2_ii_sizes[0] * c2_i48] = c2_b_ii_data[c2_b_ii_sizes[0] * c2_i48];
  }

  c2_lineIndex_sizes[0] = 1;
  c2_lineIndex_sizes[1] = c2_ii_sizes[1];
  c2_lineIndex = c2_lineIndex_sizes[0];
  c2_b_lineIndex = c2_lineIndex_sizes[1];
  c2_e_loop_ub = c2_ii_sizes[0] * c2_ii_sizes[1] - 1;
  for (c2_i49 = 0; c2_i49 <= c2_e_loop_ub; c2_i49++) {
    c2_lineIndex_data[c2_i49] = (real_T)c2_ii_data[c2_i49];
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 115);
  c2_b3 = (c2_lineIndex_sizes[1] == 0);
  if (CV_EML_IF(0, 1, 13, CV_EML_MCDC(0, 1, 5, !CV_EML_COND(0, 1, 10, c2_b3))))
  {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 116);
    c2_rho1new = 0.0;
  } else {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 118);
    c2_c_segNum = c2_segNum + 1.0;
    c2_i50 = 0;
    for (c2_i51 = 0; c2_i51 < 52; c2_i51++) {
      c2_d_x[c2_i51] = (c2_CircleData[c2_i50 + 5] == c2_c_segNum);
      c2_i50 += 6;
    }

    c2_b_idx = 0;
    for (c2_i52 = 0; c2_i52 < 2; c2_i52++) {
      c2_c_ii_sizes[c2_i52] = 1 + 51 * c2_i52;
    }

    c2_c_ii = 1;
    exitg1 = FALSE;
    while ((exitg1 == FALSE) && (c2_c_ii < 53)) {
      c2_d_ii = c2_c_ii;
      guard112 = FALSE;
      if (c2_d_x[c2_d_ii - 1]) {
        c2_l_a = c2_b_idx + 1;
        c2_b_idx = c2_l_a;
        c2_c_ii_data[c2_b_idx - 1] = c2_d_ii;
        if (c2_b_idx >= 52) {
          exitg1 = TRUE;
        } else {
          guard112 = TRUE;
        }
      } else {
        guard112 = TRUE;
      }

      if (guard112 == TRUE) {
        c2_c_ii++;
      }
    }

    c2_b4 = (1 > c2_b_idx);
    c2_b5 = c2_b4;
    c2_b6 = c2_b5;
    if (c2_b6) {
      c2_i53 = 0;
    } else {
      c2_i53 = _SFD_EML_ARRAY_BOUNDS_CHECK("", c2_b_idx, 1, 52, 0, 0);
    }

    c2_b_tmp_sizes = c2_i53;
    c2_f_loop_ub = c2_i53 - 1;
    for (c2_i54 = 0; c2_i54 <= c2_f_loop_ub; c2_i54++) {
      c2_b_tmp_data[c2_i54] = 1 + c2_i54;
    }

    c2_iv1[0] = 1;
    c2_iv1[1] = c2_b_tmp_sizes;
    c2_d_ii_sizes[0] = c2_iv1[0];
    c2_d_ii_sizes[1] = c2_iv1[1];
    c2_g_loop_ub = c2_iv1[1] - 1;
    for (c2_i55 = 0; c2_i55 <= c2_g_loop_ub; c2_i55++) {
      c2_h_loop_ub = c2_iv1[0] - 1;
      for (c2_i56 = 0; c2_i56 <= c2_h_loop_ub; c2_i56++) {
        c2_d_ii_data[c2_i56 + c2_d_ii_sizes[0] * c2_i55] =
          c2_c_ii_data[c2_b_tmp_data[c2_i56 + c2_iv1[0] * c2_i55] - 1];
      }
    }

    c2_c_ii_sizes[0] = 1;
    c2_c_ii_sizes[1] = c2_d_ii_sizes[1];
    c2_i_loop_ub = c2_d_ii_sizes[1] - 1;
    for (c2_i57 = 0; c2_i57 <= c2_i_loop_ub; c2_i57++) {
      c2_c_ii_data[c2_c_ii_sizes[0] * c2_i57] = c2_d_ii_data[c2_d_ii_sizes[0] *
        c2_i57];
    }

    c2_circleIndex_sizes[0] = 1;
    c2_circleIndex_sizes[1] = c2_c_ii_sizes[1];
    c2_circleIndex = c2_circleIndex_sizes[0];
    c2_b_circleIndex = c2_circleIndex_sizes[1];
    c2_j_loop_ub = c2_c_ii_sizes[0] * c2_c_ii_sizes[1] - 1;
    for (c2_i58 = 0; c2_i58 <= c2_j_loop_ub; c2_i58++) {
      c2_circleIndex_data[c2_i58] = (real_T)c2_c_ii_data[c2_i58];
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 119);
    c2_b7 = (c2_circleIndex_sizes[1] == 0);
    if (CV_EML_IF(0, 1, 14, c2_b7)) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 120);
      c2_rho1new = c2_rho1;
    } else {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 122);
      (real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("circleIndex", 1, 1,
        c2_circleIndex_sizes[1], 1, 0);
      c2_f_B = c2_CircleData[2 + 6 * ((int32_T)c2_circleIndex_data[0] - 1)];
      c2_s_y = c2_f_B;
      c2_t_y = c2_s_y;
      c2_rho1new = 1.0 / c2_t_y;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 126);
  c2_e_x = c2_psi1;
  c2_f_x = c2_e_x;
  c2_f_x = muDoubleScalarCos(c2_f_x);
  c2_m_a = c2_l_S;
  c2_j_b = c2_f_x;
  c2_u_y = c2_m_a * c2_j_b;
  c2_PX = c2_X1 + c2_u_y;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, MAX_int8_T);
  c2_g_x = c2_psi1;
  c2_h_x = c2_g_x;
  c2_h_x = muDoubleScalarSin(c2_h_x);
  c2_n_a = c2_l_S;
  c2_k_b = c2_h_x;
  c2_v_y = c2_n_a * c2_k_b;
  c2_PY = c2_Y1 + c2_v_y;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 128U);
  c2_alpha = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 129U);
  c2_r = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 131U);
  if (CV_EML_IF(0, 1, 15, c2_rho1 == 0.0)) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 132U);
    guard9 = FALSE;
    if (CV_EML_COND(0, 1, 11, c2_Srem < c2_l_S)) {
      if (CV_EML_COND(0, 1, 12, c2_rho1new != 0.0)) {
        CV_EML_MCDC(0, 1, 6, TRUE);
        CV_EML_IF(0, 1, 16, TRUE);
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 133U);
        c2_i_x = c2_psi1;
        c2_j_x = c2_i_x;
        c2_j_x = muDoubleScalarCos(c2_j_x);
        c2_o_a = c2_Srem;
        c2_l_b = c2_j_x;
        c2_w_y = c2_o_a * c2_l_b;
        c2_PX = c2_X1 + c2_w_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 134U);
        c2_k_x = c2_psi1;
        c2_l_x = c2_k_x;
        c2_l_x = muDoubleScalarSin(c2_l_x);
        c2_p_a = c2_Srem;
        c2_m_b = c2_l_x;
        c2_x_y = c2_p_a * c2_m_b;
        c2_PY = c2_Y1 + c2_x_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 135U);
        c2_g_B = c2_rho1new;
        c2_y_y = c2_g_B;
        c2_ab_y = c2_y_y;
        c2_r = 1.0 / c2_ab_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 136U);
        c2_c_A = c2_l_S - c2_Srem;
        c2_h_B = c2_r;
        c2_m_x = c2_c_A;
        c2_bb_y = c2_h_B;
        c2_n_x = c2_m_x;
        c2_cb_y = c2_bb_y;
        c2_alpha = c2_n_x / c2_cb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 137U);
        c2_o_x = c2_psi1 + c2_alpha;
        c2_p_x = c2_o_x;
        c2_p_x = muDoubleScalarSin(c2_p_x);
        c2_q_x = c2_psi1;
        c2_r_x = c2_q_x;
        c2_r_x = muDoubleScalarSin(c2_r_x);
        c2_q_a = c2_r;
        c2_n_b = c2_p_x - c2_r_x;
        c2_db_y = c2_q_a * c2_n_b;
        c2_PX += c2_db_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 138U);
        c2_s_x = c2_psi1;
        c2_t_x = c2_s_x;
        c2_t_x = muDoubleScalarCos(c2_t_x);
        c2_u_x = c2_psi1 + c2_alpha;
        c2_v_x = c2_u_x;
        c2_v_x = muDoubleScalarCos(c2_v_x);
        c2_r_a = c2_r;
        c2_o_b = c2_t_x - c2_v_x;
        c2_eb_y = c2_r_a * c2_o_b;
        c2_PY += c2_eb_y;
      } else {
        guard9 = TRUE;
      }
    } else {
      guard9 = TRUE;
    }

    if (guard9 == TRUE) {
      CV_EML_MCDC(0, 1, 6, FALSE);
      CV_EML_IF(0, 1, 16, FALSE);
    }
  } else {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 141U);
    if (CV_EML_IF(0, 1, 17, c2_Srem >= c2_l_S)) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 142U);
      c2_i_B = c2_rho1;
      c2_fb_y = c2_i_B;
      c2_gb_y = c2_fb_y;
      c2_r = 1.0 / c2_gb_y;
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 143U);
      c2_d_A = c2_l_S;
      c2_j_B = c2_r;
      c2_w_x = c2_d_A;
      c2_hb_y = c2_j_B;
      c2_x_x = c2_w_x;
      c2_ib_y = c2_hb_y;
      c2_alpha = c2_x_x / c2_ib_y;
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 144U);
      c2_y_x = c2_psi1 + c2_alpha;
      c2_ab_x = c2_y_x;
      c2_ab_x = muDoubleScalarSin(c2_ab_x);
      c2_bb_x = c2_psi1;
      c2_cb_x = c2_bb_x;
      c2_cb_x = muDoubleScalarSin(c2_cb_x);
      c2_s_a = c2_r;
      c2_p_b = c2_ab_x - c2_cb_x;
      c2_jb_y = c2_s_a * c2_p_b;
      c2_PX = c2_X1 + c2_jb_y;
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 145U);
      c2_db_x = c2_psi1;
      c2_eb_x = c2_db_x;
      c2_eb_x = muDoubleScalarCos(c2_eb_x);
      c2_fb_x = c2_psi1 + c2_alpha;
      c2_gb_x = c2_fb_x;
      c2_gb_x = muDoubleScalarCos(c2_gb_x);
      c2_t_a = c2_r;
      c2_q_b = c2_eb_x - c2_gb_x;
      c2_kb_y = c2_t_a * c2_q_b;
      c2_PY = c2_Y1 + c2_kb_y;
    } else {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 146U);
      if (CV_EML_IF(0, 1, 18, c2_rho1new == 0.0)) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 147U);
        c2_k_B = c2_rho1;
        c2_lb_y = c2_k_B;
        c2_mb_y = c2_lb_y;
        c2_r = 1.0 / c2_mb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 148U);
        c2_e_A = c2_Srem;
        c2_l_B = c2_r;
        c2_hb_x = c2_e_A;
        c2_nb_y = c2_l_B;
        c2_ib_x = c2_hb_x;
        c2_ob_y = c2_nb_y;
        c2_alpha = c2_ib_x / c2_ob_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 149U);
        c2_jb_x = c2_psi1 + c2_alpha;
        c2_kb_x = c2_jb_x;
        c2_kb_x = muDoubleScalarSin(c2_kb_x);
        c2_lb_x = c2_psi1;
        c2_mb_x = c2_lb_x;
        c2_mb_x = muDoubleScalarSin(c2_mb_x);
        c2_u_a = c2_r;
        c2_r_b = c2_kb_x - c2_mb_x;
        c2_pb_y = c2_u_a * c2_r_b;
        c2_PX = c2_X1 + c2_pb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 150U);
        c2_nb_x = c2_psi1;
        c2_ob_x = c2_nb_x;
        c2_ob_x = muDoubleScalarCos(c2_ob_x);
        c2_pb_x = c2_psi1 + c2_alpha;
        c2_qb_x = c2_pb_x;
        c2_qb_x = muDoubleScalarCos(c2_qb_x);
        c2_v_a = c2_r;
        c2_s_b = c2_ob_x - c2_qb_x;
        c2_qb_y = c2_v_a * c2_s_b;
        c2_PY = c2_Y1 + c2_qb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 151U);
        c2_rb_x = c2_psi1 + c2_alpha;
        c2_sb_x = c2_rb_x;
        c2_sb_x = muDoubleScalarCos(c2_sb_x);
        c2_w_a = c2_l_S - c2_Srem;
        c2_t_b = c2_sb_x;
        c2_rb_y = c2_w_a * c2_t_b;
        c2_PX += c2_rb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 152U);
        c2_tb_x = c2_psi1 + c2_alpha;
        c2_ub_x = c2_tb_x;
        c2_ub_x = muDoubleScalarSin(c2_ub_x);
        c2_x_a = c2_l_S - c2_Srem;
        c2_u_b = c2_ub_x;
        c2_sb_y = c2_x_a * c2_u_b;
        c2_PY += c2_sb_y;
      } else {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 154U);
        c2_m_B = c2_rho1;
        c2_tb_y = c2_m_B;
        c2_ub_y = c2_tb_y;
        c2_r = 1.0 / c2_ub_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 155U);
        c2_f_A = c2_Srem;
        c2_n_B = c2_r;
        c2_vb_x = c2_f_A;
        c2_vb_y = c2_n_B;
        c2_wb_x = c2_vb_x;
        c2_wb_y = c2_vb_y;
        c2_alpha = c2_wb_x / c2_wb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 156U);
        c2_xb_x = c2_psi1 + c2_alpha;
        c2_yb_x = c2_xb_x;
        c2_yb_x = muDoubleScalarSin(c2_yb_x);
        c2_ac_x = c2_psi1;
        c2_bc_x = c2_ac_x;
        c2_bc_x = muDoubleScalarSin(c2_bc_x);
        c2_y_a = c2_r;
        c2_v_b = c2_yb_x - c2_bc_x;
        c2_xb_y = c2_y_a * c2_v_b;
        c2_PX = c2_X1 + c2_xb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 157U);
        c2_cc_x = c2_psi1;
        c2_dc_x = c2_cc_x;
        c2_dc_x = muDoubleScalarCos(c2_dc_x);
        c2_ec_x = c2_psi1 + c2_alpha;
        c2_fc_x = c2_ec_x;
        c2_fc_x = muDoubleScalarCos(c2_fc_x);
        c2_ab_a = c2_r;
        c2_w_b = c2_dc_x - c2_fc_x;
        c2_yb_y = c2_ab_a * c2_w_b;
        c2_PY = c2_Y1 + c2_yb_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 158U);
        c2_o_B = c2_rho1new;
        c2_ac_y = c2_o_B;
        c2_bc_y = c2_ac_y;
        c2_r = 1.0 / c2_bc_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 159U);
        c2_psi1 += c2_alpha;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 160U);
        c2_g_A = c2_l_S - c2_Srem;
        c2_p_B = c2_r;
        c2_gc_x = c2_g_A;
        c2_cc_y = c2_p_B;
        c2_hc_x = c2_gc_x;
        c2_dc_y = c2_cc_y;
        c2_alpha = c2_hc_x / c2_dc_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 161U);
        c2_ic_x = c2_psi1 + c2_alpha;
        c2_jc_x = c2_ic_x;
        c2_jc_x = muDoubleScalarSin(c2_jc_x);
        c2_kc_x = c2_psi1;
        c2_lc_x = c2_kc_x;
        c2_lc_x = muDoubleScalarSin(c2_lc_x);
        c2_bb_a = c2_r;
        c2_x_b = c2_jc_x - c2_lc_x;
        c2_ec_y = c2_bb_a * c2_x_b;
        c2_PX += c2_ec_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 162U);
        c2_mc_x = c2_psi1;
        c2_nc_x = c2_mc_x;
        c2_nc_x = muDoubleScalarCos(c2_nc_x);
        c2_oc_x = c2_psi1 + c2_alpha;
        c2_pc_x = c2_oc_x;
        c2_pc_x = muDoubleScalarCos(c2_pc_x);
        c2_cb_a = c2_r;
        c2_y_b = c2_nc_x - c2_pc_x;
        c2_fc_y = c2_cb_a * c2_y_b;
        c2_PY += c2_fc_y;
      }
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 170U);
  c2_j = 1.0;
  c2_f_j = 0;
  while (c2_f_j < 52) {
    c2_j = 1.0 + (real_T)c2_f_j;
    CV_EML_FOR(0, 1, 2, 1);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 173U);
    c2_db_a = c2_Rvec[(int32_T)c2_j - 1];
    c2_b_sign(chartInstance, &c2_db_a);
    c2_ab_b = c2_PX - c2_CXvec[(int32_T)c2_j - 1];
    c2_gc_y = c2_db_a * c2_ab_b;
    c2_d1 = c2_Rvec[(int32_T)c2_j - 1];
    c2_b_sign(chartInstance, &c2_d1);
    c2_eb_a = -c2_d1;
    c2_bb_b = c2_PY - c2_CYvec[(int32_T)c2_j - 1];
    c2_hc_y = c2_eb_a * c2_bb_b;
    c2_theta = c2_mod(chartInstance, c2_atan2(chartInstance, c2_gc_y, c2_hc_y),
                      6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 174U);
    c2_thetaRnew = c2_mod(chartInstance, c2_thetaRvec[(int32_T)c2_j - 1],
                          6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 175U);
    c2_thetaSnew = c2_mod(chartInstance, c2_thetaSvec[(int32_T)c2_j - 1],
                          6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 177U);
    guard2 = FALSE;
    guard3 = FALSE;
    guard4 = FALSE;
    guard5 = FALSE;
    guard6 = FALSE;
    guard7 = FALSE;
    guard8 = FALSE;
    if (CV_EML_IF(0, 1, 19, c2_thetaSvec[(int32_T)c2_j - 1] < c2_thetaRvec
                  [(int32_T)c2_j - 1])) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 178U);
      if (CV_EML_IF(0, 1, 20, c2_thetaSnew < c2_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 179U);
        if (CV_EML_COND(0, 1, 13, c2_theta < c2_thetaSnew)) {
          guard4 = TRUE;
        } else if (CV_EML_COND(0, 1, 14, c2_theta >= c2_thetaRnew)) {
          guard4 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 7, FALSE);
          CV_EML_IF(0, 1, 21, FALSE);
          guard6 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 183U);
        if (CV_EML_COND(0, 1, 15, c2_theta < c2_thetaSnew)) {
          if (CV_EML_COND(0, 1, 16, c2_theta > c2_thetaRnew)) {
            CV_EML_MCDC(0, 1, 8, TRUE);
            CV_EML_IF(0, 1, 22, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 184U);
          } else {
            guard8 = TRUE;
          }
        } else {
          guard8 = TRUE;
        }
      }
    } else {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 188U);
      if (CV_EML_IF(0, 1, 23, c2_thetaSnew > c2_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 189U);
        if (CV_EML_COND(0, 1, 17, c2_theta > c2_thetaSnew)) {
          guard3 = TRUE;
        } else if (CV_EML_COND(0, 1, 18, c2_theta <= c2_thetaRnew)) {
          guard3 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 9, FALSE);
          CV_EML_IF(0, 1, 24, FALSE);
          guard5 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 193U);
        if (CV_EML_COND(0, 1, 19, c2_theta > c2_thetaSnew)) {
          if (CV_EML_COND(0, 1, 20, c2_theta < c2_thetaRnew)) {
            CV_EML_MCDC(0, 1, 10, TRUE);
            CV_EML_IF(0, 1, 25, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 194U);
          } else {
            guard7 = TRUE;
          }
        } else {
          guard7 = TRUE;
        }
      }
    }

    if (guard8 == TRUE) {
      CV_EML_MCDC(0, 1, 8, FALSE);
      CV_EML_IF(0, 1, 22, FALSE);
      guard6 = TRUE;
    }

    if (guard7 == TRUE) {
      CV_EML_MCDC(0, 1, 10, FALSE);
      CV_EML_IF(0, 1, 25, FALSE);
      guard5 = TRUE;
    }

    if (guard6 == TRUE) {
      guard2 = TRUE;
    }

    if (guard5 == TRUE) {
      guard2 = TRUE;
    }

    if (guard4 == TRUE) {
      CV_EML_MCDC(0, 1, 7, TRUE);
      CV_EML_IF(0, 1, 21, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 180U);
    }

    if (guard3 == TRUE) {
      CV_EML_MCDC(0, 1, 9, TRUE);
      CV_EML_IF(0, 1, 24, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 190U);
    }

    if (guard2 == TRUE) {
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 199U);
      c2_distVec[0] = c2_PX - c2_CXvec[(int32_T)c2_j - 1];
      c2_distVec[1] = c2_PY - c2_CYvec[(int32_T)c2_j - 1];
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 200U);
      for (c2_i59 = 0; c2_i59 < 2; c2_i59++) {
        c2_d_a[c2_i59] = c2_distVec[c2_i59];
      }

      for (c2_i60 = 0; c2_i60 < 2; c2_i60++) {
        c2_A[c2_i60] = c2_distVec[c2_i60];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_ic_y = 0.0;
      for (c2_i_k = 1; c2_i_k < 3; c2_i_k++) {
        c2_j_k = c2_i_k - 1;
        c2_ic_y += c2_d_a[c2_j_k] * c2_A[c2_j_k];
      }

      for (c2_i61 = 0; c2_i61 < 2; c2_i61++) {
        c2_A[c2_i61] = c2_distVec[c2_i61];
      }

      c2_q_B = c2_ic_y;
      c2_b_sqrt(chartInstance, &c2_q_B);
      c2_jc_y = c2_q_B;
      c2_kc_y = c2_jc_y;
      for (c2_i62 = 0; c2_i62 < 2; c2_i62++) {
        c2_A[c2_i62] /= c2_kc_y;
      }

      c2_cb_b = c2_Rvec[(int32_T)c2_j - 1];
      for (c2_i63 = 0; c2_i63 < 2; c2_i63++) {
        c2_A[c2_i63] *= c2_cb_b;
      }

      c2_r_B = c2_abs(chartInstance, c2_Rvec[(int32_T)c2_j - 1]);
      c2_lc_y = c2_r_B;
      c2_mc_y = c2_lc_y;
      for (c2_i64 = 0; c2_i64 < 2; c2_i64++) {
        c2_n[c2_i64] = c2_A[c2_i64] / c2_mc_y;
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 201U);
      c2_fb_a = c2_Rvec[(int32_T)c2_j - 1];
      for (c2_i65 = 0; c2_i65 < 2; c2_i65++) {
        c2_A[c2_i65] = c2_n[c2_i65];
      }

      for (c2_i66 = 0; c2_i66 < 2; c2_i66++) {
        c2_A[c2_i66] *= c2_fb_a;
      }

      c2_c_CXvec[0] = c2_CXvec[(int32_T)c2_j - 1];
      c2_c_CXvec[1] = c2_CYvec[(int32_T)c2_j - 1];
      for (c2_i67 = 0; c2_i67 < 2; c2_i67++) {
        c2_intVec[c2_i67] = c2_c_CXvec[c2_i67] + c2_A[c2_i67];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 202U);
      c2_b_PX[0] = c2_PX;
      c2_b_PX[1] = c2_PY;
      for (c2_i68 = 0; c2_i68 < 2; c2_i68++) {
        c2_d_a[c2_i68] = -(c2_b_PX[c2_i68] - c2_intVec[c2_i68]);
      }

      for (c2_i69 = 0; c2_i69 < 2; c2_i69++) {
        c2_A[c2_i69] = c2_n[c2_i69];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_distNew = 0.0;
      for (c2_k_k = 1; c2_k_k < 3; c2_k_k++) {
        c2_l_k = c2_k_k - 1;
        c2_distNew += c2_d_a[c2_l_k] * c2_A[c2_l_k];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 203U);
      if (CV_EML_IF(0, 1, 26, c2_abs(chartInstance, c2_distNew) < c2_abs
                    (chartInstance, c2_dist))) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 204U);
        c2_s_B = c2_Rvec[(int32_T)c2_j - 1];
        c2_nc_y = c2_s_B;
        c2_oc_y = c2_nc_y;
        c2_rho = 1.0 / c2_oc_y;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 205U);
        c2_dist = c2_distNew;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 207U);
        c2_t_B = c2_Rvec[(int32_T)c2_j - 1];
        c2_pc_y = c2_t_B;
        c2_qc_y = c2_pc_y;
        c2_rc_y = 1.0 / c2_qc_y;
        c2_gb_a = c2_rc_y;
        c2_db_b = c2_vel;
        c2_sc_y = c2_gb_a * c2_db_b;
        c2_deltadPsi = c2_sc_y - c2_dPsi;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 208U);
        if (CV_EML_IF(0, 1, 27, c2_deltaPsi > 3.1415926535897931)) {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 209U);
          c2_deltaPsi -= 6.2831853071795862;
        } else {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 210U);
          if (CV_EML_IF(0, 1, 28, c2_deltaPsi < -3.1415926535897931)) {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 211U);
            c2_deltaPsi += 6.2831853071795862;
          }
        }
      }
    }

    c2_f_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 2, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 219U);
  c2_j = 1.0;
  c2_g_j = 0;
  while (c2_g_j < 13) {
    c2_j = 1.0 + (real_T)c2_g_j;
    CV_EML_FOR(0, 1, 3, 1);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 220U);
    c2_h_j = (int32_T)c2_j - 1;
    c2_i_j = (int32_T)c2_j - 1;
    for (c2_i70 = 0; c2_i70 < 2; c2_i70++) {
      c2_v[c2_i70] = c2_Evec[c2_i70 + (c2_h_j << 1)] - c2_Svec[c2_i70 + (c2_i_j <<
        1)];
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 221U);
    c2_A[0] = -c2_v[1];
    c2_A[1] = c2_v[0];
    for (c2_i71 = 0; c2_i71 < 2; c2_i71++) {
      c2_d_v[c2_i71] = c2_v[c2_i71];
    }

    c2_u_B = c2_norm(chartInstance, c2_d_v);
    c2_tc_y = c2_u_B;
    c2_uc_y = c2_tc_y;
    for (c2_i72 = 0; c2_i72 < 2; c2_i72++) {
      c2_n[c2_i72] = c2_A[c2_i72] / c2_uc_y;
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 222U);
    c2_dir[0] = c2_PX - c2_Svec[((int32_T)c2_j - 1) << 1];
    c2_dir[1] = c2_PY - c2_Svec[1 + (((int32_T)c2_j - 1) << 1)];
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 223U);
    for (c2_i73 = 0; c2_i73 < 2; c2_i73++) {
      c2_d_a[c2_i73] = c2_v[c2_i73];
    }

    for (c2_i74 = 0; c2_i74 < 2; c2_i74++) {
      c2_A[c2_i74] = c2_dir[c2_i74];
    }

    c2_b_eml_scalar_eg(chartInstance);
    c2_b_eml_scalar_eg(chartInstance);
    c2_vc_y = 0.0;
    for (c2_m_k = 1; c2_m_k < 3; c2_m_k++) {
      c2_n_k = c2_m_k - 1;
      c2_vc_y += c2_d_a[c2_n_k] * c2_A[c2_n_k];
    }

    c2_h_A = c2_vc_y;
    for (c2_i75 = 0; c2_i75 < 2; c2_i75++) {
      c2_e_v[c2_i75] = c2_v[c2_i75];
    }

    c2_v_B = c2_mpower(chartInstance, c2_norm(chartInstance, c2_e_v));
    c2_qc_x = c2_h_A;
    c2_wc_y = c2_v_B;
    c2_rc_x = c2_qc_x;
    c2_xc_y = c2_wc_y;
    c2_f = c2_rc_x / c2_xc_y;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 224U);
    guard1 = FALSE;
    if (CV_EML_COND(0, 1, 21, c2_f < 0.0)) {
      guard1 = TRUE;
    } else if (CV_EML_COND(0, 1, 22, c2_f > 1.0)) {
      guard1 = TRUE;
    } else {
      CV_EML_MCDC(0, 1, 11, FALSE);
      CV_EML_IF(0, 1, 29, FALSE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 227U);
      for (c2_i76 = 0; c2_i76 < 2; c2_i76++) {
        c2_d_a[c2_i76] = c2_dir[c2_i76];
      }

      for (c2_i77 = 0; c2_i77 < 2; c2_i77++) {
        c2_A[c2_i77] = c2_n[c2_i77];
      }

      c2_b_eml_scalar_eg(chartInstance);
      c2_b_eml_scalar_eg(chartInstance);
      c2_distNew = 0.0;
      for (c2_o_k = 1; c2_o_k < 3; c2_o_k++) {
        c2_p_k = c2_o_k - 1;
        c2_distNew += c2_d_a[c2_p_k] * c2_A[c2_p_k];
      }

      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 228U);
      if (CV_EML_IF(0, 1, 30, c2_abs(chartInstance, c2_distNew) < c2_abs
                    (chartInstance, c2_dist))) {
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 229U);
        c2_rho = 0.0;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 230U);
        c2_dist = c2_distNew;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 231U);
        c2_lineLength = c2_LineData[4 + 5 * ((int32_T)c2_j - 1)];
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 233U);
        c2_deltadPsi = -c2_dPsi;
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 234U);
        if (CV_EML_IF(0, 1, 31, c2_deltaPsi > 3.1415926535897931)) {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 235U);
          c2_deltaPsi -= 6.2831853071795862;
        } else {
          _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 236U);
          if (CV_EML_IF(0, 1, 32, c2_deltaPsi < -3.1415926535897931)) {
            _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 237U);
            c2_deltaPsi += 6.2831853071795862;
          }
        }
      }
    }

    if (guard1 == TRUE) {
      CV_EML_MCDC(0, 1, 11, TRUE);
      CV_EML_IF(0, 1, 29, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 225U);
    }

    c2_g_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 3, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 242U);
  if (CV_EML_IF(0, 1, 33, c2_rho1new == 0.0)) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 243U);
    c2_eb_b = c2_dist;
    c2_dist = c2_eb_b;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, -243);
  _SFD_SYMBOL_SCOPE_POP();
  *c2_b_dist = c2_dist;
  *c2_b_dist1 = c2_dist1;
  *c2_b_deltaPsi = c2_deltaPsi;
  *c2_b_deltadPsi = c2_deltadPsi;
  *c2_b_rho = c2_rho;
  *c2_b_rho1 = c2_rho1;
  *c2_c_PX = c2_PX;
  *c2_b_PY = c2_PY;
  *c2_b_r = c2_r;
  *c2_b_Srem = c2_Srem;
  *c2_b_rho1new = c2_rho1new;
  *c2_d_segNum = c2_segNum;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
}

static void initSimStructsc2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc2_laneKeepingArcSplinesFF_2013a
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber)
{
}

static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  real_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_u = *(real_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static real_T c2_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_segNum, const char_T *c2_identifier)
{
  real_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_segNum), &c2_thisId);
  sf_mex_destroy(&c2_segNum);
  return c2_y;
}

static real_T c2_b_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real_T c2_y;
  real_T c2_d2;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d2, 1, 0, 0U, 0, 0U, 0);
  c2_y = c2_d2;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_segNum;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_segNum = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_segNum), &c2_thisId);
  sf_mex_destroy(&c2_segNum);
  *(real_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_i78;
  int32_T c2_i79;
  int32_T c2_i80;
  real_T c2_b_inData[65];
  int32_T c2_i81;
  int32_T c2_i82;
  int32_T c2_i83;
  real_T c2_u[65];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_i78 = 0;
  for (c2_i79 = 0; c2_i79 < 13; c2_i79++) {
    for (c2_i80 = 0; c2_i80 < 5; c2_i80++) {
      c2_b_inData[c2_i80 + c2_i78] = (*(real_T (*)[65])c2_inData)[c2_i80 +
        c2_i78];
    }

    c2_i78 += 5;
  }

  c2_i81 = 0;
  for (c2_i82 = 0; c2_i82 < 13; c2_i82++) {
    for (c2_i83 = 0; c2_i83 < 5; c2_i83++) {
      c2_u[c2_i83 + c2_i81] = c2_b_inData[c2_i83 + c2_i81];
    }

    c2_i81 += 5;
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 2, 5, 13), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_i84;
  int32_T c2_i85;
  int32_T c2_i86;
  real_T c2_b_inData[312];
  int32_T c2_i87;
  int32_T c2_i88;
  int32_T c2_i89;
  real_T c2_u[312];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_i84 = 0;
  for (c2_i85 = 0; c2_i85 < 52; c2_i85++) {
    for (c2_i86 = 0; c2_i86 < 6; c2_i86++) {
      c2_b_inData[c2_i86 + c2_i84] = (*(real_T (*)[312])c2_inData)[c2_i86 +
        c2_i84];
    }

    c2_i84 += 6;
  }

  c2_i87 = 0;
  for (c2_i88 = 0; c2_i88 < 52; c2_i88++) {
    for (c2_i89 = 0; c2_i89 < 6; c2_i89++) {
      c2_u[c2_i89 + c2_i87] = c2_b_inData[c2_i89 + c2_i87];
    }

    c2_i87 += 6;
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 2, 6, 52), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_i90;
  real_T c2_b_inData[2];
  int32_T c2_i91;
  real_T c2_u[2];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  for (c2_i90 = 0; c2_i90 < 2; c2_i90++) {
    c2_b_inData[c2_i90] = (*(real_T (*)[2])c2_inData)[c2_i90];
  }

  for (c2_i91 = 0; c2_i91 < 2; c2_i91++) {
    c2_u[c2_i91] = c2_b_inData[c2_i91];
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 1, 2), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static void c2_c_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[2])
{
  real_T c2_dv0[2];
  int32_T c2_i92;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv0, 1, 0, 0U, 1, 0U, 1, 2);
  for (c2_i92 = 0; c2_i92 < 2; c2_i92++) {
    c2_y[c2_i92] = c2_dv0[c2_i92];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_dir;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y[2];
  int32_T c2_i93;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_dir = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_dir), &c2_thisId, c2_y);
  sf_mex_destroy(&c2_dir);
  for (c2_i93 = 0; c2_i93 < 2; c2_i93++) {
    (*(real_T (*)[2])c2_outData)[c2_i93] = c2_y[c2_i93];
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, real_T
  c2_inData_data[52], int32_T c2_inData_sizes[2])
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_b_inData_sizes[2];
  int32_T c2_loop_ub;
  int32_T c2_i94;
  real_T c2_b_inData_data[52];
  int32_T c2_u_sizes[2];
  int32_T c2_b_loop_ub;
  int32_T c2_i95;
  real_T c2_u_data[52];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_b_inData_sizes[0] = 1;
  c2_b_inData_sizes[1] = c2_inData_sizes[1];
  c2_loop_ub = c2_inData_sizes[1] - 1;
  for (c2_i94 = 0; c2_i94 <= c2_loop_ub; c2_i94++) {
    c2_b_inData_data[c2_b_inData_sizes[0] * c2_i94] =
      c2_inData_data[c2_inData_sizes[0] * c2_i94];
  }

  c2_u_sizes[0] = 1;
  c2_u_sizes[1] = c2_b_inData_sizes[1];
  c2_b_loop_ub = c2_b_inData_sizes[1] - 1;
  for (c2_i95 = 0; c2_i95 <= c2_b_loop_ub; c2_i95++) {
    c2_u_data[c2_u_sizes[0] * c2_i95] = c2_b_inData_data[c2_b_inData_sizes[0] *
      c2_i95];
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u_data, 0, 0U, 1U, 0U, 2,
    c2_u_sizes[0], c2_u_sizes[1]), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static void c2_d_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y_data[52],
   int32_T c2_y_sizes[2])
{
  int32_T c2_i96;
  uint32_T c2_uv0[2];
  int32_T c2_i97;
  static boolean_T c2_bv0[2] = { FALSE, TRUE };

  boolean_T c2_bv1[2];
  int32_T c2_tmp_sizes[2];
  real_T c2_tmp_data[52];
  int32_T c2_y;
  int32_T c2_b_y;
  int32_T c2_loop_ub;
  int32_T c2_i98;
  for (c2_i96 = 0; c2_i96 < 2; c2_i96++) {
    c2_uv0[c2_i96] = 1U + 51U * (uint32_T)c2_i96;
  }

  for (c2_i97 = 0; c2_i97 < 2; c2_i97++) {
    c2_bv1[c2_i97] = c2_bv0[c2_i97];
  }

  sf_mex_import_vs(c2_parentId, sf_mex_dup(c2_u), c2_tmp_data, 1, 0, 0U, 1, 0U,
                   2, c2_bv1, c2_uv0, c2_tmp_sizes);
  c2_y_sizes[0] = 1;
  c2_y_sizes[1] = c2_tmp_sizes[1];
  c2_y = c2_y_sizes[0];
  c2_b_y = c2_y_sizes[1];
  c2_loop_ub = c2_tmp_sizes[0] * c2_tmp_sizes[1] - 1;
  for (c2_i98 = 0; c2_i98 <= c2_loop_ub; c2_i98++) {
    c2_y_data[c2_i98] = c2_tmp_data[c2_i98];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, real_T c2_outData_data[52],
  int32_T c2_outData_sizes[2])
{
  const mxArray *c2_circleIndex;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_y_sizes[2];
  real_T c2_y_data[52];
  int32_T c2_loop_ub;
  int32_T c2_i99;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_circleIndex = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_circleIndex), &c2_thisId,
                        c2_y_data, c2_y_sizes);
  sf_mex_destroy(&c2_circleIndex);
  c2_outData_sizes[0] = 1;
  c2_outData_sizes[1] = c2_y_sizes[1];
  c2_loop_ub = c2_y_sizes[1] - 1;
  for (c2_i99 = 0; c2_i99 <= c2_loop_ub; c2_i99++) {
    c2_outData_data[c2_outData_sizes[0] * c2_i99] = c2_y_data[c2_y_sizes[0] *
      c2_i99];
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_f_sf_marshallOut(void *chartInstanceVoid, real_T
  c2_inData_data[13], int32_T c2_inData_sizes[2])
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_b_inData_sizes[2];
  int32_T c2_loop_ub;
  int32_T c2_i100;
  real_T c2_b_inData_data[13];
  int32_T c2_u_sizes[2];
  int32_T c2_b_loop_ub;
  int32_T c2_i101;
  real_T c2_u_data[13];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_b_inData_sizes[0] = 1;
  c2_b_inData_sizes[1] = c2_inData_sizes[1];
  c2_loop_ub = c2_inData_sizes[1] - 1;
  for (c2_i100 = 0; c2_i100 <= c2_loop_ub; c2_i100++) {
    c2_b_inData_data[c2_b_inData_sizes[0] * c2_i100] =
      c2_inData_data[c2_inData_sizes[0] * c2_i100];
  }

  c2_u_sizes[0] = 1;
  c2_u_sizes[1] = c2_b_inData_sizes[1];
  c2_b_loop_ub = c2_b_inData_sizes[1] - 1;
  for (c2_i101 = 0; c2_i101 <= c2_b_loop_ub; c2_i101++) {
    c2_u_data[c2_u_sizes[0] * c2_i101] = c2_b_inData_data[c2_b_inData_sizes[0] *
      c2_i101];
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u_data, 0, 0U, 1U, 0U, 2,
    c2_u_sizes[0], c2_u_sizes[1]), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static void c2_e_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y_data[13],
   int32_T c2_y_sizes[2])
{
  int32_T c2_i102;
  uint32_T c2_uv1[2];
  int32_T c2_i103;
  static boolean_T c2_bv2[2] = { FALSE, TRUE };

  boolean_T c2_bv3[2];
  int32_T c2_tmp_sizes[2];
  real_T c2_tmp_data[13];
  int32_T c2_y;
  int32_T c2_b_y;
  int32_T c2_loop_ub;
  int32_T c2_i104;
  for (c2_i102 = 0; c2_i102 < 2; c2_i102++) {
    c2_uv1[c2_i102] = 1U + 12U * (uint32_T)c2_i102;
  }

  for (c2_i103 = 0; c2_i103 < 2; c2_i103++) {
    c2_bv3[c2_i103] = c2_bv2[c2_i103];
  }

  sf_mex_import_vs(c2_parentId, sf_mex_dup(c2_u), c2_tmp_data, 1, 0, 0U, 1, 0U,
                   2, c2_bv3, c2_uv1, c2_tmp_sizes);
  c2_y_sizes[0] = 1;
  c2_y_sizes[1] = c2_tmp_sizes[1];
  c2_y = c2_y_sizes[0];
  c2_b_y = c2_y_sizes[1];
  c2_loop_ub = c2_tmp_sizes[0] * c2_tmp_sizes[1] - 1;
  for (c2_i104 = 0; c2_i104 <= c2_loop_ub; c2_i104++) {
    c2_y_data[c2_i104] = c2_tmp_data[c2_i104];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, real_T c2_outData_data[13],
  int32_T c2_outData_sizes[2])
{
  const mxArray *c2_lineIndex;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_y_sizes[2];
  real_T c2_y_data[13];
  int32_T c2_loop_ub;
  int32_T c2_i105;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_lineIndex = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_lineIndex), &c2_thisId,
                        c2_y_data, c2_y_sizes);
  sf_mex_destroy(&c2_lineIndex);
  c2_outData_sizes[0] = 1;
  c2_outData_sizes[1] = c2_y_sizes[1];
  c2_loop_ub = c2_y_sizes[1] - 1;
  for (c2_i105 = 0; c2_i105 <= c2_loop_ub; c2_i105++) {
    c2_outData_data[c2_outData_sizes[0] * c2_i105] = c2_y_data[c2_y_sizes[0] *
      c2_i105];
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_g_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_i106;
  int32_T c2_i107;
  int32_T c2_i108;
  real_T c2_b_inData[26];
  int32_T c2_i109;
  int32_T c2_i110;
  int32_T c2_i111;
  real_T c2_u[26];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_i106 = 0;
  for (c2_i107 = 0; c2_i107 < 13; c2_i107++) {
    for (c2_i108 = 0; c2_i108 < 2; c2_i108++) {
      c2_b_inData[c2_i108 + c2_i106] = (*(real_T (*)[26])c2_inData)[c2_i108 +
        c2_i106];
    }

    c2_i106 += 2;
  }

  c2_i109 = 0;
  for (c2_i110 = 0; c2_i110 < 13; c2_i110++) {
    for (c2_i111 = 0; c2_i111 < 2; c2_i111++) {
      c2_u[c2_i111 + c2_i109] = c2_b_inData[c2_i111 + c2_i109];
    }

    c2_i109 += 2;
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 2, 2, 13), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static void c2_f_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[26])
{
  real_T c2_dv1[26];
  int32_T c2_i112;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv1, 1, 0, 0U, 1, 0U, 2, 2, 13);
  for (c2_i112 = 0; c2_i112 < 26; c2_i112++) {
    c2_y[c2_i112] = c2_dv1[c2_i112];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_Evec;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y[26];
  int32_T c2_i113;
  int32_T c2_i114;
  int32_T c2_i115;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_Evec = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_Evec), &c2_thisId, c2_y);
  sf_mex_destroy(&c2_Evec);
  c2_i113 = 0;
  for (c2_i114 = 0; c2_i114 < 13; c2_i114++) {
    for (c2_i115 = 0; c2_i115 < 2; c2_i115++) {
      (*(real_T (*)[26])c2_outData)[c2_i115 + c2_i113] = c2_y[c2_i115 + c2_i113];
    }

    c2_i113 += 2;
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_h_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_i116;
  real_T c2_b_inData[52];
  int32_T c2_i117;
  real_T c2_u[52];
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  for (c2_i116 = 0; c2_i116 < 52; c2_i116++) {
    c2_b_inData[c2_i116] = (*(real_T (*)[52])c2_inData)[c2_i116];
  }

  for (c2_i117 = 0; c2_i117 < 52; c2_i117++) {
    c2_u[c2_i117] = c2_b_inData[c2_i117];
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 2, 1, 52), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static void c2_g_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[52])
{
  real_T c2_dv2[52];
  int32_T c2_i118;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv2, 1, 0, 0U, 1, 0U, 2, 1, 52);
  for (c2_i118 = 0; c2_i118 < 52; c2_i118++) {
    c2_y[c2_i118] = c2_dv2[c2_i118];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_thetaRvec;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y[52];
  int32_T c2_i119;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_thetaRvec = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_thetaRvec), &c2_thisId,
                        c2_y);
  sf_mex_destroy(&c2_thetaRvec);
  for (c2_i119 = 0; c2_i119 < 52; c2_i119++) {
    (*(real_T (*)[52])c2_outData)[c2_i119] = c2_y[c2_i119];
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

const mxArray
  *sf_c2_laneKeepingArcSplinesFF_2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo;
  c2_ResolvedFunctionInfo c2_info[80];
  const mxArray *c2_m0 = NULL;
  int32_T c2_i120;
  c2_ResolvedFunctionInfo *c2_r0;
  c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  c2_info_helper(c2_info);
  c2_b_info_helper(c2_info);
  sf_mex_assign(&c2_m0, sf_mex_createstruct("nameCaptureInfo", 1, 80), FALSE);
  for (c2_i120 = 0; c2_i120 < 80; c2_i120++) {
    c2_r0 = &c2_info[c2_i120];
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c2_r0->context)), "context", "nameCaptureInfo",
                    c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c2_r0->name)), "name", "nameCaptureInfo", c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c2_r0->dominantType)), "dominantType",
                    "nameCaptureInfo", c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c2_r0->resolved)), "resolved", "nameCaptureInfo",
                    c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->mFileTimeLo,
      7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo", c2_i120);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->mFileTimeHi,
      7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo", c2_i120);
  }

  sf_mex_assign(&c2_nameCaptureInfo, c2_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c2_nameCaptureInfo);
  return c2_nameCaptureInfo;
}

static void c2_info_helper(c2_ResolvedFunctionInfo c2_info[80])
{
  c2_info[0].context = "";
  c2_info[0].name = "length";
  c2_info[0].dominantType = "double";
  c2_info[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/length.m";
  c2_info[0].fileTimeLo = 1303142606U;
  c2_info[0].fileTimeHi = 0U;
  c2_info[0].mFileTimeLo = 0U;
  c2_info[0].mFileTimeHi = 0U;
  c2_info[1].context = "";
  c2_info[1].name = "sign";
  c2_info[1].dominantType = "double";
  c2_info[1].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c2_info[1].fileTimeLo = 1354364464U;
  c2_info[1].fileTimeHi = 0U;
  c2_info[1].mFileTimeLo = 0U;
  c2_info[1].mFileTimeHi = 0U;
  c2_info[2].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c2_info[2].name = "eml_scalar_sign";
  c2_info[2].dominantType = "double";
  c2_info[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sign.m";
  c2_info[2].fileTimeLo = 1354364464U;
  c2_info[2].fileTimeHi = 0U;
  c2_info[2].mFileTimeLo = 0U;
  c2_info[2].mFileTimeHi = 0U;
  c2_info[3].context = "";
  c2_info[3].name = "mtimes";
  c2_info[3].dominantType = "double";
  c2_info[3].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[3].fileTimeLo = 1289516092U;
  c2_info[3].fileTimeHi = 0U;
  c2_info[3].mFileTimeLo = 0U;
  c2_info[3].mFileTimeHi = 0U;
  c2_info[4].context = "";
  c2_info[4].name = "atan2";
  c2_info[4].dominantType = "double";
  c2_info[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c2_info[4].fileTimeLo = 1343826772U;
  c2_info[4].fileTimeHi = 0U;
  c2_info[4].mFileTimeLo = 0U;
  c2_info[4].mFileTimeHi = 0U;
  c2_info[5].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c2_info[5].name = "eml_scalar_eg";
  c2_info[5].dominantType = "double";
  c2_info[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[5].fileTimeLo = 1286815196U;
  c2_info[5].fileTimeHi = 0U;
  c2_info[5].mFileTimeLo = 0U;
  c2_info[5].mFileTimeHi = 0U;
  c2_info[6].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c2_info[6].name = "eml_scalexp_alloc";
  c2_info[6].dominantType = "double";
  c2_info[6].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c2_info[6].fileTimeLo = 1352421260U;
  c2_info[6].fileTimeHi = 0U;
  c2_info[6].mFileTimeLo = 0U;
  c2_info[6].mFileTimeHi = 0U;
  c2_info[7].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c2_info[7].name = "eml_scalar_atan2";
  c2_info[7].dominantType = "double";
  c2_info[7].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_atan2.m";
  c2_info[7].fileTimeLo = 1286815120U;
  c2_info[7].fileTimeHi = 0U;
  c2_info[7].mFileTimeLo = 0U;
  c2_info[7].mFileTimeHi = 0U;
  c2_info[8].context = "";
  c2_info[8].name = "mod";
  c2_info[8].dominantType = "double";
  c2_info[8].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c2_info[8].fileTimeLo = 1343826782U;
  c2_info[8].fileTimeHi = 0U;
  c2_info[8].mFileTimeLo = 0U;
  c2_info[8].mFileTimeHi = 0U;
  c2_info[9].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c2_info[9].name = "eml_scalar_eg";
  c2_info[9].dominantType = "double";
  c2_info[9].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[9].fileTimeLo = 1286815196U;
  c2_info[9].fileTimeHi = 0U;
  c2_info[9].mFileTimeLo = 0U;
  c2_info[9].mFileTimeHi = 0U;
  c2_info[10].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c2_info[10].name = "eml_scalexp_alloc";
  c2_info[10].dominantType = "double";
  c2_info[10].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c2_info[10].fileTimeLo = 1352421260U;
  c2_info[10].fileTimeHi = 0U;
  c2_info[10].mFileTimeLo = 0U;
  c2_info[10].mFileTimeHi = 0U;
  c2_info[11].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[11].name = "eml_scalar_eg";
  c2_info[11].dominantType = "double";
  c2_info[11].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[11].fileTimeLo = 1286815196U;
  c2_info[11].fileTimeHi = 0U;
  c2_info[11].mFileTimeLo = 0U;
  c2_info[11].mFileTimeHi = 0U;
  c2_info[12].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[12].name = "eml_scalar_floor";
  c2_info[12].dominantType = "double";
  c2_info[12].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c2_info[12].fileTimeLo = 1286815126U;
  c2_info[12].fileTimeHi = 0U;
  c2_info[12].mFileTimeLo = 0U;
  c2_info[12].mFileTimeHi = 0U;
  c2_info[13].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[13].name = "eml_scalar_round";
  c2_info[13].dominantType = "double";
  c2_info[13].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_round.m";
  c2_info[13].fileTimeLo = 1307647638U;
  c2_info[13].fileTimeHi = 0U;
  c2_info[13].mFileTimeLo = 0U;
  c2_info[13].mFileTimeHi = 0U;
  c2_info[14].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[14].name = "eml_scalar_abs";
  c2_info[14].dominantType = "double";
  c2_info[14].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c2_info[14].fileTimeLo = 1286815112U;
  c2_info[14].fileTimeHi = 0U;
  c2_info[14].mFileTimeLo = 0U;
  c2_info[14].mFileTimeHi = 0U;
  c2_info[15].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[15].name = "eps";
  c2_info[15].dominantType = "char";
  c2_info[15].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c2_info[15].fileTimeLo = 1326724396U;
  c2_info[15].fileTimeHi = 0U;
  c2_info[15].mFileTimeLo = 0U;
  c2_info[15].mFileTimeHi = 0U;
  c2_info[16].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c2_info[16].name = "eml_is_float_class";
  c2_info[16].dominantType = "char";
  c2_info[16].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_is_float_class.m";
  c2_info[16].fileTimeLo = 1286815182U;
  c2_info[16].fileTimeHi = 0U;
  c2_info[16].mFileTimeLo = 0U;
  c2_info[16].mFileTimeHi = 0U;
  c2_info[17].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c2_info[17].name = "eml_eps";
  c2_info[17].dominantType = "char";
  c2_info[17].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_eps.m";
  c2_info[17].fileTimeLo = 1326724396U;
  c2_info[17].fileTimeHi = 0U;
  c2_info[17].mFileTimeLo = 0U;
  c2_info[17].mFileTimeHi = 0U;
  c2_info[18].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_eps.m";
  c2_info[18].name = "eml_float_model";
  c2_info[18].dominantType = "char";
  c2_info[18].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_float_model.m";
  c2_info[18].fileTimeLo = 1326724396U;
  c2_info[18].fileTimeHi = 0U;
  c2_info[18].mFileTimeLo = 0U;
  c2_info[18].mFileTimeHi = 0U;
  c2_info[19].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c2_info[19].name = "mtimes";
  c2_info[19].dominantType = "double";
  c2_info[19].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[19].fileTimeLo = 1289516092U;
  c2_info[19].fileTimeHi = 0U;
  c2_info[19].mFileTimeLo = 0U;
  c2_info[19].mFileTimeHi = 0U;
  c2_info[20].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[20].name = "eml_index_class";
  c2_info[20].dominantType = "";
  c2_info[20].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[20].fileTimeLo = 1323166978U;
  c2_info[20].fileTimeHi = 0U;
  c2_info[20].mFileTimeLo = 0U;
  c2_info[20].mFileTimeHi = 0U;
  c2_info[21].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[21].name = "eml_scalar_eg";
  c2_info[21].dominantType = "double";
  c2_info[21].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[21].fileTimeLo = 1286815196U;
  c2_info[21].fileTimeHi = 0U;
  c2_info[21].mFileTimeLo = 0U;
  c2_info[21].mFileTimeHi = 0U;
  c2_info[22].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[22].name = "eml_xdotu";
  c2_info[22].dominantType = "double";
  c2_info[22].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c2_info[22].fileTimeLo = 1299073172U;
  c2_info[22].fileTimeHi = 0U;
  c2_info[22].mFileTimeLo = 0U;
  c2_info[22].mFileTimeHi = 0U;
  c2_info[23].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c2_info[23].name = "eml_blas_inline";
  c2_info[23].dominantType = "";
  c2_info[23].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c2_info[23].fileTimeLo = 1299073168U;
  c2_info[23].fileTimeHi = 0U;
  c2_info[23].mFileTimeLo = 0U;
  c2_info[23].mFileTimeHi = 0U;
  c2_info[24].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c2_info[24].name = "eml_xdot";
  c2_info[24].dominantType = "double";
  c2_info[24].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdot.m";
  c2_info[24].fileTimeLo = 1299073172U;
  c2_info[24].fileTimeHi = 0U;
  c2_info[24].mFileTimeLo = 0U;
  c2_info[24].mFileTimeHi = 0U;
  c2_info[25].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdot.m";
  c2_info[25].name = "eml_blas_inline";
  c2_info[25].dominantType = "";
  c2_info[25].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c2_info[25].fileTimeLo = 1299073168U;
  c2_info[25].fileTimeHi = 0U;
  c2_info[25].mFileTimeLo = 0U;
  c2_info[25].mFileTimeHi = 0U;
  c2_info[26].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xdot.m";
  c2_info[26].name = "eml_index_class";
  c2_info[26].dominantType = "";
  c2_info[26].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[26].fileTimeLo = 1323166978U;
  c2_info[26].fileTimeHi = 0U;
  c2_info[26].mFileTimeLo = 0U;
  c2_info[26].mFileTimeHi = 0U;
  c2_info[27].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xdot.m";
  c2_info[27].name = "eml_refblas_xdot";
  c2_info[27].dominantType = "double";
  c2_info[27].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdot.m";
  c2_info[27].fileTimeLo = 1299073172U;
  c2_info[27].fileTimeHi = 0U;
  c2_info[27].mFileTimeLo = 0U;
  c2_info[27].mFileTimeHi = 0U;
  c2_info[28].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdot.m";
  c2_info[28].name = "eml_refblas_xdotx";
  c2_info[28].dominantType = "char";
  c2_info[28].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[28].fileTimeLo = 1299073174U;
  c2_info[28].fileTimeHi = 0U;
  c2_info[28].mFileTimeLo = 0U;
  c2_info[28].mFileTimeHi = 0U;
  c2_info[29].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[29].name = "eml_scalar_eg";
  c2_info[29].dominantType = "double";
  c2_info[29].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[29].fileTimeLo = 1286815196U;
  c2_info[29].fileTimeHi = 0U;
  c2_info[29].mFileTimeLo = 0U;
  c2_info[29].mFileTimeHi = 0U;
  c2_info[30].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[30].name = "eml_index_class";
  c2_info[30].dominantType = "";
  c2_info[30].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[30].fileTimeLo = 1323166978U;
  c2_info[30].fileTimeHi = 0U;
  c2_info[30].mFileTimeLo = 0U;
  c2_info[30].mFileTimeHi = 0U;
  c2_info[31].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[31].name = "eml_index_minus";
  c2_info[31].dominantType = "double";
  c2_info[31].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c2_info[31].fileTimeLo = 1286815178U;
  c2_info[31].fileTimeHi = 0U;
  c2_info[31].mFileTimeLo = 0U;
  c2_info[31].mFileTimeHi = 0U;
  c2_info[32].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c2_info[32].name = "eml_index_class";
  c2_info[32].dominantType = "";
  c2_info[32].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[32].fileTimeLo = 1323166978U;
  c2_info[32].fileTimeHi = 0U;
  c2_info[32].mFileTimeLo = 0U;
  c2_info[32].mFileTimeHi = 0U;
  c2_info[33].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[33].name = "eml_index_times";
  c2_info[33].dominantType = "coder.internal.indexInt";
  c2_info[33].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c2_info[33].fileTimeLo = 1286815180U;
  c2_info[33].fileTimeHi = 0U;
  c2_info[33].mFileTimeLo = 0U;
  c2_info[33].mFileTimeHi = 0U;
  c2_info[34].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c2_info[34].name = "eml_index_class";
  c2_info[34].dominantType = "";
  c2_info[34].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[34].fileTimeLo = 1323166978U;
  c2_info[34].fileTimeHi = 0U;
  c2_info[34].mFileTimeLo = 0U;
  c2_info[34].mFileTimeHi = 0U;
  c2_info[35].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[35].name = "eml_index_plus";
  c2_info[35].dominantType = "coder.internal.indexInt";
  c2_info[35].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c2_info[35].fileTimeLo = 1286815178U;
  c2_info[35].fileTimeHi = 0U;
  c2_info[35].mFileTimeLo = 0U;
  c2_info[35].mFileTimeHi = 0U;
  c2_info[36].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c2_info[36].name = "eml_index_class";
  c2_info[36].dominantType = "";
  c2_info[36].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[36].fileTimeLo = 1323166978U;
  c2_info[36].fileTimeHi = 0U;
  c2_info[36].mFileTimeLo = 0U;
  c2_info[36].mFileTimeHi = 0U;
  c2_info[37].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c2_info[37].name = "eml_int_forloop_overflow_check";
  c2_info[37].dominantType = "";
  c2_info[37].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m";
  c2_info[37].fileTimeLo = 1346506740U;
  c2_info[37].fileTimeHi = 0U;
  c2_info[37].mFileTimeLo = 0U;
  c2_info[37].mFileTimeHi = 0U;
  c2_info[38].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m!eml_int_forloop_overflow_check_helper";
  c2_info[38].name = "intmax";
  c2_info[38].dominantType = "char";
  c2_info[38].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m";
  c2_info[38].fileTimeLo = 1311251716U;
  c2_info[38].fileTimeHi = 0U;
  c2_info[38].mFileTimeLo = 0U;
  c2_info[38].mFileTimeHi = 0U;
  c2_info[39].context = "";
  c2_info[39].name = "sqrt";
  c2_info[39].dominantType = "double";
  c2_info[39].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c2_info[39].fileTimeLo = 1343826786U;
  c2_info[39].fileTimeHi = 0U;
  c2_info[39].mFileTimeLo = 0U;
  c2_info[39].mFileTimeHi = 0U;
  c2_info[40].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c2_info[40].name = "eml_error";
  c2_info[40].dominantType = "char";
  c2_info[40].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c2_info[40].fileTimeLo = 1343826758U;
  c2_info[40].fileTimeHi = 0U;
  c2_info[40].mFileTimeLo = 0U;
  c2_info[40].mFileTimeHi = 0U;
  c2_info[41].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c2_info[41].name = "eml_scalar_sqrt";
  c2_info[41].dominantType = "double";
  c2_info[41].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c2_info[41].fileTimeLo = 1286815138U;
  c2_info[41].fileTimeHi = 0U;
  c2_info[41].mFileTimeLo = 0U;
  c2_info[41].mFileTimeHi = 0U;
  c2_info[42].context = "";
  c2_info[42].name = "mrdivide";
  c2_info[42].dominantType = "double";
  c2_info[42].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c2_info[42].fileTimeLo = 1357947948U;
  c2_info[42].fileTimeHi = 0U;
  c2_info[42].mFileTimeLo = 1319726366U;
  c2_info[42].mFileTimeHi = 0U;
  c2_info[43].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c2_info[43].name = "rdivide";
  c2_info[43].dominantType = "double";
  c2_info[43].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c2_info[43].fileTimeLo = 1346506788U;
  c2_info[43].fileTimeHi = 0U;
  c2_info[43].mFileTimeLo = 0U;
  c2_info[43].mFileTimeHi = 0U;
  c2_info[44].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c2_info[44].name = "eml_scalexp_compatible";
  c2_info[44].dominantType = "double";
  c2_info[44].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  c2_info[44].fileTimeLo = 1286815196U;
  c2_info[44].fileTimeHi = 0U;
  c2_info[44].mFileTimeLo = 0U;
  c2_info[44].mFileTimeHi = 0U;
  c2_info[45].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c2_info[45].name = "eml_div";
  c2_info[45].dominantType = "double";
  c2_info[45].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c2_info[45].fileTimeLo = 1313344210U;
  c2_info[45].fileTimeHi = 0U;
  c2_info[45].mFileTimeLo = 0U;
  c2_info[45].mFileTimeHi = 0U;
  c2_info[46].context = "";
  c2_info[46].name = "abs";
  c2_info[46].dominantType = "double";
  c2_info[46].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c2_info[46].fileTimeLo = 1343826766U;
  c2_info[46].fileTimeHi = 0U;
  c2_info[46].mFileTimeLo = 0U;
  c2_info[46].mFileTimeHi = 0U;
  c2_info[47].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c2_info[47].name = "eml_scalar_abs";
  c2_info[47].dominantType = "double";
  c2_info[47].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c2_info[47].fileTimeLo = 1286815112U;
  c2_info[47].fileTimeHi = 0U;
  c2_info[47].mFileTimeLo = 0U;
  c2_info[47].mFileTimeHi = 0U;
  c2_info[48].context = "";
  c2_info[48].name = "norm";
  c2_info[48].dominantType = "double";
  c2_info[48].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m";
  c2_info[48].fileTimeLo = 1336518494U;
  c2_info[48].fileTimeHi = 0U;
  c2_info[48].mFileTimeLo = 0U;
  c2_info[48].mFileTimeHi = 0U;
  c2_info[49].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m!genpnorm";
  c2_info[49].name = "eml_index_class";
  c2_info[49].dominantType = "";
  c2_info[49].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[49].fileTimeLo = 1323166978U;
  c2_info[49].fileTimeHi = 0U;
  c2_info[49].mFileTimeLo = 0U;
  c2_info[49].mFileTimeHi = 0U;
  c2_info[50].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m!genpnorm";
  c2_info[50].name = "eml_xnrm2";
  c2_info[50].dominantType = "double";
  c2_info[50].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xnrm2.m";
  c2_info[50].fileTimeLo = 1299073176U;
  c2_info[50].fileTimeHi = 0U;
  c2_info[50].mFileTimeLo = 0U;
  c2_info[50].mFileTimeHi = 0U;
  c2_info[51].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xnrm2.m";
  c2_info[51].name = "eml_blas_inline";
  c2_info[51].dominantType = "";
  c2_info[51].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c2_info[51].fileTimeLo = 1299073168U;
  c2_info[51].fileTimeHi = 0U;
  c2_info[51].mFileTimeLo = 0U;
  c2_info[51].mFileTimeHi = 0U;
  c2_info[52].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xnrm2.m";
  c2_info[52].name = "eml_index_class";
  c2_info[52].dominantType = "";
  c2_info[52].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[52].fileTimeLo = 1323166978U;
  c2_info[52].fileTimeHi = 0U;
  c2_info[52].mFileTimeLo = 0U;
  c2_info[52].mFileTimeHi = 0U;
  c2_info[53].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xnrm2.m";
  c2_info[53].name = "eml_refblas_xnrm2";
  c2_info[53].dominantType = "double";
  c2_info[53].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[53].fileTimeLo = 1299073184U;
  c2_info[53].fileTimeHi = 0U;
  c2_info[53].mFileTimeLo = 0U;
  c2_info[53].mFileTimeHi = 0U;
  c2_info[54].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[54].name = "realmin";
  c2_info[54].dominantType = "char";
  c2_info[54].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/realmin.m";
  c2_info[54].fileTimeLo = 1307647642U;
  c2_info[54].fileTimeHi = 0U;
  c2_info[54].mFileTimeLo = 0U;
  c2_info[54].mFileTimeHi = 0U;
  c2_info[55].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/realmin.m";
  c2_info[55].name = "eml_realmin";
  c2_info[55].dominantType = "char";
  c2_info[55].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_realmin.m";
  c2_info[55].fileTimeLo = 1307647644U;
  c2_info[55].fileTimeHi = 0U;
  c2_info[55].mFileTimeLo = 0U;
  c2_info[55].mFileTimeHi = 0U;
  c2_info[56].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_realmin.m";
  c2_info[56].name = "eml_float_model";
  c2_info[56].dominantType = "char";
  c2_info[56].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_float_model.m";
  c2_info[56].fileTimeLo = 1326724396U;
  c2_info[56].fileTimeHi = 0U;
  c2_info[56].mFileTimeLo = 0U;
  c2_info[56].mFileTimeHi = 0U;
  c2_info[57].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[57].name = "eml_index_class";
  c2_info[57].dominantType = "";
  c2_info[57].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[57].fileTimeLo = 1323166978U;
  c2_info[57].fileTimeHi = 0U;
  c2_info[57].mFileTimeLo = 0U;
  c2_info[57].mFileTimeHi = 0U;
  c2_info[58].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[58].name = "eml_index_minus";
  c2_info[58].dominantType = "double";
  c2_info[58].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c2_info[58].fileTimeLo = 1286815178U;
  c2_info[58].fileTimeHi = 0U;
  c2_info[58].mFileTimeLo = 0U;
  c2_info[58].mFileTimeHi = 0U;
  c2_info[59].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[59].name = "eml_index_times";
  c2_info[59].dominantType = "coder.internal.indexInt";
  c2_info[59].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c2_info[59].fileTimeLo = 1286815180U;
  c2_info[59].fileTimeHi = 0U;
  c2_info[59].mFileTimeLo = 0U;
  c2_info[59].mFileTimeHi = 0U;
  c2_info[60].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[60].name = "eml_index_plus";
  c2_info[60].dominantType = "coder.internal.indexInt";
  c2_info[60].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c2_info[60].fileTimeLo = 1286815178U;
  c2_info[60].fileTimeHi = 0U;
  c2_info[60].mFileTimeLo = 0U;
  c2_info[60].mFileTimeHi = 0U;
  c2_info[61].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[61].name = "eml_int_forloop_overflow_check";
  c2_info[61].dominantType = "";
  c2_info[61].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m";
  c2_info[61].fileTimeLo = 1346506740U;
  c2_info[61].fileTimeHi = 0U;
  c2_info[61].mFileTimeLo = 0U;
  c2_info[61].mFileTimeHi = 0U;
  c2_info[62].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c2_info[62].name = "abs";
  c2_info[62].dominantType = "double";
  c2_info[62].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c2_info[62].fileTimeLo = 1343826766U;
  c2_info[62].fileTimeHi = 0U;
  c2_info[62].mFileTimeLo = 0U;
  c2_info[62].mFileTimeHi = 0U;
  c2_info[63].context = "";
  c2_info[63].name = "mpower";
  c2_info[63].dominantType = "double";
  c2_info[63].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c2_info[63].fileTimeLo = 1286815242U;
  c2_info[63].fileTimeHi = 0U;
  c2_info[63].mFileTimeLo = 0U;
  c2_info[63].mFileTimeHi = 0U;
}

static void c2_b_info_helper(c2_ResolvedFunctionInfo c2_info[80])
{
  c2_info[64].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c2_info[64].name = "power";
  c2_info[64].dominantType = "double";
  c2_info[64].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  c2_info[64].fileTimeLo = 1348188330U;
  c2_info[64].fileTimeHi = 0U;
  c2_info[64].mFileTimeLo = 0U;
  c2_info[64].mFileTimeHi = 0U;
  c2_info[65].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c2_info[65].name = "eml_scalar_eg";
  c2_info[65].dominantType = "double";
  c2_info[65].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[65].fileTimeLo = 1286815196U;
  c2_info[65].fileTimeHi = 0U;
  c2_info[65].mFileTimeLo = 0U;
  c2_info[65].mFileTimeHi = 0U;
  c2_info[66].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c2_info[66].name = "eml_scalexp_alloc";
  c2_info[66].dominantType = "double";
  c2_info[66].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c2_info[66].fileTimeLo = 1352421260U;
  c2_info[66].fileTimeHi = 0U;
  c2_info[66].mFileTimeLo = 0U;
  c2_info[66].mFileTimeHi = 0U;
  c2_info[67].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c2_info[67].name = "floor";
  c2_info[67].dominantType = "double";
  c2_info[67].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c2_info[67].fileTimeLo = 1343826780U;
  c2_info[67].fileTimeHi = 0U;
  c2_info[67].mFileTimeLo = 0U;
  c2_info[67].mFileTimeHi = 0U;
  c2_info[68].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c2_info[68].name = "eml_scalar_floor";
  c2_info[68].dominantType = "double";
  c2_info[68].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c2_info[68].fileTimeLo = 1286815126U;
  c2_info[68].fileTimeHi = 0U;
  c2_info[68].mFileTimeLo = 0U;
  c2_info[68].mFileTimeHi = 0U;
  c2_info[69].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c2_info[69].name = "eml_scalar_eg";
  c2_info[69].dominantType = "double";
  c2_info[69].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[69].fileTimeLo = 1286815196U;
  c2_info[69].fileTimeHi = 0U;
  c2_info[69].mFileTimeLo = 0U;
  c2_info[69].mFileTimeHi = 0U;
  c2_info[70].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c2_info[70].name = "mtimes";
  c2_info[70].dominantType = "double";
  c2_info[70].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c2_info[70].fileTimeLo = 1289516092U;
  c2_info[70].fileTimeHi = 0U;
  c2_info[70].mFileTimeLo = 0U;
  c2_info[70].mFileTimeHi = 0U;
  c2_info[71].context = "";
  c2_info[71].name = "find";
  c2_info[71].dominantType = "logical";
  c2_info[71].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/find.m";
  c2_info[71].fileTimeLo = 1303142606U;
  c2_info[71].fileTimeHi = 0U;
  c2_info[71].mFileTimeLo = 0U;
  c2_info[71].mFileTimeHi = 0U;
  c2_info[72].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/find.m!eml_find";
  c2_info[72].name = "eml_index_class";
  c2_info[72].dominantType = "";
  c2_info[72].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c2_info[72].fileTimeLo = 1323166978U;
  c2_info[72].fileTimeHi = 0U;
  c2_info[72].mFileTimeLo = 0U;
  c2_info[72].mFileTimeHi = 0U;
  c2_info[73].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/find.m!eml_find";
  c2_info[73].name = "eml_scalar_eg";
  c2_info[73].dominantType = "logical";
  c2_info[73].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c2_info[73].fileTimeLo = 1286815196U;
  c2_info[73].fileTimeHi = 0U;
  c2_info[73].mFileTimeLo = 0U;
  c2_info[73].mFileTimeHi = 0U;
  c2_info[74].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/find.m!eml_find";
  c2_info[74].name = "eml_int_forloop_overflow_check";
  c2_info[74].dominantType = "";
  c2_info[74].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m";
  c2_info[74].fileTimeLo = 1346506740U;
  c2_info[74].fileTimeHi = 0U;
  c2_info[74].mFileTimeLo = 0U;
  c2_info[74].mFileTimeHi = 0U;
  c2_info[75].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/find.m!eml_find";
  c2_info[75].name = "eml_index_plus";
  c2_info[75].dominantType = "double";
  c2_info[75].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c2_info[75].fileTimeLo = 1286815178U;
  c2_info[75].fileTimeHi = 0U;
  c2_info[75].mFileTimeLo = 0U;
  c2_info[75].mFileTimeHi = 0U;
  c2_info[76].context = "";
  c2_info[76].name = "cos";
  c2_info[76].dominantType = "double";
  c2_info[76].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c2_info[76].fileTimeLo = 1343826772U;
  c2_info[76].fileTimeHi = 0U;
  c2_info[76].mFileTimeLo = 0U;
  c2_info[76].mFileTimeHi = 0U;
  c2_info[77].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c2_info[77].name = "eml_scalar_cos";
  c2_info[77].dominantType = "double";
  c2_info[77].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c2_info[77].fileTimeLo = 1286815122U;
  c2_info[77].fileTimeHi = 0U;
  c2_info[77].mFileTimeLo = 0U;
  c2_info[77].mFileTimeHi = 0U;
  c2_info[78].context = "";
  c2_info[78].name = "sin";
  c2_info[78].dominantType = "double";
  c2_info[78].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c2_info[78].fileTimeLo = 1343826786U;
  c2_info[78].fileTimeHi = 0U;
  c2_info[78].mFileTimeLo = 0U;
  c2_info[78].mFileTimeHi = 0U;
  c2_info[79].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c2_info[79].name = "eml_scalar_sin";
  c2_info[79].dominantType = "double";
  c2_info[79].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m";
  c2_info[79].fileTimeLo = 1286815136U;
  c2_info[79].fileTimeHi = 0U;
  c2_info[79].mFileTimeLo = 0U;
  c2_info[79].mFileTimeHi = 0U;
}

static real_T c2_sign(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x)
{
  real_T c2_b_x;
  c2_b_x = c2_x;
  c2_b_sign(chartInstance, &c2_b_x);
  return c2_b_x;
}

static real_T c2_atan2(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance, real_T c2_y, real_T c2_x)
{
  real_T c2_b_y;
  real_T c2_b_x;
  c2_eml_scalar_eg(chartInstance);
  c2_b_y = c2_y;
  c2_b_x = c2_x;
  return muDoubleScalarAtan2(c2_b_y, c2_b_x);
}

static void c2_eml_scalar_eg(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance)
{
}

static real_T c2_mod(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                     *chartInstance, real_T c2_x, real_T c2_y)
{
  real_T c2_r;
  real_T c2_xk;
  real_T c2_b_x;
  real_T c2_c_x;
  real_T c2_d_x;
  real_T c2_e_x;
  real_T c2_b_y;
  real_T c2_f_x;
  real_T c2_c_y;
  real_T c2_b;
  real_T c2_d_y;
  real_T c2_g_x;
  real_T c2_h_x;
  c2_eml_scalar_eg(chartInstance);
  c2_xk = c2_x;
  c2_b_x = c2_xk;
  c2_eml_scalar_eg(chartInstance);
  c2_r = c2_b_x / 6.2831853071795862;
  c2_c_x = c2_r;
  c2_d_x = c2_c_x;
  c2_d_x = muDoubleScalarRound(c2_d_x);
  c2_e_x = c2_r - c2_d_x;
  c2_b_y = muDoubleScalarAbs(c2_e_x);
  c2_f_x = c2_r;
  c2_c_y = muDoubleScalarAbs(c2_f_x);
  c2_b = c2_c_y;
  c2_d_y = 2.2204460492503131E-16 * c2_b;
  if (c2_b_y <= c2_d_y) {
    c2_r = 0.0;
  } else {
    c2_g_x = c2_r;
    c2_h_x = c2_g_x;
    c2_h_x = muDoubleScalarFloor(c2_h_x);
    c2_r = (c2_r - c2_h_x) * 6.2831853071795862;
  }

  return c2_r;
}

static void c2_b_eml_scalar_eg(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *
  chartInstance)
{
}

static real_T c2_sqrt(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x)
{
  real_T c2_b_x;
  c2_b_x = c2_x;
  c2_b_sqrt(chartInstance, &c2_b_x);
  return c2_b_x;
}

static void c2_eml_error(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance)
{
  int32_T c2_i121;
  static char_T c2_cv0[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  char_T c2_u[30];
  const mxArray *c2_y = NULL;
  int32_T c2_i122;
  static char_T c2_cv1[4] = { 's', 'q', 'r', 't' };

  char_T c2_b_u[4];
  const mxArray *c2_b_y = NULL;
  for (c2_i121 = 0; c2_i121 < 30; c2_i121++) {
    c2_u[c2_i121] = c2_cv0[c2_i121];
  }

  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 10, 0U, 1U, 0U, 2, 1, 30), FALSE);
  for (c2_i122 = 0; c2_i122 < 4; c2_i122++) {
    c2_b_u[c2_i122] = c2_cv1[c2_i122];
  }

  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 2U, 14,
    c2_y, 14, c2_b_y));
}

static real_T c2_abs(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                     *chartInstance, real_T c2_x)
{
  real_T c2_b_x;
  c2_b_x = c2_x;
  return muDoubleScalarAbs(c2_b_x);
}

static real_T c2_norm(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T c2_x[2])
{
  real_T c2_y;
  real_T c2_scale;
  int32_T c2_k;
  int32_T c2_b_k;
  real_T c2_b_x;
  real_T c2_c_x;
  real_T c2_absxk;
  real_T c2_t;
  c2_y = 0.0;
  c2_scale = 2.2250738585072014E-308;
  for (c2_k = 1; c2_k < 3; c2_k++) {
    c2_b_k = c2_k - 1;
    c2_b_x = c2_x[c2_b_k];
    c2_c_x = c2_b_x;
    c2_absxk = muDoubleScalarAbs(c2_c_x);
    if (c2_absxk > c2_scale) {
      c2_t = c2_scale / c2_absxk;
      c2_y = 1.0 + c2_y * c2_t * c2_t;
      c2_scale = c2_absxk;
    } else {
      c2_t = c2_absxk / c2_scale;
      c2_y += c2_t * c2_t;
    }
  }

  return c2_scale * muDoubleScalarSqrt(c2_y);
}

static real_T c2_mpower(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
  *chartInstance, real_T c2_a)
{
  real_T c2_b_a;
  real_T c2_c_a;
  real_T c2_ak;
  real_T c2_d_a;
  real_T c2_e_a;
  real_T c2_b;
  c2_b_a = c2_a;
  c2_c_a = c2_b_a;
  c2_eml_scalar_eg(chartInstance);
  c2_ak = c2_c_a;
  c2_d_a = c2_ak;
  c2_eml_scalar_eg(chartInstance);
  c2_e_a = c2_d_a;
  c2_b = c2_d_a;
  return c2_e_a * c2_b;
}

static const mxArray *c2_i_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  int32_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_u = *(int32_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, FALSE);
  return c2_mxArrayOutData;
}

static int32_T c2_h_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  int32_T c2_y;
  int32_T c2_i123;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_i123, 1, 6, 0U, 0, 0U, 0);
  c2_y = c2_i123;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_sfEvent;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_y;
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
    chartInstanceVoid;
  c2_b_sfEvent = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_y = c2_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_sfEvent),
    &c2_thisId);
  sf_mex_destroy(&c2_b_sfEvent);
  *(int32_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static uint8_T c2_i_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_b_is_active_c2_laneKeepingArcSplinesFF_2013a, const char_T
   *c2_identifier)
{
  uint8_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_y = c2_j_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_is_active_c2_laneKeepingArcSplinesFF_2013a), &c2_thisId);
  sf_mex_destroy(&c2_b_is_active_c2_laneKeepingArcSplinesFF_2013a);
  return c2_y;
}

static uint8_T c2_j_emlrt_marshallIn
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_y;
  uint8_T c2_u0;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_u0, 1, 3, 0U, 0, 0U, 0);
  c2_y = c2_u0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_b_sign(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T *c2_x)
{
  *c2_x = muDoubleScalarSign(*c2_x);
}

static void c2_b_sqrt(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct
                      *chartInstance, real_T *c2_x)
{
  if (*c2_x < 0.0) {
    c2_eml_error(chartInstance);
  }

  *c2_x = muDoubleScalarSqrt(*c2_x);
}

static void init_dsm_address_info
  (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c2_laneKeepingArcSplinesFF_2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2822243977U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3628276002U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1975009143U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1172246548U);
}

mxArray *sf_c2_laneKeepingArcSplinesFF_2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("YzgY9KoqlHYF6Sog7VWc6E");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,10,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(6);
      pr[1] = (double)(52);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(5);
      pr[1] = (double)(13);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,8,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,8,"type",mxType);
    }

    mxSetField(mxData,8,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,9,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,9,"type",mxType);
    }

    mxSetField(mxData,9,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,12,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,8,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,8,"type",mxType);
    }

    mxSetField(mxData,8,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,9,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,9,"type",mxType);
    }

    mxSetField(mxData,9,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,10,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,10,"type",mxType);
    }

    mxSetField(mxData,10,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,11,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,11,"type",mxType);
    }

    mxSetField(mxData,11,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c2_laneKeepingArcSplinesFF_2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c2_laneKeepingArcSplinesFF_2013a
  (void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x10'type','srcId','name','auxInfo'{{M[1],M[24],T\"PX\",},{M[1],M[25],T\"PY\",},{M[1],M[26],T\"Srem\",},{M[1],M[17],T\"deltaPsi\",},{M[1],M[20],T\"deltadPsi\",},{M[1],M[5],T\"dist\",},{M[1],M[16],T\"dist1\",},{M[1],M[27],T\"r\",},{M[1],M[21],T\"rho\",},{M[1],M[22],T\"rho1\",}}",
    "100 S1x3'type','srcId','name','auxInfo'{{M[1],M[29],T\"rho1new\",},{M[1],M[30],T\"segNum\",},{M[8],M[0],T\"is_active_c2_laneKeepingArcSplinesFF_2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 13, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_laneKeepingArcSplinesFF_2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
    chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF_2013aMachineNumber_,
           2,
           1,
           1,
           22,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF_2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF_2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF_2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"CircleData");
          _SFD_SET_DATA_PROPS(1,2,0,1,"dist");
          _SFD_SET_DATA_PROPS(2,1,1,0,"LineData");
          _SFD_SET_DATA_PROPS(3,1,1,0,"X1");
          _SFD_SET_DATA_PROPS(4,1,1,0,"Y1");
          _SFD_SET_DATA_PROPS(5,1,1,0,"Psi");
          _SFD_SET_DATA_PROPS(6,1,1,0,"dPsi");
          _SFD_SET_DATA_PROPS(7,1,1,0,"delta");
          _SFD_SET_DATA_PROPS(8,1,1,0,"vel");
          _SFD_SET_DATA_PROPS(9,1,1,0,"l_S");
          _SFD_SET_DATA_PROPS(10,2,0,1,"dist1");
          _SFD_SET_DATA_PROPS(11,2,0,1,"deltaPsi");
          _SFD_SET_DATA_PROPS(12,2,0,1,"deltadPsi");
          _SFD_SET_DATA_PROPS(13,2,0,1,"rho");
          _SFD_SET_DATA_PROPS(14,2,0,1,"rho1");
          _SFD_SET_DATA_PROPS(15,2,0,1,"PX");
          _SFD_SET_DATA_PROPS(16,2,0,1,"PY");
          _SFD_SET_DATA_PROPS(17,2,0,1,"r");
          _SFD_SET_DATA_PROPS(18,2,0,1,"Srem");
          _SFD_SET_DATA_PROPS(19,2,0,1,"rho1new");
          _SFD_SET_DATA_PROPS(20,2,0,1,"segNum");
          _SFD_SET_DATA_PROPS(21,1,1,0,"jMin");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,34,0,0,0,4,0,23,12);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,6763);
        _SFD_CV_INIT_EML_IF(0,1,0,785,815,1072,1340);
        _SFD_CV_INIT_EML_IF(0,1,1,824,848,956,1067);
        _SFD_CV_INIT_EML_IF(0,1,2,861,905,-1,947);
        _SFD_CV_INIT_EML_IF(0,1,3,972,1015,-1,1055);
        _SFD_CV_INIT_EML_IF(0,1,4,1085,1109,1217,1328);
        _SFD_CV_INIT_EML_IF(0,1,5,1122,1166,-1,1208);
        _SFD_CV_INIT_EML_IF(0,1,6,1233,1276,-1,1316);
        _SFD_CV_INIT_EML_IF(0,1,7,1560,1589,-1,2441);
        _SFD_CV_INIT_EML_IF(0,1,8,1769,1799,2014,2237);
        _SFD_CV_INIT_EML_IF(0,1,9,1832,1853,1928,2005);
        _SFD_CV_INIT_EML_IF(0,1,10,2051,2073,2143,2225);
        _SFD_CV_INIT_EML_IF(0,1,11,2648,2665,2688,3228);
        _SFD_CV_INIT_EML_IF(0,1,12,2729,2758,-1,3220);
        _SFD_CV_INIT_EML_IF(0,1,13,3282,3304,3321,3495);
        _SFD_CV_INIT_EML_IF(0,1,14,3383,3406,3433,3491);
        _SFD_CV_INIT_EML_IF(0,1,15,3567,3579,3840,4598);
        _SFD_CV_INIT_EML_IF(0,1,16,3585,3614,-1,3839);
        _SFD_CV_INIT_EML_IF(0,1,17,3849,3863,4011,4594);
        _SFD_CV_INIT_EML_IF(0,1,18,4011,4030,4267,4594);
        _SFD_CV_INIT_EML_IF(0,1,19,4904,4934,5187,5451);
        _SFD_CV_INIT_EML_IF(0,1,20,4943,4967,5073,5182);
        _SFD_CV_INIT_EML_IF(0,1,21,4980,5022,-1,5064);
        _SFD_CV_INIT_EML_IF(0,1,22,5089,5130,-1,5170);
        _SFD_CV_INIT_EML_IF(0,1,23,5200,5224,5330,5439);
        _SFD_CV_INIT_EML_IF(0,1,24,5237,5279,-1,5321);
        _SFD_CV_INIT_EML_IF(0,1,25,5346,5387,-1,5427);
        _SFD_CV_INIT_EML_IF(0,1,26,5661,5688,-1,5960);
        _SFD_CV_INIT_EML_IF(0,1,27,5823,5839,5884,5905);
        _SFD_CV_INIT_EML_IF(0,1,28,5884,5905,-1,5905);
        _SFD_CV_INIT_EML_IF(0,1,29,6166,6183,6206,6624);
        _SFD_CV_INIT_EML_IF(0,1,30,6245,6272,-1,6616);
        _SFD_CV_INIT_EML_IF(0,1,31,6454,6470,6525,6546);
        _SFD_CV_INIT_EML_IF(0,1,32,6525,6546,-1,6546);
        _SFD_CV_INIT_EML_IF(0,1,33,6629,6644,-1,6697);
        _SFD_CV_INIT_EML_FOR(0,1,0,488,511,2491);
        _SFD_CV_INIT_EML_FOR(0,1,1,2493,2516,3232);
        _SFD_CV_INIT_EML_FOR(0,1,2,4608,4631,6010);
        _SFD_CV_INIT_EML_FOR(0,1,3,6013,6036,6628);

        {
          static int condStart[] = { 864, 886 };

          static int condEnd[] = { 882, 905 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,0,864,905,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 975, 997 };

          static int condEnd[] = { 993, 1015 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,1,975,1015,2,2,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1125, 1147 };

          static int condEnd[] = { 1143, 1166 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,2,1125,1166,2,4,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1236, 1258 };

          static int condEnd[] = { 1254, 1276 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,3,1236,1276,2,6,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2651, 2660 };

          static int condEnd[] = { 2656, 2665 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,4,2651,2665,2,8,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3286 };

          static int condEnd[] = { 3304 };

          static int pfixExpr[] = { 0, -1 };

          _SFD_CV_INIT_EML_MCDC(0,1,5,3285,3304,1,10,&(condStart[0]),&(condEnd[0]),
                                2,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3588, 3602 };

          static int condEnd[] = { 3598, 3614 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,6,3588,3614,2,11,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 4983, 5004 };

          static int condEnd[] = { 5000, 5022 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,7,4983,5022,2,13,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 5092, 5113 };

          static int condEnd[] = { 5109, 5130 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,8,5092,5130,2,15,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 5240, 5261 };

          static int condEnd[] = { 5257, 5279 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,9,5240,5279,2,17,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 5349, 5370 };

          static int condEnd[] = { 5366, 5387 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,10,5349,5387,2,19,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 6169, 6178 };

          static int condEnd[] = { 6174, 6183 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,11,6169,6183,2,21,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          unsigned int dimVector[2];
          dimVector[0]= 6;
          dimVector[1]= 52;
          _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);

        {
          unsigned int dimVector[2];
          dimVector[0]= 5;
          dimVector[1]= 13;
          _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_b_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(18,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(19,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(20,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(21,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);

        {
          real_T *c2_dist;
          real_T *c2_X1;
          real_T *c2_Y1;
          real_T *c2_Psi;
          real_T *c2_dPsi;
          real_T *c2_delta;
          real_T *c2_vel;
          real_T *c2_l_S;
          real_T *c2_dist1;
          real_T *c2_deltaPsi;
          real_T *c2_deltadPsi;
          real_T *c2_rho;
          real_T *c2_rho1;
          real_T *c2_PX;
          real_T *c2_PY;
          real_T *c2_r;
          real_T *c2_Srem;
          real_T *c2_rho1new;
          real_T *c2_segNum;
          real_T *c2_jMin;
          real_T (*c2_CircleData)[312];
          real_T (*c2_LineData)[65];
          c2_jMin = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
          c2_segNum = (real_T *)ssGetOutputPortSignal(chartInstance->S, 12);
          c2_rho1new = (real_T *)ssGetOutputPortSignal(chartInstance->S, 11);
          c2_Srem = (real_T *)ssGetOutputPortSignal(chartInstance->S, 10);
          c2_r = (real_T *)ssGetOutputPortSignal(chartInstance->S, 9);
          c2_PY = (real_T *)ssGetOutputPortSignal(chartInstance->S, 8);
          c2_PX = (real_T *)ssGetOutputPortSignal(chartInstance->S, 7);
          c2_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
          c2_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
          c2_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
          c2_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
          c2_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c2_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
          c2_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
          c2_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c2_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c2_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c2_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c2_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c2_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
          c2_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c2_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S,
            0);
          _SFD_SET_DATA_VALUE_PTR(0U, *c2_CircleData);
          _SFD_SET_DATA_VALUE_PTR(1U, c2_dist);
          _SFD_SET_DATA_VALUE_PTR(2U, *c2_LineData);
          _SFD_SET_DATA_VALUE_PTR(3U, c2_X1);
          _SFD_SET_DATA_VALUE_PTR(4U, c2_Y1);
          _SFD_SET_DATA_VALUE_PTR(5U, c2_Psi);
          _SFD_SET_DATA_VALUE_PTR(6U, c2_dPsi);
          _SFD_SET_DATA_VALUE_PTR(7U, c2_delta);
          _SFD_SET_DATA_VALUE_PTR(8U, c2_vel);
          _SFD_SET_DATA_VALUE_PTR(9U, c2_l_S);
          _SFD_SET_DATA_VALUE_PTR(10U, c2_dist1);
          _SFD_SET_DATA_VALUE_PTR(11U, c2_deltaPsi);
          _SFD_SET_DATA_VALUE_PTR(12U, c2_deltadPsi);
          _SFD_SET_DATA_VALUE_PTR(13U, c2_rho);
          _SFD_SET_DATA_VALUE_PTR(14U, c2_rho1);
          _SFD_SET_DATA_VALUE_PTR(15U, c2_PX);
          _SFD_SET_DATA_VALUE_PTR(16U, c2_PY);
          _SFD_SET_DATA_VALUE_PTR(17U, c2_r);
          _SFD_SET_DATA_VALUE_PTR(18U, c2_Srem);
          _SFD_SET_DATA_VALUE_PTR(19U, c2_rho1new);
          _SFD_SET_DATA_VALUE_PTR(20U, c2_segNum);
          _SFD_SET_DATA_VALUE_PTR(21U, c2_jMin);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF_2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "5fYyjg2IJEsHRcDfiWKeMC";
}

static void sf_opaque_initialize_c2_laneKeepingArcSplinesFF_2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
  initialize_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_laneKeepingArcSplinesFF_2013a(void
  *chartInstanceVar)
{
  enable_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_laneKeepingArcSplinesFF_2013a(void
  *chartInstanceVar)
{
  disable_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_laneKeepingArcSplinesFF_2013a(void
  *chartInstanceVar)
{
  sf_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c2_laneKeepingArcSplinesFF_2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c2_laneKeepingArcSplinesFF_2013a(SimStruct*
  S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c2_laneKeepingArcSplinesFF_2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c2_laneKeepingArcSplinesFF_2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c2_laneKeepingArcSplinesFF_2013a(S);
}

static void sf_opaque_set_sim_state_c2_laneKeepingArcSplinesFF_2013a(SimStruct*
  S, const mxArray *st)
{
  sf_internal_set_sim_state_c2_laneKeepingArcSplinesFF_2013a(S, st);
}

static void sf_opaque_terminate_c2_laneKeepingArcSplinesFF_2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF_2013a_optimization_info();
    }

    finalize_c2_laneKeepingArcSplinesFF_2013a
      ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_laneKeepingArcSplinesFF_2013a
    ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_laneKeepingArcSplinesFF_2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_laneKeepingArcSplinesFF_2013a
      ((SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c2_laneKeepingArcSplinesFF_2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF_2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      2);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,2,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,2,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,2);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 7, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 8, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 9, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,2,10);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,2,12);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=12; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 10; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,2);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(529494780U));
  ssSetChecksum1(S,(105568986U));
  ssSetChecksum2(S,(2235282490U));
  ssSetChecksum3(S,(931289655U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c2_laneKeepingArcSplinesFF_2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c2_laneKeepingArcSplinesFF_2013a(SimStruct *S)
{
  SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *chartInstance;
  chartInstance = (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct *)utMalloc
    (sizeof(SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc2_laneKeepingArcSplinesFF_2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c2_laneKeepingArcSplinesFF_2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c2_laneKeepingArcSplinesFF_2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c2_laneKeepingArcSplinesFF_2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_laneKeepingArcSplinesFF_2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_laneKeepingArcSplinesFF_2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_laneKeepingArcSplinesFF_2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
