/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "c7_laneKeepingArcSplinesFF2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c7_debug_family_names[45] = { "R", "k", "S", "L", "m",
  "Iomega", "Cx", "Cy", "Bdelta", "Br", "C0", "Cr", "ea", "zeta", "df_D1_dalpha",
  "df_D2_dalpha", "df_D1_dlambda", "df_D2_dlambda", "sprime", "nargin",
  "nargout", "r", "Flf", "Flf_dot", "delta_dot", "r_dot", "dy", "delta", "alpha",
  "dx", "VOmegax", "VOmega", "IOmega", "df_D_lambda", "ddx", "df_D_dalpha",
  "ddy", "VOmegay", "mup", "Fz0", "VOmegaa", "Omega", "Fa", "lambda", "T" };

/* Function Declarations */
static void initialize_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initialize_params_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void enable_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void disable_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c7_update_debugger_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void set_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_st);
static void finalize_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void sf_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c7_chartstep_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initSimStructsc7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void registerMessagesc7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber);
static const mxArray *c7_sf_marshallOut(void *chartInstanceVoid, void *c7_inData);
static real_T c7_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_T, const char_T *c7_identifier);
static real_T c7_b_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static void c7_info_helper(c7_ResolvedFunctionInfo c7_info[28]);
static real_T c7_abs(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c7_x);
static real_T c7_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a);
static void c7_eml_scalar_eg(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c7_b_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a);
static real_T c7_c_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a);
static void c7_eml_error(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c7_d_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a);
static real_T c7_sign(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c7_x);
static real_T c7_e_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a);
static void c7_b_eml_error(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static const mxArray *c7_b_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static int32_T c7_c_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static uint8_T c7_d_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_b_is_active_c7_laneKeepingArcSplinesFF2013a, const char_T *c7_identifier);
static uint8_T c7_e_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_b_sign(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c7_x);
static void init_dsm_address_info
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  chartInstance->c7_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c7_is_active_c7_laneKeepingArcSplinesFF2013a = 0U;
}

static void initialize_params_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void enable_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c7_update_debugger_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  const mxArray *c7_st;
  const mxArray *c7_y = NULL;
  real_T c7_hoistedGlobal;
  real_T c7_u;
  const mxArray *c7_b_y = NULL;
  uint8_T c7_b_hoistedGlobal;
  uint8_T c7_b_u;
  const mxArray *c7_c_y = NULL;
  real_T *c7_T;
  c7_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c7_st = NULL;
  c7_st = NULL;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_createcellarray(2), FALSE);
  c7_hoistedGlobal = *c7_T;
  c7_u = c7_hoistedGlobal;
  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", &c7_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c7_y, 0, c7_b_y);
  c7_b_hoistedGlobal =
    chartInstance->c7_is_active_c7_laneKeepingArcSplinesFF2013a;
  c7_b_u = c7_b_hoistedGlobal;
  c7_c_y = NULL;
  sf_mex_assign(&c7_c_y, sf_mex_create("y", &c7_b_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c7_y, 1, c7_c_y);
  sf_mex_assign(&c7_st, c7_y, FALSE);
  return c7_st;
}

static void set_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_st)
{
  const mxArray *c7_u;
  real_T *c7_T;
  c7_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c7_doneDoubleBufferReInit = TRUE;
  c7_u = sf_mex_dup(c7_st);
  *c7_T = c7_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c7_u, 0)),
    "T");
  chartInstance->c7_is_active_c7_laneKeepingArcSplinesFF2013a =
    c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c7_u, 1)),
    "is_active_c7_laneKeepingArcSplinesFF2013a");
  sf_mex_destroy(&c7_u);
  c7_update_debugger_state_c7_laneKeepingArcSplinesFF2013a(chartInstance);
  sf_mex_destroy(&c7_st);
}

static void finalize_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void sf_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T *c7_r;
  real_T *c7_Flf;
  real_T *c7_Flf_dot;
  real_T *c7_delta_dot;
  real_T *c7_r_dot;
  real_T *c7_dy;
  real_T *c7_delta;
  real_T *c7_alpha;
  real_T *c7_dx;
  real_T *c7_VOmegax;
  real_T *c7_VOmega;
  real_T *c7_IOmega;
  real_T *c7_df_D_lambda;
  real_T *c7_ddx;
  real_T *c7_df_D_dalpha;
  real_T *c7_ddy;
  real_T *c7_VOmegay;
  real_T *c7_mup;
  real_T *c7_Fz0;
  real_T *c7_VOmegaa;
  real_T *c7_Omega;
  real_T *c7_Fa;
  real_T *c7_lambda;
  real_T *c7_T;
  c7_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c7_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
  c7_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
  c7_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
  c7_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
  c7_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
  c7_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
  c7_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
  c7_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
  c7_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
  c7_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
  c7_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
  c7_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
  c7_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
  c7_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c7_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c7_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c7_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c7_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c7_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c7_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c7_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c7_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c7_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 6U, chartInstance->c7_sfEvent);
  _SFD_DATA_RANGE_CHECK(*c7_r, 0U);
  _SFD_DATA_RANGE_CHECK(*c7_Flf, 1U);
  _SFD_DATA_RANGE_CHECK(*c7_Flf_dot, 2U);
  _SFD_DATA_RANGE_CHECK(*c7_delta_dot, 3U);
  _SFD_DATA_RANGE_CHECK(*c7_r_dot, 4U);
  _SFD_DATA_RANGE_CHECK(*c7_dy, 5U);
  _SFD_DATA_RANGE_CHECK(*c7_delta, 6U);
  _SFD_DATA_RANGE_CHECK(*c7_alpha, 7U);
  _SFD_DATA_RANGE_CHECK(*c7_dx, 8U);
  _SFD_DATA_RANGE_CHECK(*c7_VOmegax, 9U);
  _SFD_DATA_RANGE_CHECK(*c7_VOmega, 10U);
  _SFD_DATA_RANGE_CHECK(*c7_IOmega, 11U);
  _SFD_DATA_RANGE_CHECK(*c7_df_D_lambda, 12U);
  _SFD_DATA_RANGE_CHECK(*c7_ddx, 13U);
  _SFD_DATA_RANGE_CHECK(*c7_df_D_dalpha, 14U);
  _SFD_DATA_RANGE_CHECK(*c7_ddy, 15U);
  _SFD_DATA_RANGE_CHECK(*c7_VOmegay, 16U);
  _SFD_DATA_RANGE_CHECK(*c7_mup, 17U);
  _SFD_DATA_RANGE_CHECK(*c7_Fz0, 18U);
  _SFD_DATA_RANGE_CHECK(*c7_VOmegaa, 19U);
  _SFD_DATA_RANGE_CHECK(*c7_Omega, 20U);
  _SFD_DATA_RANGE_CHECK(*c7_Fa, 21U);
  _SFD_DATA_RANGE_CHECK(*c7_lambda, 22U);
  _SFD_DATA_RANGE_CHECK(*c7_T, 23U);
  chartInstance->c7_sfEvent = CALL_EVENT;
  c7_chartstep_c7_laneKeepingArcSplinesFF2013a(chartInstance);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_laneKeepingArcSplinesFF2013aMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c7_chartstep_c7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T c7_hoistedGlobal;
  real_T c7_b_hoistedGlobal;
  real_T c7_c_hoistedGlobal;
  real_T c7_d_hoistedGlobal;
  real_T c7_e_hoistedGlobal;
  real_T c7_f_hoistedGlobal;
  real_T c7_g_hoistedGlobal;
  real_T c7_h_hoistedGlobal;
  real_T c7_i_hoistedGlobal;
  real_T c7_j_hoistedGlobal;
  real_T c7_k_hoistedGlobal;
  real_T c7_l_hoistedGlobal;
  real_T c7_m_hoistedGlobal;
  real_T c7_n_hoistedGlobal;
  real_T c7_o_hoistedGlobal;
  real_T c7_p_hoistedGlobal;
  real_T c7_q_hoistedGlobal;
  real_T c7_r_hoistedGlobal;
  real_T c7_s_hoistedGlobal;
  real_T c7_t_hoistedGlobal;
  real_T c7_u_hoistedGlobal;
  real_T c7_v_hoistedGlobal;
  real_T c7_w_hoistedGlobal;
  real_T c7_r;
  real_T c7_Flf;
  real_T c7_Flf_dot;
  real_T c7_delta_dot;
  real_T c7_r_dot;
  real_T c7_dy;
  real_T c7_delta;
  real_T c7_alpha;
  real_T c7_dx;
  real_T c7_VOmegax;
  real_T c7_VOmega;
  real_T c7_IOmega;
  real_T c7_df_D_lambda;
  real_T c7_ddx;
  real_T c7_df_D_dalpha;
  real_T c7_ddy;
  real_T c7_VOmegay;
  real_T c7_mup;
  real_T c7_Fz0;
  real_T c7_VOmegaa;
  real_T c7_Omega;
  real_T c7_Fa;
  real_T c7_lambda;
  uint32_T c7_debug_family_var_map[45];
  real_T c7_R;
  real_T c7_k;
  real_T c7_S;
  real_T c7_L;
  real_T c7_m;
  real_T c7_Iomega;
  real_T c7_Cx;
  real_T c7_Cy;
  real_T c7_Bdelta;
  real_T c7_Br;
  real_T c7_C0;
  real_T c7_Cr;
  real_T c7_ea;
  real_T c7_zeta;
  real_T c7_df_D1_dalpha;
  real_T c7_df_D2_dalpha;
  real_T c7_df_D1_dlambda;
  real_T c7_df_D2_dlambda;
  real_T c7_sprime;
  real_T c7_nargin = 23.0;
  real_T c7_nargout = 1.0;
  real_T c7_T;
  real_T c7_b;
  real_T c7_y;
  real_T c7_b_b;
  real_T c7_b_y;
  real_T c7_A;
  real_T c7_B;
  real_T c7_x;
  real_T c7_c_y;
  real_T c7_b_x;
  real_T c7_d_y;
  real_T c7_e_y;
  real_T c7_c_x;
  real_T c7_d_x;
  real_T c7_a;
  real_T c7_c_b;
  real_T c7_f_y;
  real_T c7_e_x;
  real_T c7_f_x;
  real_T c7_b_a;
  real_T c7_d_b;
  real_T c7_g_y;
  real_T c7_g_x;
  real_T c7_h_x;
  real_T c7_e_b;
  real_T c7_h_y;
  real_T c7_i_x;
  real_T c7_j_x;
  real_T c7_f_b;
  real_T c7_i_y;
  real_T c7_c_a;
  real_T c7_g_b;
  real_T c7_j_y;
  real_T c7_b_A;
  real_T c7_b_B;
  real_T c7_k_x;
  real_T c7_k_y;
  real_T c7_l_x;
  real_T c7_l_y;
  real_T c7_m_y;
  real_T c7_d_a;
  real_T c7_h_b;
  real_T c7_c_A;
  real_T c7_c_B;
  real_T c7_m_x;
  real_T c7_n_y;
  real_T c7_n_x;
  real_T c7_o_y;
  real_T c7_p_y;
  real_T c7_o_x;
  real_T c7_p_x;
  real_T c7_i_b;
  real_T c7_q_y;
  real_T c7_e_a;
  real_T c7_j_b;
  real_T c7_r_y;
  real_T c7_q_x;
  real_T c7_r_x;
  real_T c7_k_b;
  real_T c7_s_y;
  real_T c7_d_A;
  real_T c7_d_B;
  real_T c7_s_x;
  real_T c7_t_y;
  real_T c7_t_x;
  real_T c7_u_y;
  real_T c7_v_y;
  real_T c7_e_B;
  real_T c7_w_y;
  real_T c7_x_y;
  real_T c7_y_y;
  real_T c7_f_a;
  real_T c7_l_b;
  real_T c7_ab_y;
  real_T c7_g_a;
  real_T c7_m_b;
  real_T c7_bb_y;
  real_T c7_h_a;
  real_T c7_n_b;
  real_T c7_cb_y;
  real_T c7_i_a;
  real_T c7_o_b;
  real_T c7_db_y;
  real_T c7_j_a;
  real_T c7_p_b;
  real_T c7_eb_y;
  real_T c7_e_A;
  real_T c7_f_B;
  real_T c7_u_x;
  real_T c7_fb_y;
  real_T c7_v_x;
  real_T c7_gb_y;
  real_T c7_g_B;
  real_T c7_hb_y;
  real_T c7_ib_y;
  real_T c7_jb_y;
  real_T c7_k_a;
  real_T c7_kb_y;
  real_T c7_l_a;
  real_T c7_lb_y;
  real_T c7_m_a;
  real_T c7_q_b;
  real_T c7_mb_y;
  real_T c7_f_A;
  real_T c7_h_B;
  real_T c7_w_x;
  real_T c7_nb_y;
  real_T c7_x_x;
  real_T c7_ob_y;
  real_T c7_n_a;
  real_T c7_r_b;
  real_T c7_pb_y;
  real_T c7_o_a;
  real_T c7_s_b;
  real_T c7_qb_y;
  real_T c7_p_a;
  real_T c7_t_b;
  real_T c7_rb_y;
  real_T c7_y_x;
  real_T c7_ab_x;
  real_T c7_q_a;
  real_T c7_u_b;
  real_T c7_sb_y;
  real_T c7_bb_x;
  real_T c7_cb_x;
  real_T c7_r_a;
  real_T c7_v_b;
  real_T c7_tb_y;
  real_T c7_db_x;
  real_T c7_eb_x;
  real_T c7_w_b;
  real_T c7_ub_y;
  real_T c7_x_b;
  real_T c7_vb_y;
  real_T c7_s_a;
  real_T c7_y_b;
  real_T c7_wb_y;
  real_T c7_ab_b;
  real_T c7_xb_y;
  real_T c7_fb_x;
  real_T c7_gb_x;
  real_T c7_bb_b;
  real_T c7_yb_y;
  real_T c7_t_a;
  real_T c7_cb_b;
  real_T c7_ac_y;
  real_T c7_u_a;
  real_T c7_db_b;
  real_T c7_bc_y;
  real_T c7_v_a;
  real_T c7_eb_b;
  real_T c7_cc_y;
  real_T c7_fb_b;
  real_T c7_dc_y;
  real_T c7_hb_x;
  real_T c7_ib_x;
  real_T c7_gb_b;
  real_T c7_ec_y;
  real_T c7_w_a;
  real_T c7_hb_b;
  real_T c7_fc_y;
  real_T c7_ib_b;
  real_T c7_gc_y;
  real_T c7_jb_x;
  real_T c7_kb_x;
  real_T c7_x_a;
  real_T c7_jb_b;
  real_T c7_hc_y;
  real_T c7_y_a;
  real_T c7_kb_b;
  real_T c7_ic_y;
  real_T c7_lb_b;
  real_T c7_jc_y;
  real_T c7_lb_x;
  real_T c7_mb_x;
  real_T c7_mb_b;
  real_T c7_kc_y;
  real_T c7_nb_b;
  real_T c7_lc_y;
  real_T c7_g_A;
  real_T c7_i_B;
  real_T c7_nb_x;
  real_T c7_mc_y;
  real_T c7_ob_x;
  real_T c7_nc_y;
  real_T c7_ob_b;
  real_T c7_oc_y;
  real_T c7_ab_a;
  real_T c7_pb_b;
  real_T c7_pc_y;
  real_T c7_h_A;
  real_T c7_j_B;
  real_T c7_pb_x;
  real_T c7_qc_y;
  real_T c7_qb_x;
  real_T c7_rc_y;
  real_T c7_sc_y;
  real_T c7_k_B;
  real_T c7_tc_y;
  real_T c7_uc_y;
  real_T c7_vc_y;
  real_T c7_qb_b;
  real_T c7_wc_y;
  real_T c7_bb_a;
  real_T c7_rb_b;
  real_T c7_xc_y;
  real_T c7_sb_b;
  real_T c7_yc_y;
  real_T c7_rb_x;
  real_T c7_sb_x;
  real_T c7_tb_b;
  real_T c7_ad_y;
  real_T c7_i_A;
  real_T c7_l_B;
  real_T c7_tb_x;
  real_T c7_bd_y;
  real_T c7_ub_x;
  real_T c7_cd_y;
  real_T c7_dd_y;
  real_T c7_ub_b;
  real_T c7_ed_y;
  real_T c7_cb_a;
  real_T c7_vb_b;
  real_T c7_fd_y;
  real_T c7_wb_b;
  real_T c7_gd_y;
  real_T c7_vb_x;
  real_T c7_wb_x;
  real_T c7_xb_b;
  real_T c7_hd_y;
  real_T c7_yb_b;
  real_T c7_id_y;
  real_T c7_j_A;
  real_T c7_m_B;
  real_T c7_xb_x;
  real_T c7_jd_y;
  real_T c7_yb_x;
  real_T c7_kd_y;
  real_T c7_ld_y;
  real_T c7_ac_b;
  real_T c7_md_y;
  real_T c7_db_a;
  real_T c7_bc_b;
  real_T c7_nd_y;
  real_T c7_eb_a;
  real_T c7_cc_b;
  real_T c7_od_y;
  real_T c7_dc_b;
  real_T c7_pd_y;
  real_T c7_ac_x;
  real_T c7_bc_x;
  real_T c7_ec_b;
  real_T c7_qd_y;
  real_T c7_k_A;
  real_T c7_n_B;
  real_T c7_cc_x;
  real_T c7_rd_y;
  real_T c7_dc_x;
  real_T c7_sd_y;
  real_T c7_td_y;
  real_T c7_fc_b;
  real_T c7_ud_y;
  real_T c7_fb_a;
  real_T c7_gc_b;
  real_T c7_vd_y;
  real_T c7_gb_a;
  real_T c7_hc_b;
  real_T c7_wd_y;
  real_T c7_ic_b;
  real_T c7_xd_y;
  real_T c7_ec_x;
  real_T c7_fc_x;
  real_T c7_jc_b;
  real_T c7_yd_y;
  real_T c7_kc_b;
  real_T c7_ae_y;
  real_T c7_l_A;
  real_T c7_o_B;
  real_T c7_gc_x;
  real_T c7_be_y;
  real_T c7_hc_x;
  real_T c7_ce_y;
  real_T c7_de_y;
  real_T c7_lc_b;
  real_T c7_ee_y;
  real_T c7_hb_a;
  real_T c7_mc_b;
  real_T c7_fe_y;
  real_T c7_ib_a;
  real_T c7_nc_b;
  real_T c7_ge_y;
  real_T c7_ic_x;
  real_T c7_jc_x;
  real_T c7_oc_b;
  real_T c7_he_y;
  real_T c7_pc_b;
  real_T c7_ie_y;
  real_T c7_qc_b;
  real_T c7_je_y;
  real_T c7_kc_x;
  real_T c7_lc_x;
  real_T c7_jb_a;
  real_T c7_rc_b;
  real_T c7_ke_y;
  real_T c7_sc_b;
  real_T c7_le_y;
  real_T c7_m_A;
  real_T c7_p_B;
  real_T c7_mc_x;
  real_T c7_me_y;
  real_T c7_nc_x;
  real_T c7_ne_y;
  real_T c7_oe_y;
  real_T c7_tc_b;
  real_T c7_pe_y;
  real_T c7_kb_a;
  real_T c7_uc_b;
  real_T c7_qe_y;
  real_T c7_lb_a;
  real_T c7_vc_b;
  real_T c7_re_y;
  real_T c7_oc_x;
  real_T c7_pc_x;
  real_T c7_mb_a;
  real_T c7_wc_b;
  real_T c7_se_y;
  real_T c7_xc_b;
  real_T c7_te_y;
  real_T c7_qc_x;
  real_T c7_rc_x;
  real_T c7_yc_b;
  real_T c7_ue_y;
  real_T c7_ad_b;
  real_T c7_ve_y;
  real_T c7_n_A;
  real_T c7_q_B;
  real_T c7_sc_x;
  real_T c7_we_y;
  real_T c7_tc_x;
  real_T c7_xe_y;
  real_T c7_ye_y;
  real_T c7_bd_b;
  real_T c7_af_y;
  real_T c7_nb_a;
  real_T c7_cd_b;
  real_T c7_bf_y;
  real_T c7_ob_a;
  real_T c7_dd_b;
  real_T c7_cf_y;
  real_T c7_uc_x;
  real_T c7_vc_x;
  real_T c7_df_y;
  real_T c7_pb_a;
  real_T c7_ed_b;
  real_T c7_ef_y;
  real_T c7_wc_x;
  real_T c7_xc_x;
  real_T c7_fd_b;
  real_T c7_ff_y;
  real_T c7_gd_b;
  real_T c7_gf_y;
  real_T c7_hd_b;
  real_T c7_hf_y;
  real_T c7_yc_x;
  real_T c7_ad_x;
  real_T c7_qb_a;
  real_T c7_id_b;
  real_T c7_if_y;
  real_T c7_jd_b;
  real_T c7_jf_y;
  real_T c7_o_A;
  real_T c7_r_B;
  real_T c7_bd_x;
  real_T c7_kf_y;
  real_T c7_cd_x;
  real_T c7_lf_y;
  real_T c7_mf_y;
  real_T c7_rb_a;
  real_T c7_kd_b;
  real_T c7_nf_y;
  real_T c7_dd_x;
  real_T c7_ed_x;
  real_T c7_of_y;
  real_T c7_sb_a;
  real_T c7_ld_b;
  real_T c7_pf_y;
  real_T c7_md_b;
  real_T c7_qf_y;
  real_T c7_fd_x;
  real_T c7_gd_x;
  real_T c7_nd_b;
  real_T c7_rf_y;
  real_T c7_hd_x;
  real_T c7_id_x;
  real_T c7_od_b;
  real_T c7_sf_y;
  real_T c7_p_A;
  real_T c7_s_B;
  real_T c7_jd_x;
  real_T c7_tf_y;
  real_T c7_kd_x;
  real_T c7_uf_y;
  real_T c7_tb_a;
  real_T c7_vf_y;
  real_T c7_ub_a;
  real_T c7_pd_b;
  real_T c7_wf_y;
  real_T c7_t_B;
  real_T c7_xf_y;
  real_T c7_yf_y;
  real_T c7_ag_y;
  real_T c7_vb_a;
  real_T c7_qd_b;
  real_T c7_bg_y;
  real_T c7_ld_x;
  real_T c7_md_x;
  real_T c7_wb_a;
  real_T c7_rd_b;
  real_T c7_cg_y;
  real_T c7_xb_a;
  real_T c7_sd_b;
  real_T c7_dg_y;
  real_T c7_nd_x;
  real_T c7_od_x;
  real_T c7_yb_a;
  real_T c7_td_b;
  real_T c7_eg_y;
  real_T c7_ac_a;
  real_T c7_ud_b;
  real_T c7_fg_y;
  real_T c7_pd_x;
  real_T c7_qd_x;
  real_T c7_gg_y;
  real_T c7_q_A;
  real_T c7_u_B;
  real_T c7_rd_x;
  real_T c7_hg_y;
  real_T c7_sd_x;
  real_T c7_ig_y;
  real_T c7_jg_y;
  real_T c7_bc_a;
  real_T c7_vd_b;
  real_T c7_kg_y;
  real_T c7_cc_a;
  real_T c7_wd_b;
  real_T c7_lg_y;
  real_T c7_v_B;
  real_T c7_mg_y;
  real_T c7_ng_y;
  real_T c7_og_y;
  real_T c7_dc_a;
  real_T c7_xd_b;
  real_T c7_pg_y;
  real_T c7_ec_a;
  real_T c7_yd_b;
  real_T c7_qg_y;
  real_T c7_r_A;
  real_T c7_w_B;
  real_T c7_td_x;
  real_T c7_rg_y;
  real_T c7_ud_x;
  real_T c7_sg_y;
  real_T c7_tg_y;
  real_T c7_fc_a;
  real_T c7_ae_b;
  real_T c7_ug_y;
  real_T c7_s_A;
  real_T c7_x_B;
  real_T c7_vd_x;
  real_T c7_vg_y;
  real_T c7_wd_x;
  real_T c7_wg_y;
  real_T c7_xg_y;
  real_T c7_gc_a;
  real_T c7_be_b;
  real_T c7_yg_y;
  real_T c7_hc_a;
  real_T c7_ce_b;
  real_T c7_ah_y;
  real_T *c7_b_lambda;
  real_T *c7_b_Fa;
  real_T *c7_b_Omega;
  real_T *c7_b_VOmegaa;
  real_T *c7_b_Fz0;
  real_T *c7_b_mup;
  real_T *c7_b_VOmegay;
  real_T *c7_b_ddy;
  real_T *c7_b_df_D_dalpha;
  real_T *c7_b_ddx;
  real_T *c7_b_df_D_lambda;
  real_T *c7_b_IOmega;
  real_T *c7_b_VOmega;
  real_T *c7_b_VOmegax;
  real_T *c7_b_dx;
  real_T *c7_b_alpha;
  real_T *c7_b_delta;
  real_T *c7_b_dy;
  real_T *c7_b_r_dot;
  real_T *c7_b_delta_dot;
  real_T *c7_b_Flf_dot;
  real_T *c7_b_Flf;
  real_T *c7_b_r;
  real_T *c7_b_T;
  c7_b_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c7_b_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
  c7_b_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
  c7_b_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
  c7_b_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
  c7_b_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
  c7_b_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
  c7_b_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
  c7_b_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
  c7_b_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
  c7_b_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
  c7_b_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
  c7_b_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
  c7_b_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
  c7_b_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c7_b_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c7_b_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c7_b_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c7_b_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c7_b_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c7_b_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c7_b_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c7_b_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c7_b_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 6U, chartInstance->c7_sfEvent);
  c7_hoistedGlobal = *c7_b_r;
  c7_b_hoistedGlobal = *c7_b_Flf;
  c7_c_hoistedGlobal = *c7_b_Flf_dot;
  c7_d_hoistedGlobal = *c7_b_delta_dot;
  c7_e_hoistedGlobal = *c7_b_r_dot;
  c7_f_hoistedGlobal = *c7_b_dy;
  c7_g_hoistedGlobal = *c7_b_delta;
  c7_h_hoistedGlobal = *c7_b_alpha;
  c7_i_hoistedGlobal = *c7_b_dx;
  c7_j_hoistedGlobal = *c7_b_VOmegax;
  c7_k_hoistedGlobal = *c7_b_VOmega;
  c7_l_hoistedGlobal = *c7_b_IOmega;
  c7_m_hoistedGlobal = *c7_b_df_D_lambda;
  c7_n_hoistedGlobal = *c7_b_ddx;
  c7_o_hoistedGlobal = *c7_b_df_D_dalpha;
  c7_p_hoistedGlobal = *c7_b_ddy;
  c7_q_hoistedGlobal = *c7_b_VOmegay;
  c7_r_hoistedGlobal = *c7_b_mup;
  c7_s_hoistedGlobal = *c7_b_Fz0;
  c7_t_hoistedGlobal = *c7_b_VOmegaa;
  c7_u_hoistedGlobal = *c7_b_Omega;
  c7_v_hoistedGlobal = *c7_b_Fa;
  c7_w_hoistedGlobal = *c7_b_lambda;
  c7_r = c7_hoistedGlobal;
  c7_Flf = c7_b_hoistedGlobal;
  c7_Flf_dot = c7_c_hoistedGlobal;
  c7_delta_dot = c7_d_hoistedGlobal;
  c7_r_dot = c7_e_hoistedGlobal;
  c7_dy = c7_f_hoistedGlobal;
  c7_delta = c7_g_hoistedGlobal;
  c7_alpha = c7_h_hoistedGlobal;
  c7_dx = c7_i_hoistedGlobal;
  c7_VOmegax = c7_j_hoistedGlobal;
  c7_VOmega = c7_k_hoistedGlobal;
  c7_IOmega = c7_l_hoistedGlobal;
  c7_df_D_lambda = c7_m_hoistedGlobal;
  c7_ddx = c7_n_hoistedGlobal;
  c7_df_D_dalpha = c7_o_hoistedGlobal;
  c7_ddy = c7_p_hoistedGlobal;
  c7_VOmegay = c7_q_hoistedGlobal;
  c7_mup = c7_r_hoistedGlobal;
  c7_Fz0 = c7_s_hoistedGlobal;
  c7_VOmegaa = c7_t_hoistedGlobal;
  c7_Omega = c7_u_hoistedGlobal;
  c7_Fa = c7_v_hoistedGlobal;
  c7_lambda = c7_w_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 45U, 45U, c7_debug_family_names,
    c7_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_R, 0U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_k, 1U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_S, 2U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_L, 3U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_m, 4U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_Iomega, 5U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Cx, 6U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Cy, 7U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_Bdelta, 8U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_Br, 9U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_C0, 10U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_Cr, 11U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_ea, 12U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_zeta, 13U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_df_D1_dalpha, 14U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_df_D2_dalpha, 15U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_df_D1_dlambda, 16U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_df_D2_dlambda, 17U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_sprime, 18U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargin, 19U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargout, 20U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_r, 21U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Flf, 22U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Flf_dot, 23U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_delta_dot, 24U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_r_dot, 25U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_dy, 26U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_delta, 27U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_alpha, 28U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_dx, 29U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_VOmegax, 30U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_VOmega, 31U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_IOmega, 32U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_df_D_lambda, 33U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_ddx, 34U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_df_D_dalpha, 35U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_ddy, 36U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_VOmegay, 37U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_mup, 38U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Fz0, 39U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_VOmegaa, 40U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Omega, 41U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_Fa, 42U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c7_lambda, 43U, c7_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_T, 44U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 5);
  c7_R = 0.344;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 6);
  c7_k = 5.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 8);
  c7_S = 1.421;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 9);
  c7_L = 1.029;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 10);
  c7_m = 1480.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 11);
  c7_Iomega = 2.7;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 13);
  c7_Cx = 435000.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 14);
  c7_Cy = 166500.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 15);
  c7_b = c7_r;
  c7_y = 1.421 * c7_b;
  c7_VOmegax = c7_dx + c7_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 16);
  c7_b_b = c7_r;
  c7_b_y = 1.029 * c7_b_b;
  c7_VOmegay = c7_dy + c7_b_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 17);
  c7_A = 1.0 - c7_abs(chartInstance, c7_lambda);
  c7_B = c7_Fz0;
  c7_x = c7_A;
  c7_c_y = c7_B;
  c7_b_x = c7_x;
  c7_d_y = c7_c_y;
  c7_e_y = c7_b_x / c7_d_y;
  c7_c_x = c7_delta;
  c7_d_x = c7_c_x;
  c7_d_x = muDoubleScalarSin(c7_d_x);
  c7_a = c7_dx;
  c7_c_b = c7_d_x;
  c7_f_y = c7_a * c7_c_b;
  c7_e_x = c7_delta;
  c7_f_x = c7_e_x;
  c7_f_x = muDoubleScalarCos(c7_f_x);
  c7_b_a = c7_dy;
  c7_d_b = c7_f_x;
  c7_g_y = c7_b_a * c7_d_b;
  c7_g_x = c7_delta;
  c7_h_x = c7_g_x;
  c7_h_x = muDoubleScalarSin(c7_h_x);
  c7_e_b = c7_h_x;
  c7_h_y = 1.421 * c7_e_b;
  c7_i_x = c7_delta;
  c7_j_x = c7_i_x;
  c7_j_x = muDoubleScalarCos(c7_j_x);
  c7_f_b = c7_j_x;
  c7_i_y = 1.029 * c7_f_b;
  c7_c_a = c7_h_y - c7_i_y;
  c7_g_b = c7_r;
  c7_j_y = c7_c_a * c7_g_b;
  c7_b_A = c7_j_y;
  c7_b_B = c7_VOmegaa;
  c7_k_x = c7_b_A;
  c7_k_y = c7_b_B;
  c7_l_x = c7_k_x;
  c7_l_y = c7_k_y;
  c7_m_y = c7_l_x / c7_l_y;
  c7_d_a = c7_e_y;
  c7_h_b = (c7_f_y - c7_g_y) + c7_m_y;
  c7_Bdelta = c7_d_a * c7_h_b;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 18);
  c7_c_A = 1.0 - c7_abs(chartInstance, c7_lambda);
  c7_c_B = c7_Fz0;
  c7_m_x = c7_c_A;
  c7_n_y = c7_c_B;
  c7_n_x = c7_m_x;
  c7_o_y = c7_n_y;
  c7_p_y = c7_n_x / c7_o_y;
  c7_o_x = c7_delta;
  c7_p_x = c7_o_x;
  c7_p_x = muDoubleScalarCos(c7_p_x);
  c7_i_b = c7_p_x;
  c7_q_y = 1.421 * c7_i_b;
  c7_e_a = c7_p_y;
  c7_j_b = c7_q_y;
  c7_r_y = c7_e_a * c7_j_b;
  c7_q_x = c7_delta;
  c7_r_x = c7_q_x;
  c7_r_x = muDoubleScalarSin(c7_r_x);
  c7_k_b = c7_r_x;
  c7_s_y = 1.029 * c7_k_b;
  c7_d_A = c7_s_y;
  c7_d_B = c7_VOmegaa;
  c7_s_x = c7_d_A;
  c7_t_y = c7_d_B;
  c7_t_x = c7_s_x;
  c7_u_y = c7_t_y;
  c7_v_y = c7_t_x / c7_u_y;
  c7_Br = c7_r_y + c7_v_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 19);
  c7_e_B = c7_Fz0;
  c7_w_y = c7_e_B;
  c7_x_y = c7_w_y;
  c7_y_y = 1.0 / c7_x_y;
  c7_f_a = c7_dx;
  c7_l_b = c7_r;
  c7_ab_y = c7_f_a * c7_l_b;
  c7_g_a = c7_VOmegax;
  c7_m_b = c7_ddy - c7_ab_y;
  c7_bb_y = c7_g_a * c7_m_b;
  c7_h_a = c7_dy;
  c7_n_b = c7_r;
  c7_cb_y = c7_h_a * c7_n_b;
  c7_i_a = c7_VOmegay;
  c7_o_b = c7_ddx + c7_cb_y;
  c7_db_y = c7_i_a * c7_o_b;
  c7_j_a = -c7_y_y;
  c7_p_b = c7_bb_y - c7_db_y;
  c7_eb_y = c7_j_a * c7_p_b;
  c7_e_A = c7_eb_y;
  c7_f_B = c7_mpower(chartInstance, c7_VOmega);
  c7_u_x = c7_e_A;
  c7_fb_y = c7_f_B;
  c7_v_x = c7_u_x;
  c7_gb_y = c7_fb_y;
  c7_C0 = c7_v_x / c7_gb_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 20);
  c7_g_B = c7_Fz0;
  c7_hb_y = c7_g_B;
  c7_ib_y = c7_hb_y;
  c7_jb_y = 1.0 / c7_ib_y;
  c7_k_a = c7_VOmegax;
  c7_kb_y = c7_k_a * 1.029;
  c7_l_a = c7_VOmegay;
  c7_lb_y = c7_l_a * 1.421;
  c7_m_a = -c7_jb_y;
  c7_q_b = c7_kb_y - c7_lb_y;
  c7_mb_y = c7_m_a * c7_q_b;
  c7_f_A = c7_mb_y;
  c7_h_B = c7_mpower(chartInstance, c7_VOmega);
  c7_w_x = c7_f_A;
  c7_nb_y = c7_h_B;
  c7_x_x = c7_w_x;
  c7_ob_y = c7_nb_y;
  c7_Cr = c7_x_x / c7_ob_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 27);
  c7_ea = c7_Fa - c7_Flf;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 28);
  c7_n_a = c7_ea;
  c7_zeta = c7_n_a * 5.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 30);
  c7_df_D1_dalpha = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 31);
  c7_r_b = c7_Fz0;
  c7_pb_y = 1.205917875E+16 * c7_r_b;
  c7_o_a = c7_pb_y;
  c7_s_b = c7_lambda;
  c7_qb_y = c7_o_a * c7_s_b;
  c7_p_a = c7_qb_y;
  c7_t_b = c7_mup;
  c7_rb_y = c7_p_a * c7_t_b;
  c7_y_x = c7_alpha;
  c7_ab_x = c7_y_x;
  c7_ab_x = muDoubleScalarTan(c7_ab_x);
  c7_q_a = c7_rb_y;
  c7_u_b = c7_ab_x;
  c7_sb_y = c7_q_a * c7_u_b;
  c7_bb_x = c7_alpha;
  c7_cb_x = c7_bb_x;
  c7_cb_x = muDoubleScalarTan(c7_cb_x);
  c7_r_a = c7_sb_y;
  c7_v_b = c7_mpower(chartInstance, c7_cb_x) + 1.0;
  c7_tb_y = c7_r_a * c7_v_b;
  c7_db_x = c7_alpha;
  c7_eb_x = c7_db_x;
  c7_eb_x = muDoubleScalarTan(c7_eb_x);
  c7_w_b = c7_b_mpower(chartInstance, c7_eb_x);
  c7_ub_y = 1.537046290125E+21 * c7_w_b;
  c7_x_b = c7_b_mpower(chartInstance, c7_lambda);
  c7_vb_y = 7.161220125E+22 * c7_x_b;
  c7_s_a = c7_Fz0;
  c7_y_b = c7_mup;
  c7_wb_y = c7_s_a * c7_y_b;
  c7_ab_b = c7_mpower(chartInstance, c7_lambda);
  c7_xb_y = 1.89225E+11 * c7_ab_b;
  c7_fb_x = c7_alpha;
  c7_gb_x = c7_fb_x;
  c7_gb_x = muDoubleScalarTan(c7_gb_x);
  c7_bb_b = c7_mpower(chartInstance, c7_gb_x);
  c7_yb_y = 2.772225E+10 * c7_bb_b;
  c7_t_a = c7_wb_y;
  c7_cb_b = c7_c_mpower(chartInstance, c7_xb_y + c7_yb_y);
  c7_ac_y = c7_t_a * c7_cb_b;
  c7_u_a = c7_Fz0;
  c7_db_b = c7_mup;
  c7_bc_y = c7_u_a * c7_db_b;
  c7_v_a = c7_bc_y;
  c7_eb_b = c7_abs(chartInstance, c7_lambda);
  c7_cc_y = c7_v_a * c7_eb_b;
  c7_fb_b = c7_mpower(chartInstance, c7_lambda);
  c7_dc_y = 1.89225E+11 * c7_fb_b;
  c7_hb_x = c7_alpha;
  c7_ib_x = c7_hb_x;
  c7_ib_x = muDoubleScalarTan(c7_ib_x);
  c7_gb_b = c7_mpower(chartInstance, c7_ib_x);
  c7_ec_y = 2.772225E+10 * c7_gb_b;
  c7_w_a = c7_cc_y;
  c7_hb_b = c7_c_mpower(chartInstance, c7_dc_y + c7_ec_y);
  c7_fc_y = c7_w_a * c7_hb_b;
  c7_ib_b = c7_mpower(chartInstance, c7_lambda);
  c7_gc_y = 2.0982971025E+22 * c7_ib_b;
  c7_jb_x = c7_alpha;
  c7_kb_x = c7_jb_x;
  c7_kb_x = muDoubleScalarTan(c7_kb_x);
  c7_x_a = c7_gc_y;
  c7_jb_b = c7_mpower(chartInstance, c7_kb_x);
  c7_hc_y = c7_x_a * c7_jb_b;
  c7_y_a = c7_tb_y;
  c7_kb_b = (((c7_ub_y + c7_vb_y) - c7_ac_y) + c7_fc_y) + c7_hc_y;
  c7_ic_y = c7_y_a * c7_kb_b;
  c7_lb_b = c7_mpower(chartInstance, c7_lambda);
  c7_jc_y = 1.89225E+11 * c7_lb_b;
  c7_lb_x = c7_alpha;
  c7_mb_x = c7_lb_x;
  c7_mb_x = muDoubleScalarTan(c7_mb_x);
  c7_mb_b = c7_mpower(chartInstance, c7_mb_x);
  c7_kc_y = 2.772225E+10 * c7_mb_b;
  c7_nb_b = c7_d_mpower(chartInstance, c7_jc_y + c7_kc_y);
  c7_lc_y = 2.0 * c7_nb_b;
  c7_g_A = -c7_ic_y;
  c7_i_B = c7_lc_y;
  c7_nb_x = c7_g_A;
  c7_mc_y = c7_i_B;
  c7_ob_x = c7_nb_x;
  c7_nc_y = c7_mc_y;
  c7_df_D2_dalpha = c7_ob_x / c7_nc_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 34);
  c7_ob_b = c7_lambda;
  c7_oc_y = 435000.0 * c7_ob_b;
  c7_ab_a = c7_oc_y;
  c7_pb_b = c7_lambda;
  c7_b_sign(chartInstance, &c7_pb_b);
  c7_pc_y = c7_ab_a * c7_pb_b;
  c7_h_A = c7_pc_y;
  c7_j_B = c7_mpower(chartInstance, c7_abs(chartInstance, c7_lambda) - 1.0);
  c7_pb_x = c7_h_A;
  c7_qc_y = c7_j_B;
  c7_qb_x = c7_pb_x;
  c7_rc_y = c7_qc_y;
  c7_sc_y = c7_qb_x / c7_rc_y;
  c7_k_B = c7_abs(chartInstance, c7_lambda) - 1.0;
  c7_tc_y = c7_k_B;
  c7_uc_y = c7_tc_y;
  c7_vc_y = 435000.0 / c7_uc_y;
  c7_df_D1_dlambda = c7_sc_y - c7_vc_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 35);
  c7_qb_b = c7_Fz0;
  c7_wc_y = 435000.0 * c7_qb_b;
  c7_bb_a = c7_wc_y;
  c7_rb_b = c7_mup;
  c7_xc_y = c7_bb_a * c7_rb_b;
  c7_sb_b = c7_mpower(chartInstance, c7_lambda);
  c7_yc_y = 1.89225E+11 * c7_sb_b;
  c7_rb_x = c7_alpha;
  c7_sb_x = c7_rb_x;
  c7_sb_x = muDoubleScalarTan(c7_sb_x);
  c7_tb_b = c7_mpower(chartInstance, c7_sb_x);
  c7_ad_y = 2.772225E+10 * c7_tb_b;
  c7_i_A = c7_xc_y;
  c7_l_B = c7_e_mpower(chartInstance, c7_yc_y + c7_ad_y);
  c7_tb_x = c7_i_A;
  c7_bd_y = c7_l_B;
  c7_ub_x = c7_tb_x;
  c7_cd_y = c7_bd_y;
  c7_dd_y = c7_ub_x / c7_cd_y;
  c7_ub_b = c7_mpower(chartInstance, c7_Fz0);
  c7_ed_y = 435000.0 * c7_ub_b;
  c7_cb_a = c7_ed_y;
  c7_vb_b = c7_mpower(chartInstance, c7_mup);
  c7_fd_y = c7_cb_a * c7_vb_b;
  c7_wb_b = c7_mpower(chartInstance, c7_lambda);
  c7_gd_y = 1.89225E+11 * c7_wb_b;
  c7_vb_x = c7_alpha;
  c7_wb_x = c7_vb_x;
  c7_wb_x = muDoubleScalarTan(c7_wb_x);
  c7_xb_b = c7_mpower(chartInstance, c7_wb_x);
  c7_hd_y = 2.772225E+10 * c7_xb_b;
  c7_yb_b = c7_gd_y + c7_hd_y;
  c7_id_y = 4.0 * c7_yb_b;
  c7_j_A = c7_fd_y;
  c7_m_B = c7_id_y;
  c7_xb_x = c7_j_A;
  c7_jd_y = c7_m_B;
  c7_yb_x = c7_xb_x;
  c7_kd_y = c7_jd_y;
  c7_ld_y = c7_yb_x / c7_kd_y;
  c7_ac_b = c7_Fz0;
  c7_md_y = 8.2312875E+16 * c7_ac_b;
  c7_db_a = c7_md_y;
  c7_bc_b = c7_mpower(chartInstance, c7_lambda);
  c7_nd_y = c7_db_a * c7_bc_b;
  c7_eb_a = c7_nd_y;
  c7_cc_b = c7_mup;
  c7_od_y = c7_eb_a * c7_cc_b;
  c7_dc_b = c7_mpower(chartInstance, c7_lambda);
  c7_pd_y = 1.89225E+11 * c7_dc_b;
  c7_ac_x = c7_alpha;
  c7_bc_x = c7_ac_x;
  c7_bc_x = muDoubleScalarTan(c7_bc_x);
  c7_ec_b = c7_mpower(chartInstance, c7_bc_x);
  c7_qd_y = 2.772225E+10 * c7_ec_b;
  c7_k_A = c7_od_y;
  c7_n_B = c7_c_mpower(chartInstance, c7_pd_y + c7_qd_y);
  c7_cc_x = c7_k_A;
  c7_rd_y = c7_n_B;
  c7_dc_x = c7_cc_x;
  c7_sd_y = c7_rd_y;
  c7_td_y = c7_dc_x / c7_sd_y;
  c7_fc_b = c7_mpower(chartInstance, c7_Fz0);
  c7_ud_y = 435000.0 * c7_fc_b;
  c7_fb_a = c7_ud_y;
  c7_gc_b = c7_mpower(chartInstance, c7_mup);
  c7_vd_y = c7_fb_a * c7_gc_b;
  c7_gb_a = c7_vd_y;
  c7_hc_b = c7_abs(chartInstance, c7_lambda);
  c7_wd_y = c7_gb_a * c7_hc_b;
  c7_ic_b = c7_mpower(chartInstance, c7_lambda);
  c7_xd_y = 1.89225E+11 * c7_ic_b;
  c7_ec_x = c7_alpha;
  c7_fc_x = c7_ec_x;
  c7_fc_x = muDoubleScalarTan(c7_fc_x);
  c7_jc_b = c7_mpower(chartInstance, c7_fc_x);
  c7_yd_y = 2.772225E+10 * c7_jc_b;
  c7_kc_b = c7_xd_y + c7_yd_y;
  c7_ae_y = 4.0 * c7_kc_b;
  c7_l_A = c7_wd_y;
  c7_o_B = c7_ae_y;
  c7_gc_x = c7_l_A;
  c7_be_y = c7_o_B;
  c7_hc_x = c7_gc_x;
  c7_ce_y = c7_be_y;
  c7_de_y = c7_hc_x / c7_ce_y;
  c7_lc_b = c7_mpower(chartInstance, c7_Fz0);
  c7_ee_y = 8.2312875E+16 * c7_lc_b;
  c7_hb_a = c7_ee_y;
  c7_mc_b = c7_mpower(chartInstance, c7_lambda);
  c7_fe_y = c7_hb_a * c7_mc_b;
  c7_ib_a = c7_fe_y;
  c7_nc_b = c7_mpower(chartInstance, c7_mup);
  c7_ge_y = c7_ib_a * c7_nc_b;
  c7_ic_x = c7_alpha;
  c7_jc_x = c7_ic_x;
  c7_jc_x = muDoubleScalarTan(c7_jc_x);
  c7_oc_b = c7_b_mpower(chartInstance, c7_jc_x);
  c7_he_y = 7.685231450625E+20 * c7_oc_b;
  c7_pc_b = c7_b_mpower(chartInstance, c7_lambda);
  c7_ie_y = 3.5806100625E+22 * c7_pc_b;
  c7_qc_b = c7_mpower(chartInstance, c7_lambda);
  c7_je_y = 1.04914855125E+22 * c7_qc_b;
  c7_kc_x = c7_alpha;
  c7_lc_x = c7_kc_x;
  c7_lc_x = muDoubleScalarTan(c7_lc_x);
  c7_jb_a = c7_je_y;
  c7_rc_b = c7_mpower(chartInstance, c7_lc_x);
  c7_ke_y = c7_jb_a * c7_rc_b;
  c7_sc_b = (c7_he_y + c7_ie_y) + c7_ke_y;
  c7_le_y = 2.0 * c7_sc_b;
  c7_m_A = c7_ge_y;
  c7_p_B = c7_le_y;
  c7_mc_x = c7_m_A;
  c7_me_y = c7_p_B;
  c7_nc_x = c7_mc_x;
  c7_ne_y = c7_me_y;
  c7_oe_y = c7_nc_x / c7_ne_y;
  c7_tc_b = c7_mpower(chartInstance, c7_Fz0);
  c7_pe_y = 435000.0 * c7_tc_b;
  c7_kb_a = c7_pe_y;
  c7_uc_b = c7_lambda;
  c7_qe_y = c7_kb_a * c7_uc_b;
  c7_lb_a = c7_qe_y;
  c7_vc_b = c7_mpower(chartInstance, c7_mup);
  c7_re_y = c7_lb_a * c7_vc_b;
  c7_oc_x = c7_lambda;
  c7_pc_x = c7_oc_x;
  c7_pc_x = muDoubleScalarSign(c7_pc_x);
  c7_mb_a = c7_re_y;
  c7_wc_b = c7_pc_x;
  c7_se_y = c7_mb_a * c7_wc_b;
  c7_xc_b = c7_mpower(chartInstance, c7_lambda);
  c7_te_y = 1.89225E+11 * c7_xc_b;
  c7_qc_x = c7_alpha;
  c7_rc_x = c7_qc_x;
  c7_rc_x = muDoubleScalarTan(c7_rc_x);
  c7_yc_b = c7_mpower(chartInstance, c7_rc_x);
  c7_ue_y = 2.772225E+10 * c7_yc_b;
  c7_ad_b = c7_te_y + c7_ue_y;
  c7_ve_y = 4.0 * c7_ad_b;
  c7_n_A = c7_se_y;
  c7_q_B = c7_ve_y;
  c7_sc_x = c7_n_A;
  c7_we_y = c7_q_B;
  c7_tc_x = c7_sc_x;
  c7_xe_y = c7_we_y;
  c7_ye_y = c7_tc_x / c7_xe_y;
  c7_bd_b = c7_mpower(chartInstance, c7_Fz0);
  c7_af_y = 8.2312875E+16 * c7_bd_b;
  c7_nb_a = c7_af_y;
  c7_cd_b = c7_mpower(chartInstance, c7_lambda);
  c7_bf_y = c7_nb_a * c7_cd_b;
  c7_ob_a = c7_bf_y;
  c7_dd_b = c7_mpower(chartInstance, c7_mup);
  c7_cf_y = c7_ob_a * c7_dd_b;
  c7_uc_x = c7_lambda;
  c7_vc_x = c7_uc_x;
  c7_df_y = muDoubleScalarAbs(c7_vc_x);
  c7_pb_a = c7_cf_y;
  c7_ed_b = c7_df_y;
  c7_ef_y = c7_pb_a * c7_ed_b;
  c7_wc_x = c7_alpha;
  c7_xc_x = c7_wc_x;
  c7_xc_x = muDoubleScalarTan(c7_xc_x);
  c7_fd_b = c7_b_mpower(chartInstance, c7_xc_x);
  c7_ff_y = 7.685231450625E+20 * c7_fd_b;
  c7_gd_b = c7_b_mpower(chartInstance, c7_lambda);
  c7_gf_y = 3.5806100625E+22 * c7_gd_b;
  c7_hd_b = c7_mpower(chartInstance, c7_lambda);
  c7_hf_y = 1.04914855125E+22 * c7_hd_b;
  c7_yc_x = c7_alpha;
  c7_ad_x = c7_yc_x;
  c7_ad_x = muDoubleScalarTan(c7_ad_x);
  c7_qb_a = c7_hf_y;
  c7_id_b = c7_mpower(chartInstance, c7_ad_x);
  c7_if_y = c7_qb_a * c7_id_b;
  c7_jd_b = (c7_ff_y + c7_gf_y) + c7_if_y;
  c7_jf_y = 2.0 * c7_jd_b;
  c7_o_A = c7_ef_y;
  c7_r_B = c7_jf_y;
  c7_bd_x = c7_o_A;
  c7_kf_y = c7_r_B;
  c7_cd_x = c7_bd_x;
  c7_lf_y = c7_kf_y;
  c7_mf_y = c7_cd_x / c7_lf_y;
  c7_df_D2_dlambda = (((((c7_dd_y - c7_ld_y) - c7_td_y) + c7_de_y) + c7_oe_y) +
                      c7_ye_y) - c7_mf_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 37);
  c7_rb_a = c7_mup;
  c7_kd_b = c7_Fz0;
  c7_nf_y = c7_rb_a * c7_kd_b;
  c7_dd_x = c7_lambda;
  c7_ed_x = c7_dd_x;
  c7_of_y = muDoubleScalarAbs(c7_ed_x);
  c7_sb_a = c7_nf_y;
  c7_ld_b = 1.0 - c7_of_y;
  c7_pf_y = c7_sb_a * c7_ld_b;
  c7_md_b = c7_mpower(chartInstance, c7_lambda);
  c7_qf_y = 1.89225E+11 * c7_md_b;
  c7_fd_x = c7_alpha;
  c7_gd_x = c7_fd_x;
  c7_gd_x = muDoubleScalarTan(c7_gd_x);
  c7_nd_b = c7_mpower(chartInstance, c7_gd_x);
  c7_rf_y = 2.772225E+10 * c7_nd_b;
  c7_hd_x = c7_qf_y + c7_rf_y;
  c7_id_x = c7_hd_x;
  if (c7_id_x < 0.0) {
    c7_b_eml_error(chartInstance);
  }

  c7_id_x = muDoubleScalarSqrt(c7_id_x);
  c7_od_b = c7_id_x;
  c7_sf_y = 2.0 * c7_od_b;
  c7_p_A = c7_pf_y;
  c7_s_B = c7_sf_y;
  c7_jd_x = c7_p_A;
  c7_tf_y = c7_s_B;
  c7_kd_x = c7_jd_x;
  c7_uf_y = c7_tf_y;
  c7_sprime = c7_kd_x / c7_uf_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 39);
  if (CV_EML_IF(0, 1, 0, c7_sprime >= 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 40);
    c7_df_D_lambda = c7_df_D1_dlambda;
  }

  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 42);
  if (CV_EML_IF(0, 1, 1, c7_sprime < 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 43);
    c7_df_D_lambda = c7_df_D2_dlambda;
  }

  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 46);
  if (CV_EML_IF(0, 1, 2, c7_sprime >= 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 47);
    c7_df_D_dalpha = c7_df_D1_dalpha;
  }

  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 49);
  if (CV_EML_IF(0, 1, 3, c7_sprime < 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 50);
    c7_df_D_dalpha = c7_df_D2_dalpha;
  }

  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, 53);
  c7_tb_a = c7_Flf;
  c7_vf_y = c7_tb_a * 0.344;
  c7_ub_a = c7_Omega;
  c7_pd_b = c7_IOmega;
  c7_wf_y = c7_ub_a * c7_pd_b;
  c7_t_B = c7_VOmegaa;
  c7_xf_y = c7_t_B;
  c7_yf_y = c7_xf_y;
  c7_ag_y = 1.0 / c7_yf_y;
  c7_vb_a = c7_dy;
  c7_qd_b = c7_r;
  c7_bg_y = c7_vb_a * c7_qd_b;
  c7_ld_x = c7_delta;
  c7_md_x = c7_ld_x;
  c7_md_x = muDoubleScalarCos(c7_md_x);
  c7_wb_a = c7_ddx + c7_bg_y;
  c7_rd_b = c7_md_x;
  c7_cg_y = c7_wb_a * c7_rd_b;
  c7_xb_a = c7_dx;
  c7_sd_b = c7_r;
  c7_dg_y = c7_xb_a * c7_sd_b;
  c7_nd_x = c7_delta;
  c7_od_x = c7_nd_x;
  c7_od_x = muDoubleScalarSin(c7_od_x);
  c7_yb_a = c7_ddy - c7_dg_y;
  c7_td_b = c7_od_x;
  c7_eg_y = c7_yb_a * c7_td_b;
  c7_ac_a = c7_ag_y;
  c7_ud_b = c7_cg_y + c7_eg_y;
  c7_fg_y = c7_ac_a * c7_ud_b;
  c7_pd_x = c7_lambda;
  c7_qd_x = c7_pd_x;
  c7_gg_y = muDoubleScalarAbs(c7_qd_x);
  c7_q_A = c7_Fz0;
  c7_u_B = 1.0 - c7_gg_y;
  c7_rd_x = c7_q_A;
  c7_hg_y = c7_u_B;
  c7_sd_x = c7_rd_x;
  c7_ig_y = c7_hg_y;
  c7_jg_y = c7_sd_x / c7_ig_y;
  c7_bc_a = c7_Br;
  c7_vd_b = c7_r_dot;
  c7_kg_y = c7_bc_a * c7_vd_b;
  c7_cc_a = c7_Bdelta;
  c7_wd_b = c7_delta_dot;
  c7_lg_y = c7_cc_a * c7_wd_b;
  c7_v_B = c7_df_D_lambda;
  c7_mg_y = c7_v_B;
  c7_ng_y = c7_mg_y;
  c7_og_y = 1.0 / c7_ng_y;
  c7_dc_a = c7_og_y;
  c7_xd_b = c7_df_D_dalpha;
  c7_pg_y = c7_dc_a * c7_xd_b;
  c7_ec_a = c7_Cr;
  c7_yd_b = c7_r_dot;
  c7_qg_y = c7_ec_a * c7_yd_b;
  c7_r_A = c7_delta_dot;
  c7_w_B = c7_Fz0;
  c7_td_x = c7_r_A;
  c7_rg_y = c7_w_B;
  c7_ud_x = c7_td_x;
  c7_sg_y = c7_rg_y;
  c7_tg_y = c7_ud_x / c7_sg_y;
  c7_fc_a = c7_pg_y;
  c7_ae_b = (c7_C0 + c7_qg_y) + c7_tg_y;
  c7_ug_y = c7_fc_a * c7_ae_b;
  c7_s_A = c7_zeta - c7_Flf_dot;
  c7_x_B = c7_Fz0;
  c7_vd_x = c7_s_A;
  c7_vg_y = c7_x_B;
  c7_wd_x = c7_vd_x;
  c7_wg_y = c7_vg_y;
  c7_xg_y = c7_wd_x / c7_wg_y;
  c7_gc_a = c7_jg_y;
  c7_be_b = ((c7_kg_y + c7_lg_y) + c7_ug_y) + c7_xg_y;
  c7_yg_y = c7_gc_a * c7_be_b;
  c7_hc_a = c7_wf_y;
  c7_ce_b = c7_fg_y - c7_yg_y;
  c7_ah_y = c7_hc_a * c7_ce_b;
  c7_T = c7_vf_y + c7_ah_y;
  _SFD_EML_CALL(0U, chartInstance->c7_sfEvent, -53);
  _SFD_SYMBOL_SCOPE_POP();
  *c7_b_T = c7_T;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 6U, chartInstance->c7_sfEvent);
}

static void initSimStructsc7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc7_laneKeepingArcSplinesFF2013a
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber)
{
}

static const mxArray *c7_sf_marshallOut(void *chartInstanceVoid, void *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  real_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(real_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, FALSE);
  return c7_mxArrayOutData;
}

static real_T c7_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_T, const char_T *c7_identifier)
{
  real_T c7_y;
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_y = c7_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_T), &c7_thisId);
  sf_mex_destroy(&c7_T);
  return c7_y;
}

static real_T c7_b_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  real_T c7_y;
  real_T c7_d0;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_d0, 1, 0, 0U, 0, 0U, 0);
  c7_y = c7_d0;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_T;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  real_T c7_y;
  SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c7_T = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_y = c7_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_T), &c7_thisId);
  sf_mex_destroy(&c7_T);
  *(real_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

const mxArray
  *sf_c7_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c7_nameCaptureInfo;
  c7_ResolvedFunctionInfo c7_info[28];
  const mxArray *c7_m0 = NULL;
  int32_T c7_i0;
  c7_ResolvedFunctionInfo *c7_r0;
  c7_nameCaptureInfo = NULL;
  c7_nameCaptureInfo = NULL;
  c7_info_helper(c7_info);
  sf_mex_assign(&c7_m0, sf_mex_createstruct("nameCaptureInfo", 1, 28), FALSE);
  for (c7_i0 = 0; c7_i0 < 28; c7_i0++) {
    c7_r0 = &c7_info[c7_i0];
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c7_r0->context)), "context", "nameCaptureInfo",
                    c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c7_r0->name)), "name", "nameCaptureInfo", c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c7_r0->dominantType)), "dominantType",
                    "nameCaptureInfo", c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c7_r0->resolved)), "resolved", "nameCaptureInfo",
                    c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->mFileTimeLo,
      7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo", c7_i0);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->mFileTimeHi,
      7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo", c7_i0);
  }

  sf_mex_assign(&c7_nameCaptureInfo, c7_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c7_nameCaptureInfo);
  return c7_nameCaptureInfo;
}

static void c7_info_helper(c7_ResolvedFunctionInfo c7_info[28])
{
  c7_info[0].context = "";
  c7_info[0].name = "mtimes";
  c7_info[0].dominantType = "double";
  c7_info[0].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c7_info[0].fileTimeLo = 1289516092U;
  c7_info[0].fileTimeHi = 0U;
  c7_info[0].mFileTimeLo = 0U;
  c7_info[0].mFileTimeHi = 0U;
  c7_info[1].context = "";
  c7_info[1].name = "abs";
  c7_info[1].dominantType = "double";
  c7_info[1].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c7_info[1].fileTimeLo = 1343826766U;
  c7_info[1].fileTimeHi = 0U;
  c7_info[1].mFileTimeLo = 0U;
  c7_info[1].mFileTimeHi = 0U;
  c7_info[2].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c7_info[2].name = "eml_scalar_abs";
  c7_info[2].dominantType = "double";
  c7_info[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c7_info[2].fileTimeLo = 1286815112U;
  c7_info[2].fileTimeHi = 0U;
  c7_info[2].mFileTimeLo = 0U;
  c7_info[2].mFileTimeHi = 0U;
  c7_info[3].context = "";
  c7_info[3].name = "mrdivide";
  c7_info[3].dominantType = "double";
  c7_info[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c7_info[3].fileTimeLo = 1357947948U;
  c7_info[3].fileTimeHi = 0U;
  c7_info[3].mFileTimeLo = 1319726366U;
  c7_info[3].mFileTimeHi = 0U;
  c7_info[4].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c7_info[4].name = "rdivide";
  c7_info[4].dominantType = "double";
  c7_info[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[4].fileTimeLo = 1346506788U;
  c7_info[4].fileTimeHi = 0U;
  c7_info[4].mFileTimeLo = 0U;
  c7_info[4].mFileTimeHi = 0U;
  c7_info[5].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[5].name = "eml_scalexp_compatible";
  c7_info[5].dominantType = "double";
  c7_info[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  c7_info[5].fileTimeLo = 1286815196U;
  c7_info[5].fileTimeHi = 0U;
  c7_info[5].mFileTimeLo = 0U;
  c7_info[5].mFileTimeHi = 0U;
  c7_info[6].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[6].name = "eml_div";
  c7_info[6].dominantType = "double";
  c7_info[6].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c7_info[6].fileTimeLo = 1313344210U;
  c7_info[6].fileTimeHi = 0U;
  c7_info[6].mFileTimeLo = 0U;
  c7_info[6].mFileTimeHi = 0U;
  c7_info[7].context = "";
  c7_info[7].name = "sin";
  c7_info[7].dominantType = "double";
  c7_info[7].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c7_info[7].fileTimeLo = 1343826786U;
  c7_info[7].fileTimeHi = 0U;
  c7_info[7].mFileTimeLo = 0U;
  c7_info[7].mFileTimeHi = 0U;
  c7_info[8].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c7_info[8].name = "eml_scalar_sin";
  c7_info[8].dominantType = "double";
  c7_info[8].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m";
  c7_info[8].fileTimeLo = 1286815136U;
  c7_info[8].fileTimeHi = 0U;
  c7_info[8].mFileTimeLo = 0U;
  c7_info[8].mFileTimeHi = 0U;
  c7_info[9].context = "";
  c7_info[9].name = "cos";
  c7_info[9].dominantType = "double";
  c7_info[9].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c7_info[9].fileTimeLo = 1343826772U;
  c7_info[9].fileTimeHi = 0U;
  c7_info[9].mFileTimeLo = 0U;
  c7_info[9].mFileTimeHi = 0U;
  c7_info[10].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c7_info[10].name = "eml_scalar_cos";
  c7_info[10].dominantType = "double";
  c7_info[10].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c7_info[10].fileTimeLo = 1286815122U;
  c7_info[10].fileTimeHi = 0U;
  c7_info[10].mFileTimeLo = 0U;
  c7_info[10].mFileTimeHi = 0U;
  c7_info[11].context = "";
  c7_info[11].name = "mpower";
  c7_info[11].dominantType = "double";
  c7_info[11].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c7_info[11].fileTimeLo = 1286815242U;
  c7_info[11].fileTimeHi = 0U;
  c7_info[11].mFileTimeLo = 0U;
  c7_info[11].mFileTimeHi = 0U;
  c7_info[12].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c7_info[12].name = "power";
  c7_info[12].dominantType = "double";
  c7_info[12].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  c7_info[12].fileTimeLo = 1348188330U;
  c7_info[12].fileTimeHi = 0U;
  c7_info[12].mFileTimeLo = 0U;
  c7_info[12].mFileTimeHi = 0U;
  c7_info[13].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c7_info[13].name = "eml_scalar_eg";
  c7_info[13].dominantType = "double";
  c7_info[13].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c7_info[13].fileTimeLo = 1286815196U;
  c7_info[13].fileTimeHi = 0U;
  c7_info[13].mFileTimeLo = 0U;
  c7_info[13].mFileTimeHi = 0U;
  c7_info[14].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c7_info[14].name = "eml_scalexp_alloc";
  c7_info[14].dominantType = "double";
  c7_info[14].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c7_info[14].fileTimeLo = 1352421260U;
  c7_info[14].fileTimeHi = 0U;
  c7_info[14].mFileTimeLo = 0U;
  c7_info[14].mFileTimeHi = 0U;
  c7_info[15].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c7_info[15].name = "floor";
  c7_info[15].dominantType = "double";
  c7_info[15].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c7_info[15].fileTimeLo = 1343826780U;
  c7_info[15].fileTimeHi = 0U;
  c7_info[15].mFileTimeLo = 0U;
  c7_info[15].mFileTimeHi = 0U;
  c7_info[16].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c7_info[16].name = "eml_scalar_floor";
  c7_info[16].dominantType = "double";
  c7_info[16].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c7_info[16].fileTimeLo = 1286815126U;
  c7_info[16].fileTimeHi = 0U;
  c7_info[16].mFileTimeLo = 0U;
  c7_info[16].mFileTimeHi = 0U;
  c7_info[17].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c7_info[17].name = "eml_scalar_eg";
  c7_info[17].dominantType = "double";
  c7_info[17].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c7_info[17].fileTimeLo = 1286815196U;
  c7_info[17].fileTimeHi = 0U;
  c7_info[17].mFileTimeLo = 0U;
  c7_info[17].mFileTimeHi = 0U;
  c7_info[18].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c7_info[18].name = "mtimes";
  c7_info[18].dominantType = "double";
  c7_info[18].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c7_info[18].fileTimeLo = 1289516092U;
  c7_info[18].fileTimeHi = 0U;
  c7_info[18].mFileTimeLo = 0U;
  c7_info[18].mFileTimeHi = 0U;
  c7_info[19].context = "";
  c7_info[19].name = "tan";
  c7_info[19].dominantType = "double";
  c7_info[19].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/tan.m";
  c7_info[19].fileTimeLo = 1343826786U;
  c7_info[19].fileTimeHi = 0U;
  c7_info[19].mFileTimeLo = 0U;
  c7_info[19].mFileTimeHi = 0U;
  c7_info[20].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/tan.m";
  c7_info[20].name = "eml_scalar_tan";
  c7_info[20].dominantType = "double";
  c7_info[20].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_tan.m";
  c7_info[20].fileTimeLo = 1286815138U;
  c7_info[20].fileTimeHi = 0U;
  c7_info[20].mFileTimeLo = 0U;
  c7_info[20].mFileTimeHi = 0U;
  c7_info[21].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c7_info[21].name = "eml_error";
  c7_info[21].dominantType = "char";
  c7_info[21].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c7_info[21].fileTimeLo = 1343826758U;
  c7_info[21].fileTimeHi = 0U;
  c7_info[21].mFileTimeLo = 0U;
  c7_info[21].mFileTimeHi = 0U;
  c7_info[22].context = "";
  c7_info[22].name = "sign";
  c7_info[22].dominantType = "double";
  c7_info[22].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c7_info[22].fileTimeLo = 1354364464U;
  c7_info[22].fileTimeHi = 0U;
  c7_info[22].mFileTimeLo = 0U;
  c7_info[22].mFileTimeHi = 0U;
  c7_info[23].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c7_info[23].name = "eml_scalar_sign";
  c7_info[23].dominantType = "double";
  c7_info[23].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sign.m";
  c7_info[23].fileTimeLo = 1354364464U;
  c7_info[23].fileTimeHi = 0U;
  c7_info[23].mFileTimeLo = 0U;
  c7_info[23].mFileTimeHi = 0U;
  c7_info[24].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c7_info[24].name = "sqrt";
  c7_info[24].dominantType = "double";
  c7_info[24].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c7_info[24].fileTimeLo = 1343826786U;
  c7_info[24].fileTimeHi = 0U;
  c7_info[24].mFileTimeLo = 0U;
  c7_info[24].mFileTimeHi = 0U;
  c7_info[25].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c7_info[25].name = "eml_error";
  c7_info[25].dominantType = "char";
  c7_info[25].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c7_info[25].fileTimeLo = 1343826758U;
  c7_info[25].fileTimeHi = 0U;
  c7_info[25].mFileTimeLo = 0U;
  c7_info[25].mFileTimeHi = 0U;
  c7_info[26].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c7_info[26].name = "eml_scalar_sqrt";
  c7_info[26].dominantType = "double";
  c7_info[26].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c7_info[26].fileTimeLo = 1286815138U;
  c7_info[26].fileTimeHi = 0U;
  c7_info[26].mFileTimeLo = 0U;
  c7_info[26].mFileTimeHi = 0U;
  c7_info[27].context = "";
  c7_info[27].name = "sqrt";
  c7_info[27].dominantType = "double";
  c7_info[27].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c7_info[27].fileTimeLo = 1343826786U;
  c7_info[27].fileTimeHi = 0U;
  c7_info[27].mFileTimeLo = 0U;
  c7_info[27].mFileTimeHi = 0U;
}

static real_T c7_abs(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c7_x)
{
  real_T c7_b_x;
  c7_b_x = c7_x;
  return muDoubleScalarAbs(c7_b_x);
}

static real_T c7_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a)
{
  real_T c7_b_a;
  real_T c7_c_a;
  real_T c7_ak;
  real_T c7_d_a;
  real_T c7_e_a;
  real_T c7_b;
  c7_b_a = c7_a;
  c7_c_a = c7_b_a;
  c7_eml_scalar_eg(chartInstance);
  c7_ak = c7_c_a;
  c7_d_a = c7_ak;
  c7_eml_scalar_eg(chartInstance);
  c7_e_a = c7_d_a;
  c7_b = c7_d_a;
  return c7_e_a * c7_b;
}

static void c7_eml_scalar_eg(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
}

static real_T c7_b_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a)
{
  real_T c7_b_a;
  real_T c7_c_a;
  real_T c7_ak;
  real_T c7_d_a;
  real_T c7_ar;
  c7_b_a = c7_a;
  c7_c_a = c7_b_a;
  c7_eml_scalar_eg(chartInstance);
  c7_ak = c7_c_a;
  c7_d_a = c7_ak;
  c7_eml_scalar_eg(chartInstance);
  c7_ar = c7_d_a;
  return muDoubleScalarPower(c7_ar, 4.0);
}

static real_T c7_c_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a)
{
  real_T c7_b_a;
  real_T c7_c_a;
  real_T c7_ak;
  real_T c7_d_a;
  real_T c7_ar;
  c7_b_a = c7_a;
  c7_c_a = c7_b_a;
  c7_eml_scalar_eg(chartInstance);
  c7_ak = c7_c_a;
  if (c7_ak < 0.0) {
    c7_eml_error(chartInstance);
  }

  c7_d_a = c7_ak;
  c7_eml_scalar_eg(chartInstance);
  c7_ar = c7_d_a;
  return muDoubleScalarPower(c7_ar, 1.5);
}

static void c7_eml_error(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c7_i1;
  static char_T c7_cv0[31] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'p', 'o', 'w', 'e', 'r', '_', 'd', 'o', 'm', 'a', 'i',
    'n', 'E', 'r', 'r', 'o', 'r' };

  char_T c7_u[31];
  const mxArray *c7_y = NULL;
  for (c7_i1 = 0; c7_i1 < 31; c7_i1++) {
    c7_u[c7_i1] = c7_cv0[c7_i1];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 31), FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 1U, 14,
    c7_y));
}

static real_T c7_d_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a)
{
  real_T c7_b_a;
  real_T c7_c_a;
  real_T c7_ak;
  real_T c7_d_a;
  real_T c7_ar;
  c7_b_a = c7_a;
  c7_c_a = c7_b_a;
  c7_eml_scalar_eg(chartInstance);
  c7_ak = c7_c_a;
  if (c7_ak < 0.0) {
    c7_eml_error(chartInstance);
  }

  c7_d_a = c7_ak;
  c7_eml_scalar_eg(chartInstance);
  c7_ar = c7_d_a;
  return muDoubleScalarPower(c7_ar, 3.5);
}

static real_T c7_sign(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c7_x)
{
  real_T c7_b_x;
  c7_b_x = c7_x;
  c7_b_sign(chartInstance, &c7_b_x);
  return c7_b_x;
}

static real_T c7_e_mpower(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c7_a)
{
  real_T c7_c;
  real_T c7_b_a;
  real_T c7_c_a;
  real_T c7_ak;
  real_T c7_d_a;
  real_T c7_x;
  c7_b_a = c7_a;
  c7_c_a = c7_b_a;
  c7_eml_scalar_eg(chartInstance);
  c7_ak = c7_c_a;
  if (c7_ak < 0.0) {
    c7_eml_error(chartInstance);
  }

  c7_d_a = c7_ak;
  c7_eml_scalar_eg(chartInstance);
  c7_x = c7_d_a;
  c7_c = c7_x;
  if (c7_c < 0.0) {
    c7_b_eml_error(chartInstance);
  }

  return muDoubleScalarSqrt(c7_c);
}

static void c7_b_eml_error(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c7_i2;
  static char_T c7_cv1[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  char_T c7_u[30];
  const mxArray *c7_y = NULL;
  int32_T c7_i3;
  static char_T c7_cv2[4] = { 's', 'q', 'r', 't' };

  char_T c7_b_u[4];
  const mxArray *c7_b_y = NULL;
  for (c7_i2 = 0; c7_i2 < 30; c7_i2++) {
    c7_u[c7_i2] = c7_cv1[c7_i2];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 30), FALSE);
  for (c7_i3 = 0; c7_i3 < 4; c7_i3++) {
    c7_b_u[c7_i3] = c7_cv2[c7_i3];
  }

  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 2U, 14,
    c7_y, 14, c7_b_y));
}

static const mxArray *c7_b_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  int32_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(int32_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, FALSE);
  return c7_mxArrayOutData;
}

static int32_T c7_c_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  int32_T c7_y;
  int32_T c7_i4;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_i4, 1, 6, 0U, 0, 0U, 0);
  c7_y = c7_i4;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_b_sfEvent;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  int32_T c7_y;
  SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c7_b_sfEvent = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_y = c7_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_b_sfEvent),
    &c7_thisId);
  sf_mex_destroy(&c7_b_sfEvent);
  *(int32_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static uint8_T c7_d_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_b_is_active_c7_laneKeepingArcSplinesFF2013a, const char_T *c7_identifier)
{
  uint8_T c7_y;
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_y = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c7_b_is_active_c7_laneKeepingArcSplinesFF2013a), &c7_thisId);
  sf_mex_destroy(&c7_b_is_active_c7_laneKeepingArcSplinesFF2013a);
  return c7_y;
}

static uint8_T c7_e_emlrt_marshallIn
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  uint8_T c7_y;
  uint8_T c7_u0;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_u0, 1, 3, 0U, 0, 0U, 0);
  c7_y = c7_u0;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_b_sign(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c7_x)
{
  *c7_x = muDoubleScalarSign(*c7_x);
}

static void init_dsm_address_info
  (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c7_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2673191558U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4039794039U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4132069516U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(338304628U);
}

mxArray *sf_c7_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("gJWTKjM0iFb0wpnQLjrjqC");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,23,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,8,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,8,"type",mxType);
    }

    mxSetField(mxData,8,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,9,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,9,"type",mxType);
    }

    mxSetField(mxData,9,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,10,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,10,"type",mxType);
    }

    mxSetField(mxData,10,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,11,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,11,"type",mxType);
    }

    mxSetField(mxData,11,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,12,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,12,"type",mxType);
    }

    mxSetField(mxData,12,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,13,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,13,"type",mxType);
    }

    mxSetField(mxData,13,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,14,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,14,"type",mxType);
    }

    mxSetField(mxData,14,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,15,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,15,"type",mxType);
    }

    mxSetField(mxData,15,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,16,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,16,"type",mxType);
    }

    mxSetField(mxData,16,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,17,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,17,"type",mxType);
    }

    mxSetField(mxData,17,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,18,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,18,"type",mxType);
    }

    mxSetField(mxData,18,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,19,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,19,"type",mxType);
    }

    mxSetField(mxData,19,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,20,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,20,"type",mxType);
    }

    mxSetField(mxData,20,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,21,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,21,"type",mxType);
    }

    mxSetField(mxData,21,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,22,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,22,"type",mxType);
    }

    mxSetField(mxData,22,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c7_laneKeepingArcSplinesFF2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c7_laneKeepingArcSplinesFF2013a(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"T\",},{M[8],M[0],T\"is_active_c7_laneKeepingArcSplinesFF2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c7_laneKeepingArcSplinesFF2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
    chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF2013aMachineNumber_,
           7,
           1,
           1,
           24,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"r");
          _SFD_SET_DATA_PROPS(1,1,1,0,"Flf");
          _SFD_SET_DATA_PROPS(2,1,1,0,"Flf_dot");
          _SFD_SET_DATA_PROPS(3,1,1,0,"delta_dot");
          _SFD_SET_DATA_PROPS(4,1,1,0,"r_dot");
          _SFD_SET_DATA_PROPS(5,1,1,0,"dy");
          _SFD_SET_DATA_PROPS(6,1,1,0,"delta");
          _SFD_SET_DATA_PROPS(7,1,1,0,"alpha");
          _SFD_SET_DATA_PROPS(8,1,1,0,"dx");
          _SFD_SET_DATA_PROPS(9,1,1,0,"VOmegax");
          _SFD_SET_DATA_PROPS(10,1,1,0,"VOmega");
          _SFD_SET_DATA_PROPS(11,1,1,0,"IOmega");
          _SFD_SET_DATA_PROPS(12,1,1,0,"df_D_lambda");
          _SFD_SET_DATA_PROPS(13,1,1,0,"ddx");
          _SFD_SET_DATA_PROPS(14,1,1,0,"df_D_dalpha");
          _SFD_SET_DATA_PROPS(15,1,1,0,"ddy");
          _SFD_SET_DATA_PROPS(16,1,1,0,"VOmegay");
          _SFD_SET_DATA_PROPS(17,1,1,0,"mup");
          _SFD_SET_DATA_PROPS(18,1,1,0,"Fz0");
          _SFD_SET_DATA_PROPS(19,1,1,0,"VOmegaa");
          _SFD_SET_DATA_PROPS(20,1,1,0,"Omega");
          _SFD_SET_DATA_PROPS(21,1,1,0,"Fa");
          _SFD_SET_DATA_PROPS(22,1,1,0,"lambda");
          _SFD_SET_DATA_PROPS(23,2,0,1,"T");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,4,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,2514);
        _SFD_CV_INIT_EML_IF(0,1,0,2048,2062,-1,2100);
        _SFD_CV_INIT_EML_IF(0,1,1,2102,2115,-1,2153);
        _SFD_CV_INIT_EML_IF(0,1,2,2164,2178,-1,2215);
        _SFD_CV_INIT_EML_IF(0,1,3,2217,2230,-1,2267);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(18,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(19,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(20,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(21,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(22,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(23,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)c7_sf_marshallIn);

        {
          real_T *c7_r;
          real_T *c7_Flf;
          real_T *c7_Flf_dot;
          real_T *c7_delta_dot;
          real_T *c7_r_dot;
          real_T *c7_dy;
          real_T *c7_delta;
          real_T *c7_alpha;
          real_T *c7_dx;
          real_T *c7_VOmegax;
          real_T *c7_VOmega;
          real_T *c7_IOmega;
          real_T *c7_df_D_lambda;
          real_T *c7_ddx;
          real_T *c7_df_D_dalpha;
          real_T *c7_ddy;
          real_T *c7_VOmegay;
          real_T *c7_mup;
          real_T *c7_Fz0;
          real_T *c7_VOmegaa;
          real_T *c7_Omega;
          real_T *c7_Fa;
          real_T *c7_lambda;
          real_T *c7_T;
          c7_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c7_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
          c7_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
          c7_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
          c7_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
          c7_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
          c7_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
          c7_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
          c7_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
          c7_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
          c7_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
          c7_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
          c7_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
          c7_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
          c7_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
          c7_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
          c7_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
          c7_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c7_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c7_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c7_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c7_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c7_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c7_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c7_r);
          _SFD_SET_DATA_VALUE_PTR(1U, c7_Flf);
          _SFD_SET_DATA_VALUE_PTR(2U, c7_Flf_dot);
          _SFD_SET_DATA_VALUE_PTR(3U, c7_delta_dot);
          _SFD_SET_DATA_VALUE_PTR(4U, c7_r_dot);
          _SFD_SET_DATA_VALUE_PTR(5U, c7_dy);
          _SFD_SET_DATA_VALUE_PTR(6U, c7_delta);
          _SFD_SET_DATA_VALUE_PTR(7U, c7_alpha);
          _SFD_SET_DATA_VALUE_PTR(8U, c7_dx);
          _SFD_SET_DATA_VALUE_PTR(9U, c7_VOmegax);
          _SFD_SET_DATA_VALUE_PTR(10U, c7_VOmega);
          _SFD_SET_DATA_VALUE_PTR(11U, c7_IOmega);
          _SFD_SET_DATA_VALUE_PTR(12U, c7_df_D_lambda);
          _SFD_SET_DATA_VALUE_PTR(13U, c7_ddx);
          _SFD_SET_DATA_VALUE_PTR(14U, c7_df_D_dalpha);
          _SFD_SET_DATA_VALUE_PTR(15U, c7_ddy);
          _SFD_SET_DATA_VALUE_PTR(16U, c7_VOmegay);
          _SFD_SET_DATA_VALUE_PTR(17U, c7_mup);
          _SFD_SET_DATA_VALUE_PTR(18U, c7_Fz0);
          _SFD_SET_DATA_VALUE_PTR(19U, c7_VOmegaa);
          _SFD_SET_DATA_VALUE_PTR(20U, c7_Omega);
          _SFD_SET_DATA_VALUE_PTR(21U, c7_Fa);
          _SFD_SET_DATA_VALUE_PTR(22U, c7_lambda);
          _SFD_SET_DATA_VALUE_PTR(23U, c7_T);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "r7v1MFHkteIICz8lJkTkoC";
}

static void sf_opaque_initialize_c7_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
  initialize_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c7_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  enable_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c7_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  disable_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c7_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  sf_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c7_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c7_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c7_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c7_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c7_laneKeepingArcSplinesFF2013a(S);
}

static void sf_opaque_set_sim_state_c7_laneKeepingArcSplinesFF2013a(SimStruct* S,
  const mxArray *st)
{
  sf_internal_set_sim_state_c7_laneKeepingArcSplinesFF2013a(S, st);
}

static void sf_opaque_terminate_c7_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF2013a_optimization_info();
    }

    finalize_c7_laneKeepingArcSplinesFF2013a
      ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc7_laneKeepingArcSplinesFF2013a
    ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c7_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c7_laneKeepingArcSplinesFF2013a
      ((SFc7_laneKeepingArcSplinesFF2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c7_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      7);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,7,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,7,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,7);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 7, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 8, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 9, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 10, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 11, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 12, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 13, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 14, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 15, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 16, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 17, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 18, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 19, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 20, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 21, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 22, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,7,23);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,7,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 23; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,7);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(4043927683U));
  ssSetChecksum1(S,(3344300765U));
  ssSetChecksum2(S,(3439005895U));
  ssSetChecksum3(S,(3619973032U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c7_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c7_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct *)utMalloc
    (sizeof(SFc7_laneKeepingArcSplinesFF2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc7_laneKeepingArcSplinesFF2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c7_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c7_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c7_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c7_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c7_laneKeepingArcSplinesFF2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c7_laneKeepingArcSplinesFF2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
