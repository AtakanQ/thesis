#ifndef __c98_laneKeepingArcSplinesFF2013a_h__
#define __c98_laneKeepingArcSplinesFF2013a_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef typedef_c98_ResolvedFunctionInfo
#define typedef_c98_ResolvedFunctionInfo

typedef struct {
  const char * context;
  const char * name;
  const char * dominantType;
  const char * resolved;
  uint32_T fileTimeLo;
  uint32_T fileTimeHi;
  uint32_T mFileTimeLo;
  uint32_T mFileTimeHi;
} c98_ResolvedFunctionInfo;

#endif                                 /*typedef_c98_ResolvedFunctionInfo*/

#ifndef typedef_SFc98_laneKeepingArcSplinesFF2013aInstanceStruct
#define typedef_SFc98_laneKeepingArcSplinesFF2013aInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c98_sfEvent;
  boolean_T c98_isStable;
  boolean_T c98_doneDoubleBufferReInit;
  uint8_T c98_is_active_c98_laneKeepingArcSplinesFF2013a;
} SFc98_laneKeepingArcSplinesFF2013aInstanceStruct;

#endif                                 /*typedef_SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c98_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c98_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[]);
extern void c98_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S,
  int_T method, void *data);

#endif
