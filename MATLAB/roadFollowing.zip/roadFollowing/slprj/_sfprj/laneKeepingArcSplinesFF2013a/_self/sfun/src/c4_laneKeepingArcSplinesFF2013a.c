/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "c4_laneKeepingArcSplinesFF2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c4_debug_family_names[42] = { "PX", "PY", "CXvec", "CYvec",
  "Rvec", "thetaSvec", "thetaRvec", "j", "theta", "thetaRnew", "thetaSnew",
  "distVec", "n", "intVec", "distNew", "Svec", "Evec", "v", "dir", "f", "theta1",
  "distVec1", "n1", "intVec1", "distNew1", "dir1", "nargin", "nargout",
  "CircleData", "LineData", "X1", "Y1", "Psi", "dPsi", "vel", "l_S", "dist",
  "dist1", "deltaPsi", "deltadPsi", "rho", "rho1" };

/* Function Declarations */
static void initialize_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initialize_params_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void enable_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void disable_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c4_update_debugger_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void set_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_st);
static void finalize_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void sf_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c4_chartstep_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initSimStructsc4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void registerMessagesc4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c4_machineNumber, uint32_T
  c4_chartNumber);
static const mxArray *c4_sf_marshallOut(void *chartInstanceVoid, void *c4_inData);
static real_T c4_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_rho1, const char_T *c4_identifier);
static real_T c4_b_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId);
static void c4_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData);
static const mxArray *c4_b_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static const mxArray *c4_c_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static const mxArray *c4_d_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static void c4_c_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[2]);
static void c4_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData);
static const mxArray *c4_e_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static void c4_d_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[26]);
static void c4_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData);
static const mxArray *c4_f_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static void c4_e_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[52]);
static void c4_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData);
static void c4_info_helper(c4_ResolvedFunctionInfo c4_info[75]);
static real_T c4_sign(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x);
static real_T c4_atan2(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c4_y, real_T c4_x);
static void c4_eml_scalar_eg(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c4_mod(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c4_x, real_T c4_y);
static void c4_b_eml_scalar_eg(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c4_sqrt(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x);
static void c4_eml_error(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c4_abs(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c4_x);
static real_T c4_norm(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x[2]);
static real_T c4_mpower(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c4_a);
static const mxArray *c4_g_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData);
static int32_T c4_f_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId);
static void c4_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData);
static uint8_T c4_g_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_b_is_active_c4_laneKeepingArcSplinesFF2013a, const char_T *c4_identifier);
static uint8_T c4_h_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId);
static void c4_b_sign(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c4_x);
static void c4_b_sqrt(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c4_x);
static void init_dsm_address_info
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  chartInstance->c4_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c4_is_active_c4_laneKeepingArcSplinesFF2013a = 0U;
}

static void initialize_params_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void enable_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c4_update_debugger_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  const mxArray *c4_st;
  const mxArray *c4_y = NULL;
  real_T c4_hoistedGlobal;
  real_T c4_u;
  const mxArray *c4_b_y = NULL;
  real_T c4_b_hoistedGlobal;
  real_T c4_b_u;
  const mxArray *c4_c_y = NULL;
  real_T c4_c_hoistedGlobal;
  real_T c4_c_u;
  const mxArray *c4_d_y = NULL;
  real_T c4_d_hoistedGlobal;
  real_T c4_d_u;
  const mxArray *c4_e_y = NULL;
  real_T c4_e_hoistedGlobal;
  real_T c4_e_u;
  const mxArray *c4_f_y = NULL;
  real_T c4_f_hoistedGlobal;
  real_T c4_f_u;
  const mxArray *c4_g_y = NULL;
  uint8_T c4_g_hoistedGlobal;
  uint8_T c4_g_u;
  const mxArray *c4_h_y = NULL;
  real_T *c4_deltaPsi;
  real_T *c4_deltadPsi;
  real_T *c4_dist;
  real_T *c4_dist1;
  real_T *c4_rho;
  real_T *c4_rho1;
  c4_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c4_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c4_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c4_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c4_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c4_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c4_st = NULL;
  c4_st = NULL;
  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_createcellarray(7), FALSE);
  c4_hoistedGlobal = *c4_deltaPsi;
  c4_u = c4_hoistedGlobal;
  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 0, c4_b_y);
  c4_b_hoistedGlobal = *c4_deltadPsi;
  c4_b_u = c4_b_hoistedGlobal;
  c4_c_y = NULL;
  sf_mex_assign(&c4_c_y, sf_mex_create("y", &c4_b_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 1, c4_c_y);
  c4_c_hoistedGlobal = *c4_dist;
  c4_c_u = c4_c_hoistedGlobal;
  c4_d_y = NULL;
  sf_mex_assign(&c4_d_y, sf_mex_create("y", &c4_c_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 2, c4_d_y);
  c4_d_hoistedGlobal = *c4_dist1;
  c4_d_u = c4_d_hoistedGlobal;
  c4_e_y = NULL;
  sf_mex_assign(&c4_e_y, sf_mex_create("y", &c4_d_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 3, c4_e_y);
  c4_e_hoistedGlobal = *c4_rho;
  c4_e_u = c4_e_hoistedGlobal;
  c4_f_y = NULL;
  sf_mex_assign(&c4_f_y, sf_mex_create("y", &c4_e_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 4, c4_f_y);
  c4_f_hoistedGlobal = *c4_rho1;
  c4_f_u = c4_f_hoistedGlobal;
  c4_g_y = NULL;
  sf_mex_assign(&c4_g_y, sf_mex_create("y", &c4_f_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 5, c4_g_y);
  c4_g_hoistedGlobal =
    chartInstance->c4_is_active_c4_laneKeepingArcSplinesFF2013a;
  c4_g_u = c4_g_hoistedGlobal;
  c4_h_y = NULL;
  sf_mex_assign(&c4_h_y, sf_mex_create("y", &c4_g_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c4_y, 6, c4_h_y);
  sf_mex_assign(&c4_st, c4_y, FALSE);
  return c4_st;
}

static void set_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_st)
{
  const mxArray *c4_u;
  real_T *c4_deltaPsi;
  real_T *c4_deltadPsi;
  real_T *c4_dist;
  real_T *c4_dist1;
  real_T *c4_rho;
  real_T *c4_rho1;
  c4_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c4_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c4_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c4_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c4_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c4_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c4_doneDoubleBufferReInit = TRUE;
  c4_u = sf_mex_dup(c4_st);
  *c4_deltaPsi = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c4_u, 0)), "deltaPsi");
  *c4_deltadPsi = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c4_u, 1)), "deltadPsi");
  *c4_dist = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u,
    2)), "dist");
  *c4_dist1 = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u,
    3)), "dist1");
  *c4_rho = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u, 4)),
    "rho");
  *c4_rho1 = c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u,
    5)), "rho1");
  chartInstance->c4_is_active_c4_laneKeepingArcSplinesFF2013a =
    c4_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u, 6)),
    "is_active_c4_laneKeepingArcSplinesFF2013a");
  sf_mex_destroy(&c4_u);
  c4_update_debugger_state_c4_laneKeepingArcSplinesFF2013a(chartInstance);
  sf_mex_destroy(&c4_st);
}

static void finalize_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void sf_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  int32_T c4_i0;
  int32_T c4_i1;
  real_T *c4_dist;
  real_T *c4_X1;
  real_T *c4_Y1;
  real_T *c4_Psi;
  real_T *c4_dPsi;
  real_T *c4_vel;
  real_T *c4_l_S;
  real_T *c4_dist1;
  real_T *c4_deltaPsi;
  real_T *c4_deltadPsi;
  real_T *c4_rho;
  real_T *c4_rho1;
  real_T (*c4_LineData)[65];
  real_T (*c4_CircleData)[312];
  c4_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c4_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c4_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c4_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c4_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c4_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c4_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c4_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c4_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c4_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c4_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c4_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
  c4_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c4_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 3U, chartInstance->c4_sfEvent);
  for (c4_i0 = 0; c4_i0 < 312; c4_i0++) {
    _SFD_DATA_RANGE_CHECK((*c4_CircleData)[c4_i0], 0U);
  }

  _SFD_DATA_RANGE_CHECK(*c4_dist, 1U);
  for (c4_i1 = 0; c4_i1 < 65; c4_i1++) {
    _SFD_DATA_RANGE_CHECK((*c4_LineData)[c4_i1], 2U);
  }

  _SFD_DATA_RANGE_CHECK(*c4_X1, 3U);
  _SFD_DATA_RANGE_CHECK(*c4_Y1, 4U);
  _SFD_DATA_RANGE_CHECK(*c4_Psi, 5U);
  _SFD_DATA_RANGE_CHECK(*c4_dPsi, 6U);
  _SFD_DATA_RANGE_CHECK(*c4_vel, 7U);
  _SFD_DATA_RANGE_CHECK(*c4_l_S, 8U);
  _SFD_DATA_RANGE_CHECK(*c4_dist1, 9U);
  _SFD_DATA_RANGE_CHECK(*c4_deltaPsi, 10U);
  _SFD_DATA_RANGE_CHECK(*c4_deltadPsi, 11U);
  _SFD_DATA_RANGE_CHECK(*c4_rho, 12U);
  _SFD_DATA_RANGE_CHECK(*c4_rho1, 13U);
  chartInstance->c4_sfEvent = CALL_EVENT;
  c4_chartstep_c4_laneKeepingArcSplinesFF2013a(chartInstance);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_laneKeepingArcSplinesFF2013aMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c4_chartstep_c4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T c4_hoistedGlobal;
  real_T c4_b_hoistedGlobal;
  real_T c4_c_hoistedGlobal;
  real_T c4_d_hoistedGlobal;
  real_T c4_e_hoistedGlobal;
  real_T c4_f_hoistedGlobal;
  int32_T c4_i2;
  real_T c4_CircleData[312];
  int32_T c4_i3;
  real_T c4_LineData[65];
  real_T c4_X1;
  real_T c4_Y1;
  real_T c4_Psi;
  real_T c4_dPsi;
  real_T c4_vel;
  real_T c4_l_S;
  uint32_T c4_debug_family_var_map[42];
  real_T c4_PX;
  real_T c4_PY;
  real_T c4_CXvec[52];
  real_T c4_CYvec[52];
  real_T c4_Rvec[52];
  real_T c4_thetaSvec[52];
  real_T c4_thetaRvec[52];
  real_T c4_j;
  real_T c4_theta;
  real_T c4_thetaRnew;
  real_T c4_thetaSnew;
  real_T c4_distVec[2];
  real_T c4_n[2];
  real_T c4_intVec[2];
  real_T c4_distNew;
  real_T c4_Svec[26];
  real_T c4_Evec[26];
  real_T c4_v[2];
  real_T c4_dir[2];
  real_T c4_f;
  real_T c4_theta1;
  real_T c4_distVec1[2];
  real_T c4_n1[2];
  real_T c4_intVec1[2];
  real_T c4_distNew1;
  real_T c4_dir1[2];
  real_T c4_nargin = 8.0;
  real_T c4_nargout = 6.0;
  real_T c4_dist;
  real_T c4_dist1;
  real_T c4_deltaPsi;
  real_T c4_deltadPsi;
  real_T c4_rho;
  real_T c4_rho1;
  real_T c4_x;
  real_T c4_b_x;
  real_T c4_a;
  real_T c4_b;
  real_T c4_y;
  real_T c4_c_x;
  real_T c4_d_x;
  real_T c4_b_a;
  real_T c4_b_b;
  real_T c4_b_y;
  int32_T c4_i4;
  int32_T c4_i5;
  int32_T c4_i6;
  int32_T c4_i7;
  int32_T c4_i8;
  int32_T c4_i9;
  int32_T c4_i10;
  int32_T c4_i11;
  int32_T c4_i12;
  int32_T c4_i13;
  int32_T c4_b_j;
  real_T c4_c_a;
  real_T c4_c_b;
  real_T c4_c_y;
  real_T c4_d0;
  real_T c4_d_a;
  real_T c4_d_b;
  real_T c4_d_y;
  int32_T c4_i14;
  real_T c4_e_a[2];
  int32_T c4_i15;
  real_T c4_A[2];
  real_T c4_e_y;
  int32_T c4_k;
  int32_T c4_b_k;
  int32_T c4_i16;
  real_T c4_B;
  real_T c4_f_y;
  real_T c4_g_y;
  int32_T c4_i17;
  real_T c4_e_b;
  int32_T c4_i18;
  real_T c4_b_B;
  real_T c4_h_y;
  real_T c4_i_y;
  int32_T c4_i19;
  real_T c4_f_a;
  int32_T c4_i20;
  int32_T c4_i21;
  real_T c4_b_CXvec[2];
  int32_T c4_i22;
  real_T c4_b_PX[2];
  int32_T c4_i23;
  int32_T c4_i24;
  int32_T c4_c_k;
  int32_T c4_d_k;
  real_T c4_c_B;
  real_T c4_j_y;
  real_T c4_k_y;
  real_T c4_d_B;
  real_T c4_l_y;
  real_T c4_m_y;
  real_T c4_n_y;
  real_T c4_g_a;
  real_T c4_f_b;
  real_T c4_o_y;
  int32_T c4_i25;
  int32_T c4_i26;
  int32_T c4_i27;
  int32_T c4_i28;
  int32_T c4_i29;
  int32_T c4_i30;
  int32_T c4_i31;
  int32_T c4_i32;
  int32_T c4_c_j;
  int32_T c4_d_j;
  int32_T c4_e_j;
  int32_T c4_i33;
  int32_T c4_i34;
  real_T c4_b_v[2];
  real_T c4_e_B;
  real_T c4_p_y;
  real_T c4_q_y;
  int32_T c4_i35;
  int32_T c4_i36;
  int32_T c4_i37;
  real_T c4_r_y;
  int32_T c4_e_k;
  int32_T c4_f_k;
  real_T c4_b_A;
  int32_T c4_i38;
  real_T c4_c_v[2];
  real_T c4_f_B;
  real_T c4_e_x;
  real_T c4_s_y;
  real_T c4_f_x;
  real_T c4_t_y;
  int32_T c4_i39;
  int32_T c4_i40;
  int32_T c4_g_k;
  int32_T c4_h_k;
  int32_T c4_f_j;
  real_T c4_h_a;
  real_T c4_g_b;
  real_T c4_u_y;
  real_T c4_d1;
  real_T c4_i_a;
  real_T c4_h_b;
  real_T c4_v_y;
  int32_T c4_i41;
  int32_T c4_i42;
  real_T c4_w_y;
  int32_T c4_i_k;
  int32_T c4_j_k;
  int32_T c4_i43;
  real_T c4_g_B;
  real_T c4_x_y;
  real_T c4_y_y;
  int32_T c4_i44;
  real_T c4_i_b;
  int32_T c4_i45;
  real_T c4_h_B;
  real_T c4_ab_y;
  real_T c4_bb_y;
  int32_T c4_i46;
  real_T c4_j_a;
  int32_T c4_i47;
  int32_T c4_i48;
  real_T c4_c_CXvec[2];
  int32_T c4_i49;
  real_T c4_b_X1[2];
  int32_T c4_i50;
  int32_T c4_i51;
  int32_T c4_k_k;
  int32_T c4_l_k;
  real_T c4_i_B;
  real_T c4_cb_y;
  real_T c4_db_y;
  int32_T c4_g_j;
  int32_T c4_h_j;
  int32_T c4_i_j;
  int32_T c4_i52;
  int32_T c4_i53;
  real_T c4_d_v[2];
  real_T c4_j_B;
  real_T c4_eb_y;
  real_T c4_fb_y;
  int32_T c4_i54;
  int32_T c4_i55;
  int32_T c4_i56;
  real_T c4_gb_y;
  int32_T c4_m_k;
  int32_T c4_n_k;
  real_T c4_c_A;
  int32_T c4_i57;
  real_T c4_e_v[2];
  real_T c4_k_B;
  real_T c4_g_x;
  real_T c4_hb_y;
  real_T c4_h_x;
  real_T c4_ib_y;
  int32_T c4_i58;
  int32_T c4_i59;
  int32_T c4_o_k;
  int32_T c4_p_k;
  real_T *c4_c_X1;
  real_T *c4_b_Y1;
  real_T *c4_b_Psi;
  real_T *c4_b_dPsi;
  real_T *c4_b_vel;
  real_T *c4_b_l_S;
  real_T *c4_b_dist;
  real_T *c4_b_dist1;
  real_T *c4_b_deltaPsi;
  real_T *c4_b_deltadPsi;
  real_T *c4_b_rho;
  real_T *c4_b_rho1;
  real_T (*c4_b_LineData)[65];
  real_T (*c4_b_CircleData)[312];
  boolean_T guard1 = FALSE;
  boolean_T guard2 = FALSE;
  boolean_T guard3 = FALSE;
  boolean_T guard4 = FALSE;
  boolean_T guard5 = FALSE;
  boolean_T guard6 = FALSE;
  boolean_T guard7 = FALSE;
  boolean_T guard8 = FALSE;
  boolean_T guard9 = FALSE;
  boolean_T guard10 = FALSE;
  boolean_T guard11 = FALSE;
  boolean_T guard12 = FALSE;
  boolean_T guard13 = FALSE;
  boolean_T guard14 = FALSE;
  boolean_T guard15 = FALSE;
  boolean_T guard16 = FALSE;
  c4_b_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
  c4_b_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
  c4_b_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
  c4_b_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c4_b_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c4_b_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c4_b_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c4_b_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c4_b_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c4_b_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c4_c_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c4_b_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
  c4_b_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c4_b_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 3U, chartInstance->c4_sfEvent);
  c4_hoistedGlobal = *c4_c_X1;
  c4_b_hoistedGlobal = *c4_b_Y1;
  c4_c_hoistedGlobal = *c4_b_Psi;
  c4_d_hoistedGlobal = *c4_b_dPsi;
  c4_e_hoistedGlobal = *c4_b_vel;
  c4_f_hoistedGlobal = *c4_b_l_S;
  for (c4_i2 = 0; c4_i2 < 312; c4_i2++) {
    c4_CircleData[c4_i2] = (*c4_b_CircleData)[c4_i2];
  }

  for (c4_i3 = 0; c4_i3 < 65; c4_i3++) {
    c4_LineData[c4_i3] = (*c4_b_LineData)[c4_i3];
  }

  c4_X1 = c4_hoistedGlobal;
  c4_Y1 = c4_b_hoistedGlobal;
  c4_Psi = c4_c_hoistedGlobal;
  c4_dPsi = c4_d_hoistedGlobal;
  c4_vel = c4_e_hoistedGlobal;
  c4_l_S = c4_f_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 42U, 42U, c4_debug_family_names,
    c4_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_PX, 0U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_PY, 1U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_CXvec, 2U, c4_f_sf_marshallOut,
    c4_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_CYvec, 3U, c4_f_sf_marshallOut,
    c4_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_Rvec, 4U, c4_f_sf_marshallOut,
    c4_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_thetaSvec, 5U, c4_f_sf_marshallOut,
    c4_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_thetaRvec, 6U, c4_f_sf_marshallOut,
    c4_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_j, 7U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_theta, 8U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_thetaRnew, 9U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_thetaSnew, 10U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_distVec, 11U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_n, 12U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_intVec, 13U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_distNew, 14U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_Svec, 15U, c4_e_sf_marshallOut,
    c4_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_Evec, 16U, c4_e_sf_marshallOut,
    c4_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_v, 17U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_dir, 18U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_f, 19U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_theta1, 20U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_distVec1, 21U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_n1, 22U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_intVec1, 23U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_distNew1, 24U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c4_dir1, 25U, c4_d_sf_marshallOut,
    c4_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_nargin, 26U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_nargout, 27U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(c4_CircleData, 28U, c4_c_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c4_LineData, 29U, c4_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_X1, 30U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_Y1, 31U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_Psi, 32U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_dPsi, 33U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_vel, 34U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c4_l_S, 35U, c4_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_dist, 36U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_dist1, 37U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_deltaPsi, 38U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_deltadPsi, 39U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_rho, 40U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c4_rho1, 41U, c4_sf_marshallOut,
    c4_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 3);
  c4_x = c4_Psi;
  c4_b_x = c4_x;
  c4_b_x = muDoubleScalarCos(c4_b_x);
  c4_a = c4_l_S;
  c4_b = c4_b_x;
  c4_y = c4_a * c4_b;
  c4_PX = c4_X1 + c4_y;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 4);
  c4_c_x = c4_Psi;
  c4_d_x = c4_c_x;
  c4_d_x = muDoubleScalarSin(c4_d_x);
  c4_b_a = c4_l_S;
  c4_b_b = c4_d_x;
  c4_b_y = c4_b_a * c4_b_b;
  c4_PY = c4_Y1 + c4_b_y;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 5);
  c4_dist = 1000.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 6);
  c4_dist1 = 1000.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 7);
  c4_deltaPsi = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 8);
  c4_deltadPsi = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 9);
  c4_i4 = 0;
  for (c4_i5 = 0; c4_i5 < 52; c4_i5++) {
    c4_CXvec[c4_i5] = c4_CircleData[c4_i4];
    c4_i4 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 10);
  c4_i6 = 0;
  for (c4_i7 = 0; c4_i7 < 52; c4_i7++) {
    c4_CYvec[c4_i7] = c4_CircleData[c4_i6 + 1];
    c4_i6 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 11);
  c4_i8 = 0;
  for (c4_i9 = 0; c4_i9 < 52; c4_i9++) {
    c4_Rvec[c4_i9] = c4_CircleData[c4_i8 + 2];
    c4_i8 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 12);
  c4_i10 = 0;
  for (c4_i11 = 0; c4_i11 < 52; c4_i11++) {
    c4_thetaSvec[c4_i11] = c4_CircleData[c4_i10 + 3];
    c4_i10 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 13);
  c4_i12 = 0;
  for (c4_i13 = 0; c4_i13 < 52; c4_i13++) {
    c4_thetaRvec[c4_i13] = c4_CircleData[c4_i12 + 4];
    c4_i12 += 6;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 14);
  c4_rho = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 15);
  c4_rho1 = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 17);
  c4_j = 1.0;
  c4_b_j = 0;
  while (c4_b_j < 52) {
    c4_j = 1.0 + (real_T)c4_b_j;
    CV_EML_FOR(0, 1, 0, 1);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 20);
    c4_c_a = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
      (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_b_sign(chartInstance, &c4_c_a);
    c4_c_b = c4_PX - c4_CXvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "CXvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_c_y = c4_c_a * c4_c_b;
    c4_d0 = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
      (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_b_sign(chartInstance, &c4_d0);
    c4_d_a = -c4_d0;
    c4_d_b = c4_PY - c4_CYvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "CYvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_d_y = c4_d_a * c4_d_b;
    c4_theta = c4_mod(chartInstance, c4_atan2(chartInstance, c4_c_y, c4_d_y),
                      6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 21);
    c4_thetaRnew = c4_mod(chartInstance, c4_thetaRvec[(int32_T)(real_T)
                          _SFD_EML_ARRAY_BOUNDS_CHECK("thetaRvec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1], 6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 22);
    c4_thetaSnew = c4_mod(chartInstance, c4_thetaSvec[(int32_T)(real_T)
                          _SFD_EML_ARRAY_BOUNDS_CHECK("thetaSvec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1], 6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 24);
    guard10 = FALSE;
    guard11 = FALSE;
    guard12 = FALSE;
    guard13 = FALSE;
    guard14 = FALSE;
    guard15 = FALSE;
    guard16 = FALSE;
    if (CV_EML_IF(0, 1, 0, c4_thetaSvec[(int32_T)(real_T)
                  _SFD_EML_ARRAY_BOUNDS_CHECK("thetaSvec", (int32_T)
          _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1] < c4_thetaRvec
                  [(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("thetaRvec",
          (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1])) {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 25);
      if (CV_EML_IF(0, 1, 1, c4_thetaSnew < c4_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 26);
        if (CV_EML_COND(0, 1, 0, c4_theta < c4_thetaSnew)) {
          guard12 = TRUE;
        } else if (CV_EML_COND(0, 1, 1, c4_theta >= c4_thetaRnew)) {
          guard12 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 0, FALSE);
          CV_EML_IF(0, 1, 2, FALSE);
          guard14 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 30);
        if (CV_EML_COND(0, 1, 2, c4_theta < c4_thetaSnew)) {
          if (CV_EML_COND(0, 1, 3, c4_theta > c4_thetaRnew)) {
            CV_EML_MCDC(0, 1, 1, TRUE);
            CV_EML_IF(0, 1, 3, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 31);
          } else {
            guard16 = TRUE;
          }
        } else {
          guard16 = TRUE;
        }
      }
    } else {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 35);
      if (CV_EML_IF(0, 1, 4, c4_thetaSnew > c4_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 36);
        if (CV_EML_COND(0, 1, 4, c4_theta > c4_thetaSnew)) {
          guard11 = TRUE;
        } else if (CV_EML_COND(0, 1, 5, c4_theta <= c4_thetaRnew)) {
          guard11 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 2, FALSE);
          CV_EML_IF(0, 1, 5, FALSE);
          guard13 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 40);
        if (CV_EML_COND(0, 1, 6, c4_theta > c4_thetaSnew)) {
          if (CV_EML_COND(0, 1, 7, c4_theta < c4_thetaRnew)) {
            CV_EML_MCDC(0, 1, 3, TRUE);
            CV_EML_IF(0, 1, 6, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 41);
          } else {
            guard15 = TRUE;
          }
        } else {
          guard15 = TRUE;
        }
      }
    }

    if (guard16 == TRUE) {
      CV_EML_MCDC(0, 1, 1, FALSE);
      CV_EML_IF(0, 1, 3, FALSE);
      guard14 = TRUE;
    }

    if (guard15 == TRUE) {
      CV_EML_MCDC(0, 1, 3, FALSE);
      CV_EML_IF(0, 1, 6, FALSE);
      guard13 = TRUE;
    }

    if (guard14 == TRUE) {
      guard10 = TRUE;
    }

    if (guard13 == TRUE) {
      guard10 = TRUE;
    }

    if (guard12 == TRUE) {
      CV_EML_MCDC(0, 1, 0, TRUE);
      CV_EML_IF(0, 1, 2, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 27);
    }

    if (guard11 == TRUE) {
      CV_EML_MCDC(0, 1, 2, TRUE);
      CV_EML_IF(0, 1, 5, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 37);
    }

    if (guard10 == TRUE) {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 46);
      c4_distVec[0] = c4_PX - c4_CXvec[(int32_T)(real_T)
        _SFD_EML_ARRAY_BOUNDS_CHECK("CXvec", (int32_T)_SFD_INTEGER_CHECK("j",
        c4_j), 1, 52, 1, 0) - 1];
      c4_distVec[1] = c4_PY - c4_CYvec[(int32_T)(real_T)
        _SFD_EML_ARRAY_BOUNDS_CHECK("CYvec", (int32_T)_SFD_INTEGER_CHECK("j",
        c4_j), 1, 52, 1, 0) - 1];
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 47);
      for (c4_i14 = 0; c4_i14 < 2; c4_i14++) {
        c4_e_a[c4_i14] = c4_distVec[c4_i14];
      }

      for (c4_i15 = 0; c4_i15 < 2; c4_i15++) {
        c4_A[c4_i15] = c4_distVec[c4_i15];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_e_y = 0.0;
      for (c4_k = 1; c4_k < 3; c4_k++) {
        c4_b_k = c4_k;
        c4_e_y += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_b_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_b_k), 1, 2, 1, 0) - 1];
      }

      for (c4_i16 = 0; c4_i16 < 2; c4_i16++) {
        c4_A[c4_i16] = c4_distVec[c4_i16];
      }

      c4_B = c4_e_y;
      c4_b_sqrt(chartInstance, &c4_B);
      c4_f_y = c4_B;
      c4_g_y = c4_f_y;
      for (c4_i17 = 0; c4_i17 < 2; c4_i17++) {
        c4_A[c4_i17] /= c4_g_y;
      }

      c4_e_b = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
        (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i18 = 0; c4_i18 < 2; c4_i18++) {
        c4_A[c4_i18] *= c4_e_b;
      }

      c4_b_B = c4_abs(chartInstance, c4_Rvec[(int32_T)(real_T)
                      _SFD_EML_ARRAY_BOUNDS_CHECK("Rvec", (int32_T)
        _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1]);
      c4_h_y = c4_b_B;
      c4_i_y = c4_h_y;
      for (c4_i19 = 0; c4_i19 < 2; c4_i19++) {
        c4_n[c4_i19] = c4_A[c4_i19] / c4_i_y;
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 48);
      c4_f_a = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
        (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i20 = 0; c4_i20 < 2; c4_i20++) {
        c4_A[c4_i20] = c4_n[c4_i20];
      }

      for (c4_i21 = 0; c4_i21 < 2; c4_i21++) {
        c4_A[c4_i21] *= c4_f_a;
      }

      c4_b_CXvec[0] = c4_CXvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
        "CXvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      c4_b_CXvec[1] = c4_CYvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
        "CYvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i22 = 0; c4_i22 < 2; c4_i22++) {
        c4_intVec[c4_i22] = c4_b_CXvec[c4_i22] + c4_A[c4_i22];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 49);
      c4_b_PX[0] = c4_PX;
      c4_b_PX[1] = c4_PY;
      for (c4_i23 = 0; c4_i23 < 2; c4_i23++) {
        c4_e_a[c4_i23] = -(c4_b_PX[c4_i23] - c4_intVec[c4_i23]);
      }

      for (c4_i24 = 0; c4_i24 < 2; c4_i24++) {
        c4_A[c4_i24] = c4_n[c4_i24];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_distNew = 0.0;
      for (c4_c_k = 1; c4_c_k < 3; c4_c_k++) {
        c4_d_k = c4_c_k;
        c4_distNew += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_d_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_d_k), 1, 2, 1, 0) - 1];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 50);
      if (CV_EML_IF(0, 1, 7, c4_abs(chartInstance, c4_distNew) < c4_abs
                    (chartInstance, c4_dist))) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 51);
        c4_c_B = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
          (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
        c4_j_y = c4_c_B;
        c4_k_y = c4_j_y;
        c4_rho = 1.0 / c4_k_y;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 52);
        c4_dist = c4_distNew;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 53);
        c4_deltaPsi = c4_theta - c4_Psi;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 54);
        c4_d_B = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
          (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
        c4_l_y = c4_d_B;
        c4_m_y = c4_l_y;
        c4_n_y = 1.0 / c4_m_y;
        c4_g_a = c4_n_y;
        c4_f_b = c4_vel;
        c4_o_y = c4_g_a * c4_f_b;
        c4_deltadPsi = c4_o_y - c4_dPsi;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 55);
        if (CV_EML_IF(0, 1, 8, c4_deltaPsi > 3.1415926535897931)) {
          _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 56);
          c4_deltaPsi -= 6.2831853071795862;
        } else {
          _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 57);
          if (CV_EML_IF(0, 1, 9, c4_deltaPsi < -3.1415926535897931)) {
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 58);
            c4_deltaPsi += 6.2831853071795862;
          }
        }
      }
    }

    c4_b_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 0, 0);
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 65);
  c4_i25 = 0;
  c4_i26 = 0;
  for (c4_i27 = 0; c4_i27 < 13; c4_i27++) {
    for (c4_i28 = 0; c4_i28 < 2; c4_i28++) {
      c4_Svec[c4_i28 + c4_i25] = c4_LineData[c4_i28 + c4_i26];
    }

    c4_i25 += 2;
    c4_i26 += 5;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 66);
  c4_i29 = 0;
  c4_i30 = 0;
  for (c4_i31 = 0; c4_i31 < 13; c4_i31++) {
    for (c4_i32 = 0; c4_i32 < 2; c4_i32++) {
      c4_Evec[c4_i32 + c4_i29] = c4_LineData[(c4_i32 + c4_i30) + 2];
    }

    c4_i29 += 2;
    c4_i30 += 5;
  }

  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 67);
  c4_j = 1.0;
  c4_c_j = 0;
  while (c4_c_j < 13) {
    c4_j = 1.0 + (real_T)c4_c_j;
    CV_EML_FOR(0, 1, 1, 1);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 68);
    c4_d_j = (int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Evec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1;
    c4_e_j = (int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Svec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1;
    for (c4_i33 = 0; c4_i33 < 2; c4_i33++) {
      c4_v[c4_i33] = c4_Evec[c4_i33 + (c4_d_j << 1)] - c4_Svec[c4_i33 + (c4_e_j <<
        1)];
    }

    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 69);
    c4_A[0] = -c4_v[1];
    c4_A[1] = c4_v[0];
    for (c4_i34 = 0; c4_i34 < 2; c4_i34++) {
      c4_b_v[c4_i34] = c4_v[c4_i34];
    }

    c4_e_B = c4_norm(chartInstance, c4_b_v);
    c4_p_y = c4_e_B;
    c4_q_y = c4_p_y;
    for (c4_i35 = 0; c4_i35 < 2; c4_i35++) {
      c4_n[c4_i35] = c4_A[c4_i35] / c4_q_y;
    }

    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 70);
    c4_dir[0] = c4_PX - c4_Svec[((int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "Svec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1) << 1];
    c4_dir[1] = c4_PY - c4_Svec[1 + (((int32_T)(real_T)
      _SFD_EML_ARRAY_BOUNDS_CHECK("Svec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j),
      1, 13, 2, 0) - 1) << 1)];
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 71);
    for (c4_i36 = 0; c4_i36 < 2; c4_i36++) {
      c4_e_a[c4_i36] = c4_v[c4_i36];
    }

    for (c4_i37 = 0; c4_i37 < 2; c4_i37++) {
      c4_A[c4_i37] = c4_dir[c4_i37];
    }

    c4_b_eml_scalar_eg(chartInstance);
    c4_b_eml_scalar_eg(chartInstance);
    c4_r_y = 0.0;
    for (c4_e_k = 1; c4_e_k < 3; c4_e_k++) {
      c4_f_k = c4_e_k;
      c4_r_y += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
        _SFD_INTEGER_CHECK("", (real_T)c4_f_k), 1, 2, 1, 0) - 1] *
        c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
        (real_T)c4_f_k), 1, 2, 1, 0) - 1];
    }

    c4_b_A = c4_r_y;
    for (c4_i38 = 0; c4_i38 < 2; c4_i38++) {
      c4_c_v[c4_i38] = c4_v[c4_i38];
    }

    c4_f_B = c4_mpower(chartInstance, c4_norm(chartInstance, c4_c_v));
    c4_e_x = c4_b_A;
    c4_s_y = c4_f_B;
    c4_f_x = c4_e_x;
    c4_t_y = c4_s_y;
    c4_f = c4_f_x / c4_t_y;
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 72);
    guard9 = FALSE;
    if (CV_EML_COND(0, 1, 8, c4_f < 0.0)) {
      guard9 = TRUE;
    } else if (CV_EML_COND(0, 1, 9, c4_f > 1.0)) {
      guard9 = TRUE;
    } else {
      CV_EML_MCDC(0, 1, 4, FALSE);
      CV_EML_IF(0, 1, 10, FALSE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 75);
      for (c4_i39 = 0; c4_i39 < 2; c4_i39++) {
        c4_e_a[c4_i39] = c4_dir[c4_i39];
      }

      for (c4_i40 = 0; c4_i40 < 2; c4_i40++) {
        c4_A[c4_i40] = c4_n[c4_i40];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_distNew = 0.0;
      for (c4_g_k = 1; c4_g_k < 3; c4_g_k++) {
        c4_h_k = c4_g_k;
        c4_distNew += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_h_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_h_k), 1, 2, 1, 0) - 1];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 76);
      if (CV_EML_IF(0, 1, 11, c4_abs(chartInstance, c4_distNew) < c4_abs
                    (chartInstance, c4_dist))) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 77);
        c4_rho = 0.0;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 78);
        c4_dist = c4_distNew;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 80);
        c4_deltaPsi = c4_atan2(chartInstance, c4_v[1], c4_v[0]) - c4_Psi;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 81);
        c4_deltadPsi = -c4_dPsi;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 82);
        if (CV_EML_IF(0, 1, 12, c4_deltaPsi > 3.1415926535897931)) {
          _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 83);
          c4_deltaPsi -= 6.2831853071795862;
        } else {
          _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 84);
          if (CV_EML_IF(0, 1, 13, c4_deltaPsi < -3.1415926535897931)) {
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 85);
            c4_deltaPsi += 6.2831853071795862;
          }
        }
      }
    }

    if (guard9 == TRUE) {
      CV_EML_MCDC(0, 1, 4, TRUE);
      CV_EML_IF(0, 1, 10, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 73);
    }

    c4_c_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 1, 0);
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 91);
  c4_j = 1.0;
  c4_f_j = 0;
  while (c4_f_j < 52) {
    c4_j = 1.0 + (real_T)c4_f_j;
    CV_EML_FOR(0, 1, 2, 1);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 94);
    c4_h_a = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
      (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_b_sign(chartInstance, &c4_h_a);
    c4_g_b = c4_X1 - c4_CXvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "CXvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_u_y = c4_h_a * c4_g_b;
    c4_d1 = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
      (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_b_sign(chartInstance, &c4_d1);
    c4_i_a = -c4_d1;
    c4_h_b = c4_Y1 - c4_CYvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "CYvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
    c4_v_y = c4_i_a * c4_h_b;
    c4_theta1 = c4_mod(chartInstance, c4_atan2(chartInstance, c4_u_y, c4_v_y),
                       6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 95);
    c4_thetaRnew = c4_mod(chartInstance, c4_thetaRvec[(int32_T)(real_T)
                          _SFD_EML_ARRAY_BOUNDS_CHECK("thetaRvec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1], 6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 96);
    c4_thetaSnew = c4_mod(chartInstance, c4_thetaSvec[(int32_T)(real_T)
                          _SFD_EML_ARRAY_BOUNDS_CHECK("thetaSvec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1], 6.2831853071795862);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 98);
    guard2 = FALSE;
    guard3 = FALSE;
    guard4 = FALSE;
    guard5 = FALSE;
    guard6 = FALSE;
    guard7 = FALSE;
    guard8 = FALSE;
    if (CV_EML_IF(0, 1, 14, c4_thetaSvec[(int32_T)(real_T)
                  _SFD_EML_ARRAY_BOUNDS_CHECK("thetaSvec", (int32_T)
          _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1] < c4_thetaRvec
                  [(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("thetaRvec",
          (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1])) {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 99);
      if (CV_EML_IF(0, 1, 15, c4_thetaSnew < c4_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 100);
        if (CV_EML_COND(0, 1, 10, c4_theta1 < c4_thetaSnew)) {
          guard4 = TRUE;
        } else if (CV_EML_COND(0, 1, 11, c4_theta1 >= c4_thetaRnew)) {
          guard4 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 5, FALSE);
          CV_EML_IF(0, 1, 16, FALSE);
          guard6 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 104);
        if (CV_EML_COND(0, 1, 12, c4_theta1 < c4_thetaSnew)) {
          if (CV_EML_COND(0, 1, 13, c4_theta1 > c4_thetaRnew)) {
            CV_EML_MCDC(0, 1, 6, TRUE);
            CV_EML_IF(0, 1, 17, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 105);
          } else {
            guard8 = TRUE;
          }
        } else {
          guard8 = TRUE;
        }
      }
    } else {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 109);
      if (CV_EML_IF(0, 1, 18, c4_thetaSnew > c4_thetaRnew)) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 110);
        if (CV_EML_COND(0, 1, 14, c4_theta1 > c4_thetaSnew)) {
          guard3 = TRUE;
        } else if (CV_EML_COND(0, 1, 15, c4_theta1 <= c4_thetaRnew)) {
          guard3 = TRUE;
        } else {
          CV_EML_MCDC(0, 1, 7, FALSE);
          CV_EML_IF(0, 1, 19, FALSE);
          guard5 = TRUE;
        }
      } else {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 114);
        if (CV_EML_COND(0, 1, 16, c4_theta1 > c4_thetaSnew)) {
          if (CV_EML_COND(0, 1, 17, c4_theta1 < c4_thetaRnew)) {
            CV_EML_MCDC(0, 1, 8, TRUE);
            CV_EML_IF(0, 1, 20, TRUE);
            _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 115);
          } else {
            guard7 = TRUE;
          }
        } else {
          guard7 = TRUE;
        }
      }
    }

    if (guard8 == TRUE) {
      CV_EML_MCDC(0, 1, 6, FALSE);
      CV_EML_IF(0, 1, 17, FALSE);
      guard6 = TRUE;
    }

    if (guard7 == TRUE) {
      CV_EML_MCDC(0, 1, 8, FALSE);
      CV_EML_IF(0, 1, 20, FALSE);
      guard5 = TRUE;
    }

    if (guard6 == TRUE) {
      guard2 = TRUE;
    }

    if (guard5 == TRUE) {
      guard2 = TRUE;
    }

    if (guard4 == TRUE) {
      CV_EML_MCDC(0, 1, 5, TRUE);
      CV_EML_IF(0, 1, 16, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 101);
    }

    if (guard3 == TRUE) {
      CV_EML_MCDC(0, 1, 7, TRUE);
      CV_EML_IF(0, 1, 19, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 111);
    }

    if (guard2 == TRUE) {
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 120);
      c4_distVec1[0] = c4_X1 - c4_CXvec[(int32_T)(real_T)
        _SFD_EML_ARRAY_BOUNDS_CHECK("CXvec", (int32_T)_SFD_INTEGER_CHECK("j",
        c4_j), 1, 52, 1, 0) - 1];
      c4_distVec1[1] = c4_Y1 - c4_CYvec[(int32_T)(real_T)
        _SFD_EML_ARRAY_BOUNDS_CHECK("CYvec", (int32_T)_SFD_INTEGER_CHECK("j",
        c4_j), 1, 52, 1, 0) - 1];
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 121);
      for (c4_i41 = 0; c4_i41 < 2; c4_i41++) {
        c4_e_a[c4_i41] = c4_distVec1[c4_i41];
      }

      for (c4_i42 = 0; c4_i42 < 2; c4_i42++) {
        c4_A[c4_i42] = c4_distVec1[c4_i42];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_w_y = 0.0;
      for (c4_i_k = 1; c4_i_k < 3; c4_i_k++) {
        c4_j_k = c4_i_k;
        c4_w_y += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_j_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_j_k), 1, 2, 1, 0) - 1];
      }

      for (c4_i43 = 0; c4_i43 < 2; c4_i43++) {
        c4_A[c4_i43] = c4_distVec1[c4_i43];
      }

      c4_g_B = c4_w_y;
      c4_b_sqrt(chartInstance, &c4_g_B);
      c4_x_y = c4_g_B;
      c4_y_y = c4_x_y;
      for (c4_i44 = 0; c4_i44 < 2; c4_i44++) {
        c4_A[c4_i44] /= c4_y_y;
      }

      c4_i_b = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
        (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i45 = 0; c4_i45 < 2; c4_i45++) {
        c4_A[c4_i45] *= c4_i_b;
      }

      c4_h_B = c4_abs(chartInstance, c4_Rvec[(int32_T)(real_T)
                      _SFD_EML_ARRAY_BOUNDS_CHECK("Rvec", (int32_T)
        _SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1]);
      c4_ab_y = c4_h_B;
      c4_bb_y = c4_ab_y;
      for (c4_i46 = 0; c4_i46 < 2; c4_i46++) {
        c4_n1[c4_i46] = c4_A[c4_i46] / c4_bb_y;
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 122);
      c4_j_a = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
        (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i47 = 0; c4_i47 < 2; c4_i47++) {
        c4_A[c4_i47] = c4_n1[c4_i47];
      }

      for (c4_i48 = 0; c4_i48 < 2; c4_i48++) {
        c4_A[c4_i48] *= c4_j_a;
      }

      c4_c_CXvec[0] = c4_CXvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
        "CXvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      c4_c_CXvec[1] = c4_CYvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
        "CYvec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
      for (c4_i49 = 0; c4_i49 < 2; c4_i49++) {
        c4_intVec1[c4_i49] = c4_c_CXvec[c4_i49] + c4_A[c4_i49];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 123);
      c4_b_X1[0] = c4_X1;
      c4_b_X1[1] = c4_Y1;
      for (c4_i50 = 0; c4_i50 < 2; c4_i50++) {
        c4_e_a[c4_i50] = -(c4_b_X1[c4_i50] - c4_intVec1[c4_i50]);
      }

      for (c4_i51 = 0; c4_i51 < 2; c4_i51++) {
        c4_A[c4_i51] = c4_n1[c4_i51];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_distNew1 = 0.0;
      for (c4_k_k = 1; c4_k_k < 3; c4_k_k++) {
        c4_l_k = c4_k_k;
        c4_distNew1 += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_l_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_l_k), 1, 2, 1, 0) - 1];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 124);
      if (CV_EML_IF(0, 1, 21, c4_abs(chartInstance, c4_distNew1) < c4_abs
                    (chartInstance, c4_dist1))) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 125);
        c4_i_B = c4_Rvec[(int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Rvec",
          (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 52, 1, 0) - 1];
        c4_cb_y = c4_i_B;
        c4_db_y = c4_cb_y;
        c4_rho1 = 1.0 / c4_db_y;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 126);
        c4_dist1 = c4_distNew1;
      }
    }

    c4_f_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 2, 0);
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 139U);
  c4_j = 1.0;
  c4_g_j = 0;
  while (c4_g_j < 13) {
    c4_j = 1.0 + (real_T)c4_g_j;
    CV_EML_FOR(0, 1, 3, 1);
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 140U);
    c4_h_j = (int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Evec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1;
    c4_i_j = (int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK("Svec", (int32_T)
      _SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1;
    for (c4_i52 = 0; c4_i52 < 2; c4_i52++) {
      c4_v[c4_i52] = c4_Evec[c4_i52 + (c4_h_j << 1)] - c4_Svec[c4_i52 + (c4_i_j <<
        1)];
    }

    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 141U);
    c4_A[0] = -c4_v[1];
    c4_A[1] = c4_v[0];
    for (c4_i53 = 0; c4_i53 < 2; c4_i53++) {
      c4_d_v[c4_i53] = c4_v[c4_i53];
    }

    c4_j_B = c4_norm(chartInstance, c4_d_v);
    c4_eb_y = c4_j_B;
    c4_fb_y = c4_eb_y;
    for (c4_i54 = 0; c4_i54 < 2; c4_i54++) {
      c4_n[c4_i54] = c4_A[c4_i54] / c4_fb_y;
    }

    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 142U);
    c4_dir1[0] = c4_X1 - c4_Svec[((int32_T)(real_T)_SFD_EML_ARRAY_BOUNDS_CHECK(
      "Svec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j), 1, 13, 2, 0) - 1) << 1];
    c4_dir1[1] = c4_Y1 - c4_Svec[1 + (((int32_T)(real_T)
      _SFD_EML_ARRAY_BOUNDS_CHECK("Svec", (int32_T)_SFD_INTEGER_CHECK("j", c4_j),
      1, 13, 2, 0) - 1) << 1)];
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 143U);
    for (c4_i55 = 0; c4_i55 < 2; c4_i55++) {
      c4_e_a[c4_i55] = c4_v[c4_i55];
    }

    for (c4_i56 = 0; c4_i56 < 2; c4_i56++) {
      c4_A[c4_i56] = c4_dir1[c4_i56];
    }

    c4_b_eml_scalar_eg(chartInstance);
    c4_b_eml_scalar_eg(chartInstance);
    c4_gb_y = 0.0;
    for (c4_m_k = 1; c4_m_k < 3; c4_m_k++) {
      c4_n_k = c4_m_k;
      c4_gb_y += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
        _SFD_INTEGER_CHECK("", (real_T)c4_n_k), 1, 2, 1, 0) - 1] *
        c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
        (real_T)c4_n_k), 1, 2, 1, 0) - 1];
    }

    c4_c_A = c4_gb_y;
    for (c4_i57 = 0; c4_i57 < 2; c4_i57++) {
      c4_e_v[c4_i57] = c4_v[c4_i57];
    }

    c4_k_B = c4_mpower(chartInstance, c4_norm(chartInstance, c4_e_v));
    c4_g_x = c4_c_A;
    c4_hb_y = c4_k_B;
    c4_h_x = c4_g_x;
    c4_ib_y = c4_hb_y;
    c4_f = c4_h_x / c4_ib_y;
    _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 144U);
    guard1 = FALSE;
    if (CV_EML_COND(0, 1, 18, c4_f < 0.0)) {
      guard1 = TRUE;
    } else if (CV_EML_COND(0, 1, 19, c4_f > 1.0)) {
      guard1 = TRUE;
    } else {
      CV_EML_MCDC(0, 1, 9, FALSE);
      CV_EML_IF(0, 1, 22, FALSE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 147U);
      for (c4_i58 = 0; c4_i58 < 2; c4_i58++) {
        c4_e_a[c4_i58] = c4_dir1[c4_i58];
      }

      for (c4_i59 = 0; c4_i59 < 2; c4_i59++) {
        c4_A[c4_i59] = c4_n[c4_i59];
      }

      c4_b_eml_scalar_eg(chartInstance);
      c4_b_eml_scalar_eg(chartInstance);
      c4_distNew1 = 0.0;
      for (c4_o_k = 1; c4_o_k < 3; c4_o_k++) {
        c4_p_k = c4_o_k;
        c4_distNew1 += c4_e_a[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
          _SFD_INTEGER_CHECK("", (real_T)c4_p_k), 1, 2, 1, 0) - 1] *
          c4_A[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
          (real_T)c4_p_k), 1, 2, 1, 0) - 1];
      }

      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 148U);
      if (CV_EML_IF(0, 1, 23, c4_abs(chartInstance, c4_distNew1) < c4_abs
                    (chartInstance, c4_dist1))) {
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 149U);
        c4_rho1 = 0.0;
        _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 150U);
        c4_dist1 = c4_distNew1;
      }
    }

    if (guard1 == TRUE) {
      CV_EML_MCDC(0, 1, 9, TRUE);
      CV_EML_IF(0, 1, 22, TRUE);
      _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, 145U);
    }

    c4_g_j++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 3, 0);
  _SFD_EML_CALL(0U, chartInstance->c4_sfEvent, -150);
  _SFD_SYMBOL_SCOPE_POP();
  *c4_b_dist = c4_dist;
  *c4_b_dist1 = c4_dist1;
  *c4_b_deltaPsi = c4_deltaPsi;
  *c4_b_deltadPsi = c4_deltadPsi;
  *c4_b_rho = c4_rho;
  *c4_b_rho1 = c4_rho1;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 3U, chartInstance->c4_sfEvent);
}

static void initSimStructsc4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc4_laneKeepingArcSplinesFF2013a
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c4_machineNumber, uint32_T
  c4_chartNumber)
{
}

static const mxArray *c4_sf_marshallOut(void *chartInstanceVoid, void *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  real_T c4_u;
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  c4_u = *(real_T *)c4_inData;
  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", &c4_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static real_T c4_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_rho1, const char_T *c4_identifier)
{
  real_T c4_y;
  emlrtMsgIdentifier c4_thisId;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_y = c4_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_rho1), &c4_thisId);
  sf_mex_destroy(&c4_rho1);
  return c4_y;
}

static real_T c4_b_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId)
{
  real_T c4_y;
  real_T c4_d2;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), &c4_d2, 1, 0, 0U, 0, 0U, 0);
  c4_y = c4_d2;
  sf_mex_destroy(&c4_u);
  return c4_y;
}

static void c4_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData)
{
  const mxArray *c4_rho1;
  const char_T *c4_identifier;
  emlrtMsgIdentifier c4_thisId;
  real_T c4_y;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_rho1 = sf_mex_dup(c4_mxArrayInData);
  c4_identifier = c4_varName;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_y = c4_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_rho1), &c4_thisId);
  sf_mex_destroy(&c4_rho1);
  *(real_T *)c4_outData = c4_y;
  sf_mex_destroy(&c4_mxArrayInData);
}

static const mxArray *c4_b_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_i60;
  int32_T c4_i61;
  int32_T c4_i62;
  real_T c4_b_inData[65];
  int32_T c4_i63;
  int32_T c4_i64;
  int32_T c4_i65;
  real_T c4_u[65];
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  c4_i60 = 0;
  for (c4_i61 = 0; c4_i61 < 13; c4_i61++) {
    for (c4_i62 = 0; c4_i62 < 5; c4_i62++) {
      c4_b_inData[c4_i62 + c4_i60] = (*(real_T (*)[65])c4_inData)[c4_i62 +
        c4_i60];
    }

    c4_i60 += 5;
  }

  c4_i63 = 0;
  for (c4_i64 = 0; c4_i64 < 13; c4_i64++) {
    for (c4_i65 = 0; c4_i65 < 5; c4_i65++) {
      c4_u[c4_i65 + c4_i63] = c4_b_inData[c4_i65 + c4_i63];
    }

    c4_i63 += 5;
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 0, 0U, 1U, 0U, 2, 5, 13), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static const mxArray *c4_c_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_i66;
  int32_T c4_i67;
  int32_T c4_i68;
  real_T c4_b_inData[312];
  int32_T c4_i69;
  int32_T c4_i70;
  int32_T c4_i71;
  real_T c4_u[312];
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  c4_i66 = 0;
  for (c4_i67 = 0; c4_i67 < 52; c4_i67++) {
    for (c4_i68 = 0; c4_i68 < 6; c4_i68++) {
      c4_b_inData[c4_i68 + c4_i66] = (*(real_T (*)[312])c4_inData)[c4_i68 +
        c4_i66];
    }

    c4_i66 += 6;
  }

  c4_i69 = 0;
  for (c4_i70 = 0; c4_i70 < 52; c4_i70++) {
    for (c4_i71 = 0; c4_i71 < 6; c4_i71++) {
      c4_u[c4_i71 + c4_i69] = c4_b_inData[c4_i71 + c4_i69];
    }

    c4_i69 += 6;
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 0, 0U, 1U, 0U, 2, 6, 52), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static const mxArray *c4_d_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_i72;
  real_T c4_b_inData[2];
  int32_T c4_i73;
  real_T c4_u[2];
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  for (c4_i72 = 0; c4_i72 < 2; c4_i72++) {
    c4_b_inData[c4_i72] = (*(real_T (*)[2])c4_inData)[c4_i72];
  }

  for (c4_i73 = 0; c4_i73 < 2; c4_i73++) {
    c4_u[c4_i73] = c4_b_inData[c4_i73];
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 0, 0U, 1U, 0U, 1, 2), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static void c4_c_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[2])
{
  real_T c4_dv0[2];
  int32_T c4_i74;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), c4_dv0, 1, 0, 0U, 1, 0U, 1, 2);
  for (c4_i74 = 0; c4_i74 < 2; c4_i74++) {
    c4_y[c4_i74] = c4_dv0[c4_i74];
  }

  sf_mex_destroy(&c4_u);
}

static void c4_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData)
{
  const mxArray *c4_dir1;
  const char_T *c4_identifier;
  emlrtMsgIdentifier c4_thisId;
  real_T c4_y[2];
  int32_T c4_i75;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_dir1 = sf_mex_dup(c4_mxArrayInData);
  c4_identifier = c4_varName;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_dir1), &c4_thisId, c4_y);
  sf_mex_destroy(&c4_dir1);
  for (c4_i75 = 0; c4_i75 < 2; c4_i75++) {
    (*(real_T (*)[2])c4_outData)[c4_i75] = c4_y[c4_i75];
  }

  sf_mex_destroy(&c4_mxArrayInData);
}

static const mxArray *c4_e_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_i76;
  int32_T c4_i77;
  int32_T c4_i78;
  real_T c4_b_inData[26];
  int32_T c4_i79;
  int32_T c4_i80;
  int32_T c4_i81;
  real_T c4_u[26];
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  c4_i76 = 0;
  for (c4_i77 = 0; c4_i77 < 13; c4_i77++) {
    for (c4_i78 = 0; c4_i78 < 2; c4_i78++) {
      c4_b_inData[c4_i78 + c4_i76] = (*(real_T (*)[26])c4_inData)[c4_i78 +
        c4_i76];
    }

    c4_i76 += 2;
  }

  c4_i79 = 0;
  for (c4_i80 = 0; c4_i80 < 13; c4_i80++) {
    for (c4_i81 = 0; c4_i81 < 2; c4_i81++) {
      c4_u[c4_i81 + c4_i79] = c4_b_inData[c4_i81 + c4_i79];
    }

    c4_i79 += 2;
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 0, 0U, 1U, 0U, 2, 2, 13), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static void c4_d_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[26])
{
  real_T c4_dv1[26];
  int32_T c4_i82;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), c4_dv1, 1, 0, 0U, 1, 0U, 2, 2, 13);
  for (c4_i82 = 0; c4_i82 < 26; c4_i82++) {
    c4_y[c4_i82] = c4_dv1[c4_i82];
  }

  sf_mex_destroy(&c4_u);
}

static void c4_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData)
{
  const mxArray *c4_Evec;
  const char_T *c4_identifier;
  emlrtMsgIdentifier c4_thisId;
  real_T c4_y[26];
  int32_T c4_i83;
  int32_T c4_i84;
  int32_T c4_i85;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_Evec = sf_mex_dup(c4_mxArrayInData);
  c4_identifier = c4_varName;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_Evec), &c4_thisId, c4_y);
  sf_mex_destroy(&c4_Evec);
  c4_i83 = 0;
  for (c4_i84 = 0; c4_i84 < 13; c4_i84++) {
    for (c4_i85 = 0; c4_i85 < 2; c4_i85++) {
      (*(real_T (*)[26])c4_outData)[c4_i85 + c4_i83] = c4_y[c4_i85 + c4_i83];
    }

    c4_i83 += 2;
  }

  sf_mex_destroy(&c4_mxArrayInData);
}

static const mxArray *c4_f_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_i86;
  real_T c4_b_inData[52];
  int32_T c4_i87;
  real_T c4_u[52];
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  for (c4_i86 = 0; c4_i86 < 52; c4_i86++) {
    c4_b_inData[c4_i86] = (*(real_T (*)[52])c4_inData)[c4_i86];
  }

  for (c4_i87 = 0; c4_i87 < 52; c4_i87++) {
    c4_u[c4_i87] = c4_b_inData[c4_i87];
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 0, 0U, 1U, 0U, 2, 1, 52), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static void c4_e_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId, real_T c4_y[52])
{
  real_T c4_dv2[52];
  int32_T c4_i88;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), c4_dv2, 1, 0, 0U, 1, 0U, 2, 1, 52);
  for (c4_i88 = 0; c4_i88 < 52; c4_i88++) {
    c4_y[c4_i88] = c4_dv2[c4_i88];
  }

  sf_mex_destroy(&c4_u);
}

static void c4_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData)
{
  const mxArray *c4_thetaRvec;
  const char_T *c4_identifier;
  emlrtMsgIdentifier c4_thisId;
  real_T c4_y[52];
  int32_T c4_i89;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_thetaRvec = sf_mex_dup(c4_mxArrayInData);
  c4_identifier = c4_varName;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_thetaRvec), &c4_thisId,
                        c4_y);
  sf_mex_destroy(&c4_thetaRvec);
  for (c4_i89 = 0; c4_i89 < 52; c4_i89++) {
    (*(real_T (*)[52])c4_outData)[c4_i89] = c4_y[c4_i89];
  }

  sf_mex_destroy(&c4_mxArrayInData);
}

const mxArray
  *sf_c4_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c4_nameCaptureInfo;
  c4_ResolvedFunctionInfo c4_info[75];
  c4_ResolvedFunctionInfo (*c4_b_info)[75];
  const mxArray *c4_m0 = NULL;
  int32_T c4_i90;
  c4_ResolvedFunctionInfo *c4_r0;
  c4_nameCaptureInfo = NULL;
  c4_nameCaptureInfo = NULL;
  c4_info_helper(c4_info);
  c4_b_info = (c4_ResolvedFunctionInfo (*)[75])c4_info;
  (*c4_b_info)[64].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  (*c4_b_info)[64].name = "eml_index_plus";
  (*c4_b_info)[64].dominantType = "coder.internal.indexInt";
  (*c4_b_info)[64].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  (*c4_b_info)[64].fileTimeLo = 1286815178U;
  (*c4_b_info)[64].fileTimeHi = 0U;
  (*c4_b_info)[64].mFileTimeLo = 0U;
  (*c4_b_info)[64].mFileTimeHi = 0U;
  (*c4_b_info)[65].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  (*c4_b_info)[65].name = "eml_int_forloop_overflow_check";
  (*c4_b_info)[65].dominantType = "";
  (*c4_b_info)[65].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m";
  (*c4_b_info)[65].fileTimeLo = 1346506740U;
  (*c4_b_info)[65].fileTimeHi = 0U;
  (*c4_b_info)[65].mFileTimeLo = 0U;
  (*c4_b_info)[65].mFileTimeHi = 0U;
  (*c4_b_info)[66].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  (*c4_b_info)[66].name = "abs";
  (*c4_b_info)[66].dominantType = "double";
  (*c4_b_info)[66].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  (*c4_b_info)[66].fileTimeLo = 1343826766U;
  (*c4_b_info)[66].fileTimeHi = 0U;
  (*c4_b_info)[66].mFileTimeLo = 0U;
  (*c4_b_info)[66].mFileTimeHi = 0U;
  (*c4_b_info)[67].context = "";
  (*c4_b_info)[67].name = "mpower";
  (*c4_b_info)[67].dominantType = "double";
  (*c4_b_info)[67].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  (*c4_b_info)[67].fileTimeLo = 1286815242U;
  (*c4_b_info)[67].fileTimeHi = 0U;
  (*c4_b_info)[67].mFileTimeLo = 0U;
  (*c4_b_info)[67].mFileTimeHi = 0U;
  (*c4_b_info)[68].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  (*c4_b_info)[68].name = "power";
  (*c4_b_info)[68].dominantType = "double";
  (*c4_b_info)[68].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  (*c4_b_info)[68].fileTimeLo = 1348188330U;
  (*c4_b_info)[68].fileTimeHi = 0U;
  (*c4_b_info)[68].mFileTimeLo = 0U;
  (*c4_b_info)[68].mFileTimeHi = 0U;
  (*c4_b_info)[69].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c4_b_info)[69].name = "eml_scalar_eg";
  (*c4_b_info)[69].dominantType = "double";
  (*c4_b_info)[69].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  (*c4_b_info)[69].fileTimeLo = 1286815196U;
  (*c4_b_info)[69].fileTimeHi = 0U;
  (*c4_b_info)[69].mFileTimeLo = 0U;
  (*c4_b_info)[69].mFileTimeHi = 0U;
  (*c4_b_info)[70].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c4_b_info)[70].name = "eml_scalexp_alloc";
  (*c4_b_info)[70].dominantType = "double";
  (*c4_b_info)[70].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  (*c4_b_info)[70].fileTimeLo = 1352421260U;
  (*c4_b_info)[70].fileTimeHi = 0U;
  (*c4_b_info)[70].mFileTimeLo = 0U;
  (*c4_b_info)[70].mFileTimeHi = 0U;
  (*c4_b_info)[71].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  (*c4_b_info)[71].name = "floor";
  (*c4_b_info)[71].dominantType = "double";
  (*c4_b_info)[71].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  (*c4_b_info)[71].fileTimeLo = 1343826780U;
  (*c4_b_info)[71].fileTimeHi = 0U;
  (*c4_b_info)[71].mFileTimeLo = 0U;
  (*c4_b_info)[71].mFileTimeHi = 0U;
  (*c4_b_info)[72].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  (*c4_b_info)[72].name = "eml_scalar_floor";
  (*c4_b_info)[72].dominantType = "double";
  (*c4_b_info)[72].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  (*c4_b_info)[72].fileTimeLo = 1286815126U;
  (*c4_b_info)[72].fileTimeHi = 0U;
  (*c4_b_info)[72].mFileTimeLo = 0U;
  (*c4_b_info)[72].mFileTimeHi = 0U;
  (*c4_b_info)[73].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  (*c4_b_info)[73].name = "eml_scalar_eg";
  (*c4_b_info)[73].dominantType = "double";
  (*c4_b_info)[73].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  (*c4_b_info)[73].fileTimeLo = 1286815196U;
  (*c4_b_info)[73].fileTimeHi = 0U;
  (*c4_b_info)[73].mFileTimeLo = 0U;
  (*c4_b_info)[73].mFileTimeHi = 0U;
  (*c4_b_info)[74].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  (*c4_b_info)[74].name = "mtimes";
  (*c4_b_info)[74].dominantType = "double";
  (*c4_b_info)[74].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c4_b_info)[74].fileTimeLo = 1289516092U;
  (*c4_b_info)[74].fileTimeHi = 0U;
  (*c4_b_info)[74].mFileTimeLo = 0U;
  (*c4_b_info)[74].mFileTimeHi = 0U;
  sf_mex_assign(&c4_m0, sf_mex_createstruct("nameCaptureInfo", 1, 75), FALSE);
  for (c4_i90 = 0; c4_i90 < 75; c4_i90++) {
    c4_r0 = &c4_info[c4_i90];
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c4_r0->context)), "context", "nameCaptureInfo",
                    c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c4_r0->name)), "name", "nameCaptureInfo", c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c4_r0->dominantType)), "dominantType",
                    "nameCaptureInfo", c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c4_r0->resolved)), "resolved", "nameCaptureInfo",
                    c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->mFileTimeLo,
      7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo", c4_i90);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->mFileTimeHi,
      7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo", c4_i90);
  }

  sf_mex_assign(&c4_nameCaptureInfo, c4_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c4_nameCaptureInfo);
  return c4_nameCaptureInfo;
}

static void c4_info_helper(c4_ResolvedFunctionInfo c4_info[75])
{
  c4_info[0].context = "";
  c4_info[0].name = "cos";
  c4_info[0].dominantType = "double";
  c4_info[0].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c4_info[0].fileTimeLo = 1343826772U;
  c4_info[0].fileTimeHi = 0U;
  c4_info[0].mFileTimeLo = 0U;
  c4_info[0].mFileTimeHi = 0U;
  c4_info[1].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c4_info[1].name = "eml_scalar_cos";
  c4_info[1].dominantType = "double";
  c4_info[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c4_info[1].fileTimeLo = 1286815122U;
  c4_info[1].fileTimeHi = 0U;
  c4_info[1].mFileTimeLo = 0U;
  c4_info[1].mFileTimeHi = 0U;
  c4_info[2].context = "";
  c4_info[2].name = "mtimes";
  c4_info[2].dominantType = "double";
  c4_info[2].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c4_info[2].fileTimeLo = 1289516092U;
  c4_info[2].fileTimeHi = 0U;
  c4_info[2].mFileTimeLo = 0U;
  c4_info[2].mFileTimeHi = 0U;
  c4_info[3].context = "";
  c4_info[3].name = "sin";
  c4_info[3].dominantType = "double";
  c4_info[3].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c4_info[3].fileTimeLo = 1343826786U;
  c4_info[3].fileTimeHi = 0U;
  c4_info[3].mFileTimeLo = 0U;
  c4_info[3].mFileTimeHi = 0U;
  c4_info[4].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c4_info[4].name = "eml_scalar_sin";
  c4_info[4].dominantType = "double";
  c4_info[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m";
  c4_info[4].fileTimeLo = 1286815136U;
  c4_info[4].fileTimeHi = 0U;
  c4_info[4].mFileTimeLo = 0U;
  c4_info[4].mFileTimeHi = 0U;
  c4_info[5].context = "";
  c4_info[5].name = "length";
  c4_info[5].dominantType = "double";
  c4_info[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/length.m";
  c4_info[5].fileTimeLo = 1303142606U;
  c4_info[5].fileTimeHi = 0U;
  c4_info[5].mFileTimeLo = 0U;
  c4_info[5].mFileTimeHi = 0U;
  c4_info[6].context = "";
  c4_info[6].name = "sign";
  c4_info[6].dominantType = "double";
  c4_info[6].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c4_info[6].fileTimeLo = 1354364464U;
  c4_info[6].fileTimeHi = 0U;
  c4_info[6].mFileTimeLo = 0U;
  c4_info[6].mFileTimeHi = 0U;
  c4_info[7].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c4_info[7].name = "eml_scalar_sign";
  c4_info[7].dominantType = "double";
  c4_info[7].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sign.m";
  c4_info[7].fileTimeLo = 1354364464U;
  c4_info[7].fileTimeHi = 0U;
  c4_info[7].mFileTimeLo = 0U;
  c4_info[7].mFileTimeHi = 0U;
  c4_info[8].context = "";
  c4_info[8].name = "atan2";
  c4_info[8].dominantType = "double";
  c4_info[8].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c4_info[8].fileTimeLo = 1343826772U;
  c4_info[8].fileTimeHi = 0U;
  c4_info[8].mFileTimeLo = 0U;
  c4_info[8].mFileTimeHi = 0U;
  c4_info[9].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c4_info[9].name = "eml_scalar_eg";
  c4_info[9].dominantType = "double";
  c4_info[9].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c4_info[9].fileTimeLo = 1286815196U;
  c4_info[9].fileTimeHi = 0U;
  c4_info[9].mFileTimeLo = 0U;
  c4_info[9].mFileTimeHi = 0U;
  c4_info[10].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c4_info[10].name = "eml_scalexp_alloc";
  c4_info[10].dominantType = "double";
  c4_info[10].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c4_info[10].fileTimeLo = 1352421260U;
  c4_info[10].fileTimeHi = 0U;
  c4_info[10].mFileTimeLo = 0U;
  c4_info[10].mFileTimeHi = 0U;
  c4_info[11].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan2.m";
  c4_info[11].name = "eml_scalar_atan2";
  c4_info[11].dominantType = "double";
  c4_info[11].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_atan2.m";
  c4_info[11].fileTimeLo = 1286815120U;
  c4_info[11].fileTimeHi = 0U;
  c4_info[11].mFileTimeLo = 0U;
  c4_info[11].mFileTimeHi = 0U;
  c4_info[12].context = "";
  c4_info[12].name = "mod";
  c4_info[12].dominantType = "double";
  c4_info[12].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c4_info[12].fileTimeLo = 1343826782U;
  c4_info[12].fileTimeHi = 0U;
  c4_info[12].mFileTimeLo = 0U;
  c4_info[12].mFileTimeHi = 0U;
  c4_info[13].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c4_info[13].name = "eml_scalar_eg";
  c4_info[13].dominantType = "double";
  c4_info[13].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c4_info[13].fileTimeLo = 1286815196U;
  c4_info[13].fileTimeHi = 0U;
  c4_info[13].mFileTimeLo = 0U;
  c4_info[13].mFileTimeHi = 0U;
  c4_info[14].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m";
  c4_info[14].name = "eml_scalexp_alloc";
  c4_info[14].dominantType = "double";
  c4_info[14].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c4_info[14].fileTimeLo = 1352421260U;
  c4_info[14].fileTimeHi = 0U;
  c4_info[14].mFileTimeLo = 0U;
  c4_info[14].mFileTimeHi = 0U;
  c4_info[15].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[15].name = "eml_scalar_eg";
  c4_info[15].dominantType = "double";
  c4_info[15].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c4_info[15].fileTimeLo = 1286815196U;
  c4_info[15].fileTimeHi = 0U;
  c4_info[15].mFileTimeLo = 0U;
  c4_info[15].mFileTimeHi = 0U;
  c4_info[16].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[16].name = "eml_scalar_floor";
  c4_info[16].dominantType = "double";
  c4_info[16].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c4_info[16].fileTimeLo = 1286815126U;
  c4_info[16].fileTimeHi = 0U;
  c4_info[16].mFileTimeLo = 0U;
  c4_info[16].mFileTimeHi = 0U;
  c4_info[17].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[17].name = "eml_scalar_round";
  c4_info[17].dominantType = "double";
  c4_info[17].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_round.m";
  c4_info[17].fileTimeLo = 1307647638U;
  c4_info[17].fileTimeHi = 0U;
  c4_info[17].mFileTimeLo = 0U;
  c4_info[17].mFileTimeHi = 0U;
  c4_info[18].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[18].name = "eml_scalar_abs";
  c4_info[18].dominantType = "double";
  c4_info[18].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c4_info[18].fileTimeLo = 1286815112U;
  c4_info[18].fileTimeHi = 0U;
  c4_info[18].mFileTimeLo = 0U;
  c4_info[18].mFileTimeHi = 0U;
  c4_info[19].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[19].name = "eps";
  c4_info[19].dominantType = "char";
  c4_info[19].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c4_info[19].fileTimeLo = 1326724396U;
  c4_info[19].fileTimeHi = 0U;
  c4_info[19].mFileTimeLo = 0U;
  c4_info[19].mFileTimeHi = 0U;
  c4_info[20].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c4_info[20].name = "eml_is_float_class";
  c4_info[20].dominantType = "char";
  c4_info[20].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_is_float_class.m";
  c4_info[20].fileTimeLo = 1286815182U;
  c4_info[20].fileTimeHi = 0U;
  c4_info[20].mFileTimeLo = 0U;
  c4_info[20].mFileTimeHi = 0U;
  c4_info[21].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/eps.m";
  c4_info[21].name = "eml_eps";
  c4_info[21].dominantType = "char";
  c4_info[21].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_eps.m";
  c4_info[21].fileTimeLo = 1326724396U;
  c4_info[21].fileTimeHi = 0U;
  c4_info[21].mFileTimeLo = 0U;
  c4_info[21].mFileTimeHi = 0U;
  c4_info[22].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_eps.m";
  c4_info[22].name = "eml_float_model";
  c4_info[22].dominantType = "char";
  c4_info[22].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_float_model.m";
  c4_info[22].fileTimeLo = 1326724396U;
  c4_info[22].fileTimeHi = 0U;
  c4_info[22].mFileTimeLo = 0U;
  c4_info[22].mFileTimeHi = 0U;
  c4_info[23].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/mod.m!floatmod";
  c4_info[23].name = "mtimes";
  c4_info[23].dominantType = "double";
  c4_info[23].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c4_info[23].fileTimeLo = 1289516092U;
  c4_info[23].fileTimeHi = 0U;
  c4_info[23].mFileTimeLo = 0U;
  c4_info[23].mFileTimeHi = 0U;
  c4_info[24].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c4_info[24].name = "eml_index_class";
  c4_info[24].dominantType = "";
  c4_info[24].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[24].fileTimeLo = 1323166978U;
  c4_info[24].fileTimeHi = 0U;
  c4_info[24].mFileTimeLo = 0U;
  c4_info[24].mFileTimeHi = 0U;
  c4_info[25].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c4_info[25].name = "eml_scalar_eg";
  c4_info[25].dominantType = "double";
  c4_info[25].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c4_info[25].fileTimeLo = 1286815196U;
  c4_info[25].fileTimeHi = 0U;
  c4_info[25].mFileTimeLo = 0U;
  c4_info[25].mFileTimeHi = 0U;
  c4_info[26].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c4_info[26].name = "eml_xdotu";
  c4_info[26].dominantType = "double";
  c4_info[26].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c4_info[26].fileTimeLo = 1299073172U;
  c4_info[26].fileTimeHi = 0U;
  c4_info[26].mFileTimeLo = 0U;
  c4_info[26].mFileTimeHi = 0U;
  c4_info[27].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c4_info[27].name = "eml_blas_inline";
  c4_info[27].dominantType = "";
  c4_info[27].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c4_info[27].fileTimeLo = 1299073168U;
  c4_info[27].fileTimeHi = 0U;
  c4_info[27].mFileTimeLo = 0U;
  c4_info[27].mFileTimeHi = 0U;
  c4_info[28].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdotu.m";
  c4_info[28].name = "eml_xdot";
  c4_info[28].dominantType = "double";
  c4_info[28].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdot.m";
  c4_info[28].fileTimeLo = 1299073172U;
  c4_info[28].fileTimeHi = 0U;
  c4_info[28].mFileTimeLo = 0U;
  c4_info[28].mFileTimeHi = 0U;
  c4_info[29].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xdot.m";
  c4_info[29].name = "eml_blas_inline";
  c4_info[29].dominantType = "";
  c4_info[29].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c4_info[29].fileTimeLo = 1299073168U;
  c4_info[29].fileTimeHi = 0U;
  c4_info[29].mFileTimeLo = 0U;
  c4_info[29].mFileTimeHi = 0U;
  c4_info[30].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xdot.m";
  c4_info[30].name = "eml_index_class";
  c4_info[30].dominantType = "";
  c4_info[30].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[30].fileTimeLo = 1323166978U;
  c4_info[30].fileTimeHi = 0U;
  c4_info[30].mFileTimeLo = 0U;
  c4_info[30].mFileTimeHi = 0U;
  c4_info[31].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xdot.m";
  c4_info[31].name = "eml_refblas_xdot";
  c4_info[31].dominantType = "double";
  c4_info[31].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdot.m";
  c4_info[31].fileTimeLo = 1299073172U;
  c4_info[31].fileTimeHi = 0U;
  c4_info[31].mFileTimeLo = 0U;
  c4_info[31].mFileTimeHi = 0U;
  c4_info[32].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdot.m";
  c4_info[32].name = "eml_refblas_xdotx";
  c4_info[32].dominantType = "char";
  c4_info[32].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[32].fileTimeLo = 1299073174U;
  c4_info[32].fileTimeHi = 0U;
  c4_info[32].mFileTimeLo = 0U;
  c4_info[32].mFileTimeHi = 0U;
  c4_info[33].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[33].name = "eml_scalar_eg";
  c4_info[33].dominantType = "double";
  c4_info[33].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c4_info[33].fileTimeLo = 1286815196U;
  c4_info[33].fileTimeHi = 0U;
  c4_info[33].mFileTimeLo = 0U;
  c4_info[33].mFileTimeHi = 0U;
  c4_info[34].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[34].name = "eml_index_class";
  c4_info[34].dominantType = "";
  c4_info[34].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[34].fileTimeLo = 1323166978U;
  c4_info[34].fileTimeHi = 0U;
  c4_info[34].mFileTimeLo = 0U;
  c4_info[34].mFileTimeHi = 0U;
  c4_info[35].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[35].name = "eml_index_minus";
  c4_info[35].dominantType = "double";
  c4_info[35].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c4_info[35].fileTimeLo = 1286815178U;
  c4_info[35].fileTimeHi = 0U;
  c4_info[35].mFileTimeLo = 0U;
  c4_info[35].mFileTimeHi = 0U;
  c4_info[36].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c4_info[36].name = "eml_index_class";
  c4_info[36].dominantType = "";
  c4_info[36].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[36].fileTimeLo = 1323166978U;
  c4_info[36].fileTimeHi = 0U;
  c4_info[36].mFileTimeLo = 0U;
  c4_info[36].mFileTimeHi = 0U;
  c4_info[37].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[37].name = "eml_index_times";
  c4_info[37].dominantType = "coder.internal.indexInt";
  c4_info[37].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c4_info[37].fileTimeLo = 1286815180U;
  c4_info[37].fileTimeHi = 0U;
  c4_info[37].mFileTimeLo = 0U;
  c4_info[37].mFileTimeHi = 0U;
  c4_info[38].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c4_info[38].name = "eml_index_class";
  c4_info[38].dominantType = "";
  c4_info[38].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[38].fileTimeLo = 1323166978U;
  c4_info[38].fileTimeHi = 0U;
  c4_info[38].mFileTimeLo = 0U;
  c4_info[38].mFileTimeHi = 0U;
  c4_info[39].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[39].name = "eml_index_plus";
  c4_info[39].dominantType = "coder.internal.indexInt";
  c4_info[39].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c4_info[39].fileTimeLo = 1286815178U;
  c4_info[39].fileTimeHi = 0U;
  c4_info[39].mFileTimeLo = 0U;
  c4_info[39].mFileTimeHi = 0U;
  c4_info[40].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_plus.m";
  c4_info[40].name = "eml_index_class";
  c4_info[40].dominantType = "";
  c4_info[40].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[40].fileTimeLo = 1323166978U;
  c4_info[40].fileTimeHi = 0U;
  c4_info[40].mFileTimeLo = 0U;
  c4_info[40].mFileTimeHi = 0U;
  c4_info[41].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xdotx.m";
  c4_info[41].name = "eml_int_forloop_overflow_check";
  c4_info[41].dominantType = "";
  c4_info[41].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m";
  c4_info[41].fileTimeLo = 1346506740U;
  c4_info[41].fileTimeHi = 0U;
  c4_info[41].mFileTimeLo = 0U;
  c4_info[41].mFileTimeHi = 0U;
  c4_info[42].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m!eml_int_forloop_overflow_check_helper";
  c4_info[42].name = "intmax";
  c4_info[42].dominantType = "char";
  c4_info[42].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m";
  c4_info[42].fileTimeLo = 1311251716U;
  c4_info[42].fileTimeHi = 0U;
  c4_info[42].mFileTimeLo = 0U;
  c4_info[42].mFileTimeHi = 0U;
  c4_info[43].context = "";
  c4_info[43].name = "sqrt";
  c4_info[43].dominantType = "double";
  c4_info[43].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c4_info[43].fileTimeLo = 1343826786U;
  c4_info[43].fileTimeHi = 0U;
  c4_info[43].mFileTimeLo = 0U;
  c4_info[43].mFileTimeHi = 0U;
  c4_info[44].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c4_info[44].name = "eml_error";
  c4_info[44].dominantType = "char";
  c4_info[44].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c4_info[44].fileTimeLo = 1343826758U;
  c4_info[44].fileTimeHi = 0U;
  c4_info[44].mFileTimeLo = 0U;
  c4_info[44].mFileTimeHi = 0U;
  c4_info[45].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c4_info[45].name = "eml_scalar_sqrt";
  c4_info[45].dominantType = "double";
  c4_info[45].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c4_info[45].fileTimeLo = 1286815138U;
  c4_info[45].fileTimeHi = 0U;
  c4_info[45].mFileTimeLo = 0U;
  c4_info[45].mFileTimeHi = 0U;
  c4_info[46].context = "";
  c4_info[46].name = "mrdivide";
  c4_info[46].dominantType = "double";
  c4_info[46].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c4_info[46].fileTimeLo = 1357947948U;
  c4_info[46].fileTimeHi = 0U;
  c4_info[46].mFileTimeLo = 1319726366U;
  c4_info[46].mFileTimeHi = 0U;
  c4_info[47].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c4_info[47].name = "rdivide";
  c4_info[47].dominantType = "double";
  c4_info[47].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c4_info[47].fileTimeLo = 1346506788U;
  c4_info[47].fileTimeHi = 0U;
  c4_info[47].mFileTimeLo = 0U;
  c4_info[47].mFileTimeHi = 0U;
  c4_info[48].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c4_info[48].name = "eml_scalexp_compatible";
  c4_info[48].dominantType = "double";
  c4_info[48].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  c4_info[48].fileTimeLo = 1286815196U;
  c4_info[48].fileTimeHi = 0U;
  c4_info[48].mFileTimeLo = 0U;
  c4_info[48].mFileTimeHi = 0U;
  c4_info[49].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c4_info[49].name = "eml_div";
  c4_info[49].dominantType = "double";
  c4_info[49].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c4_info[49].fileTimeLo = 1313344210U;
  c4_info[49].fileTimeHi = 0U;
  c4_info[49].mFileTimeLo = 0U;
  c4_info[49].mFileTimeHi = 0U;
  c4_info[50].context = "";
  c4_info[50].name = "abs";
  c4_info[50].dominantType = "double";
  c4_info[50].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c4_info[50].fileTimeLo = 1343826766U;
  c4_info[50].fileTimeHi = 0U;
  c4_info[50].mFileTimeLo = 0U;
  c4_info[50].mFileTimeHi = 0U;
  c4_info[51].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c4_info[51].name = "eml_scalar_abs";
  c4_info[51].dominantType = "double";
  c4_info[51].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c4_info[51].fileTimeLo = 1286815112U;
  c4_info[51].fileTimeHi = 0U;
  c4_info[51].mFileTimeLo = 0U;
  c4_info[51].mFileTimeHi = 0U;
  c4_info[52].context = "";
  c4_info[52].name = "norm";
  c4_info[52].dominantType = "double";
  c4_info[52].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m";
  c4_info[52].fileTimeLo = 1336518494U;
  c4_info[52].fileTimeHi = 0U;
  c4_info[52].mFileTimeLo = 0U;
  c4_info[52].mFileTimeHi = 0U;
  c4_info[53].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m!genpnorm";
  c4_info[53].name = "eml_index_class";
  c4_info[53].dominantType = "";
  c4_info[53].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[53].fileTimeLo = 1323166978U;
  c4_info[53].fileTimeHi = 0U;
  c4_info[53].mFileTimeLo = 0U;
  c4_info[53].mFileTimeHi = 0U;
  c4_info[54].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/matfun/norm.m!genpnorm";
  c4_info[54].name = "eml_xnrm2";
  c4_info[54].dominantType = "double";
  c4_info[54].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xnrm2.m";
  c4_info[54].fileTimeLo = 1299073176U;
  c4_info[54].fileTimeHi = 0U;
  c4_info[54].mFileTimeLo = 0U;
  c4_info[54].mFileTimeHi = 0U;
  c4_info[55].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xnrm2.m";
  c4_info[55].name = "eml_blas_inline";
  c4_info[55].dominantType = "";
  c4_info[55].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_blas_inline.m";
  c4_info[55].fileTimeLo = 1299073168U;
  c4_info[55].fileTimeHi = 0U;
  c4_info[55].mFileTimeLo = 0U;
  c4_info[55].mFileTimeHi = 0U;
  c4_info[56].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xnrm2.m";
  c4_info[56].name = "eml_index_class";
  c4_info[56].dominantType = "";
  c4_info[56].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[56].fileTimeLo = 1323166978U;
  c4_info[56].fileTimeHi = 0U;
  c4_info[56].mFileTimeLo = 0U;
  c4_info[56].mFileTimeHi = 0U;
  c4_info[57].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/external/eml_blas_xnrm2.m";
  c4_info[57].name = "eml_refblas_xnrm2";
  c4_info[57].dominantType = "double";
  c4_info[57].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c4_info[57].fileTimeLo = 1299073184U;
  c4_info[57].fileTimeHi = 0U;
  c4_info[57].mFileTimeLo = 0U;
  c4_info[57].mFileTimeHi = 0U;
  c4_info[58].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c4_info[58].name = "realmin";
  c4_info[58].dominantType = "char";
  c4_info[58].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/realmin.m";
  c4_info[58].fileTimeLo = 1307647642U;
  c4_info[58].fileTimeHi = 0U;
  c4_info[58].mFileTimeLo = 0U;
  c4_info[58].mFileTimeHi = 0U;
  c4_info[59].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/realmin.m";
  c4_info[59].name = "eml_realmin";
  c4_info[59].dominantType = "char";
  c4_info[59].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_realmin.m";
  c4_info[59].fileTimeLo = 1307647644U;
  c4_info[59].fileTimeHi = 0U;
  c4_info[59].mFileTimeLo = 0U;
  c4_info[59].mFileTimeHi = 0U;
  c4_info[60].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_realmin.m";
  c4_info[60].name = "eml_float_model";
  c4_info[60].dominantType = "char";
  c4_info[60].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_float_model.m";
  c4_info[60].fileTimeLo = 1326724396U;
  c4_info[60].fileTimeHi = 0U;
  c4_info[60].mFileTimeLo = 0U;
  c4_info[60].mFileTimeHi = 0U;
  c4_info[61].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c4_info[61].name = "eml_index_class";
  c4_info[61].dominantType = "";
  c4_info[61].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m";
  c4_info[61].fileTimeLo = 1323166978U;
  c4_info[61].fileTimeHi = 0U;
  c4_info[61].mFileTimeLo = 0U;
  c4_info[61].mFileTimeHi = 0U;
  c4_info[62].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c4_info[62].name = "eml_index_minus";
  c4_info[62].dominantType = "double";
  c4_info[62].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_minus.m";
  c4_info[62].fileTimeLo = 1286815178U;
  c4_info[62].fileTimeHi = 0U;
  c4_info[62].mFileTimeLo = 0U;
  c4_info[62].mFileTimeHi = 0U;
  c4_info[63].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/refblas/eml_refblas_xnrm2.m";
  c4_info[63].name = "eml_index_times";
  c4_info[63].dominantType = "coder.internal.indexInt";
  c4_info[63].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_times.m";
  c4_info[63].fileTimeLo = 1286815180U;
  c4_info[63].fileTimeHi = 0U;
  c4_info[63].mFileTimeLo = 0U;
  c4_info[63].mFileTimeHi = 0U;
}

static real_T c4_sign(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x)
{
  real_T c4_b_x;
  c4_b_x = c4_x;
  c4_b_sign(chartInstance, &c4_b_x);
  return c4_b_x;
}

static real_T c4_atan2(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c4_y, real_T c4_x)
{
  real_T c4_b_y;
  real_T c4_b_x;
  c4_eml_scalar_eg(chartInstance);
  c4_b_y = c4_y;
  c4_b_x = c4_x;
  return muDoubleScalarAtan2(c4_b_y, c4_b_x);
}

static void c4_eml_scalar_eg(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
}

static real_T c4_mod(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c4_x, real_T c4_y)
{
  real_T c4_r;
  real_T c4_xk;
  real_T c4_yk;
  real_T c4_b_x;
  real_T c4_b_y;
  real_T c4_c_x;
  real_T c4_d_x;
  real_T c4_e_x;
  real_T c4_f_x;
  real_T c4_g_x;
  real_T c4_h_x;
  real_T c4_i_x;
  real_T c4_c_y;
  real_T c4_j_x;
  real_T c4_d_y;
  real_T c4_b;
  real_T c4_e_y;
  real_T c4_k_x;
  real_T c4_l_x;
  c4_eml_scalar_eg(chartInstance);
  c4_xk = c4_x;
  c4_yk = c4_y;
  c4_b_x = c4_xk;
  c4_b_y = c4_yk;
  c4_eml_scalar_eg(chartInstance);
  if (c4_b_y == 0.0) {
    c4_r = c4_b_x;
  } else {
    c4_c_x = c4_b_y;
    c4_d_x = c4_c_x;
    c4_d_x = muDoubleScalarFloor(c4_d_x);
    if (c4_b_y == c4_d_x) {
      c4_e_x = c4_b_x / c4_b_y;
      c4_f_x = c4_e_x;
      c4_f_x = muDoubleScalarFloor(c4_f_x);
      c4_r = c4_b_x - c4_f_x * c4_b_y;
    } else {
      c4_r = c4_b_x / c4_b_y;
      c4_g_x = c4_r;
      c4_h_x = c4_g_x;
      c4_h_x = muDoubleScalarRound(c4_h_x);
      c4_i_x = c4_r - c4_h_x;
      c4_c_y = muDoubleScalarAbs(c4_i_x);
      c4_j_x = c4_r;
      c4_d_y = muDoubleScalarAbs(c4_j_x);
      c4_b = c4_d_y;
      c4_e_y = 2.2204460492503131E-16 * c4_b;
      if (c4_c_y <= c4_e_y) {
        c4_r = 0.0;
      } else {
        c4_k_x = c4_r;
        c4_l_x = c4_k_x;
        c4_l_x = muDoubleScalarFloor(c4_l_x);
        c4_r = (c4_r - c4_l_x) * c4_b_y;
      }
    }
  }

  return c4_r;
}

static void c4_b_eml_scalar_eg(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
}

static real_T c4_sqrt(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x)
{
  real_T c4_b_x;
  c4_b_x = c4_x;
  c4_b_sqrt(chartInstance, &c4_b_x);
  return c4_b_x;
}

static void c4_eml_error(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c4_i91;
  static char_T c4_cv0[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  char_T c4_u[30];
  const mxArray *c4_y = NULL;
  int32_T c4_i92;
  static char_T c4_cv1[4] = { 's', 'q', 'r', 't' };

  char_T c4_b_u[4];
  const mxArray *c4_b_y = NULL;
  for (c4_i91 = 0; c4_i91 < 30; c4_i91++) {
    c4_u[c4_i91] = c4_cv0[c4_i91];
  }

  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", c4_u, 10, 0U, 1U, 0U, 2, 1, 30), FALSE);
  for (c4_i92 = 0; c4_i92 < 4; c4_i92++) {
    c4_b_u[c4_i92] = c4_cv1[c4_i92];
  }

  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", c4_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 2U, 14,
    c4_y, 14, c4_b_y));
}

static real_T c4_abs(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                     *chartInstance, real_T c4_x)
{
  real_T c4_b_x;
  c4_b_x = c4_x;
  return muDoubleScalarAbs(c4_b_x);
}

static real_T c4_norm(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T c4_x[2])
{
  real_T c4_y;
  real_T c4_scale;
  int32_T c4_k;
  int32_T c4_b_k;
  real_T c4_b_x;
  real_T c4_c_x;
  real_T c4_absxk;
  real_T c4_t;
  c4_y = 0.0;
  c4_scale = 2.2250738585072014E-308;
  for (c4_k = 1; c4_k < 3; c4_k++) {
    c4_b_k = c4_k;
    c4_b_x = c4_x[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c4_b_k), 1, 2, 1, 0) - 1];
    c4_c_x = c4_b_x;
    c4_absxk = muDoubleScalarAbs(c4_c_x);
    if (c4_absxk > c4_scale) {
      c4_t = c4_scale / c4_absxk;
      c4_y = 1.0 + c4_y * c4_t * c4_t;
      c4_scale = c4_absxk;
    } else {
      c4_t = c4_absxk / c4_scale;
      c4_y += c4_t * c4_t;
    }
  }

  return c4_scale * muDoubleScalarSqrt(c4_y);
}

static real_T c4_mpower(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c4_a)
{
  real_T c4_b_a;
  real_T c4_c_a;
  real_T c4_ak;
  real_T c4_d_a;
  real_T c4_e_a;
  real_T c4_b;
  c4_b_a = c4_a;
  c4_c_a = c4_b_a;
  c4_eml_scalar_eg(chartInstance);
  c4_ak = c4_c_a;
  c4_d_a = c4_ak;
  c4_eml_scalar_eg(chartInstance);
  c4_e_a = c4_d_a;
  c4_b = c4_d_a;
  return c4_e_a * c4_b;
}

static const mxArray *c4_g_sf_marshallOut(void *chartInstanceVoid, void
  *c4_inData)
{
  const mxArray *c4_mxArrayOutData = NULL;
  int32_T c4_u;
  const mxArray *c4_y = NULL;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_mxArrayOutData = NULL;
  c4_u = *(int32_T *)c4_inData;
  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_create("y", &c4_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c4_mxArrayOutData, c4_y, FALSE);
  return c4_mxArrayOutData;
}

static int32_T c4_f_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId)
{
  int32_T c4_y;
  int32_T c4_i93;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), &c4_i93, 1, 6, 0U, 0, 0U, 0);
  c4_y = c4_i93;
  sf_mex_destroy(&c4_u);
  return c4_y;
}

static void c4_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c4_mxArrayInData, const char_T *c4_varName, void *c4_outData)
{
  const mxArray *c4_b_sfEvent;
  const char_T *c4_identifier;
  emlrtMsgIdentifier c4_thisId;
  int32_T c4_y;
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c4_b_sfEvent = sf_mex_dup(c4_mxArrayInData);
  c4_identifier = c4_varName;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_y = c4_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c4_b_sfEvent),
    &c4_thisId);
  sf_mex_destroy(&c4_b_sfEvent);
  *(int32_T *)c4_outData = c4_y;
  sf_mex_destroy(&c4_mxArrayInData);
}

static uint8_T c4_g_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_b_is_active_c4_laneKeepingArcSplinesFF2013a, const char_T *c4_identifier)
{
  uint8_T c4_y;
  emlrtMsgIdentifier c4_thisId;
  c4_thisId.fIdentifier = c4_identifier;
  c4_thisId.fParent = NULL;
  c4_y = c4_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c4_b_is_active_c4_laneKeepingArcSplinesFF2013a), &c4_thisId);
  sf_mex_destroy(&c4_b_is_active_c4_laneKeepingArcSplinesFF2013a);
  return c4_y;
}

static uint8_T c4_h_emlrt_marshallIn
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c4_u, const emlrtMsgIdentifier *c4_parentId)
{
  uint8_T c4_y;
  uint8_T c4_u0;
  sf_mex_import(c4_parentId, sf_mex_dup(c4_u), &c4_u0, 1, 3, 0U, 0, 0U, 0);
  c4_y = c4_u0;
  sf_mex_destroy(&c4_u);
  return c4_y;
}

static void c4_b_sign(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c4_x)
{
  *c4_x = muDoubleScalarSign(*c4_x);
}

static void c4_b_sqrt(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct
                      *chartInstance, real_T *c4_x)
{
  if (*c4_x < 0.0) {
    c4_eml_error(chartInstance);
  }

  *c4_x = muDoubleScalarSqrt(*c4_x);
}

static void init_dsm_address_info
  (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c4_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1249909476U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1886605872U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2818076252U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(155604481U);
}

mxArray *sf_c4_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("5tI2S76Rp0FP2EenFdo4KD");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,8,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(6);
      pr[1] = (double)(52);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(5);
      pr[1] = (double)(13);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,6,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c4_laneKeepingArcSplinesFF2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c4_laneKeepingArcSplinesFF2013a(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x7'type','srcId','name','auxInfo'{{M[1],M[17],T\"deltaPsi\",},{M[1],M[20],T\"deltadPsi\",},{M[1],M[5],T\"dist\",},{M[1],M[16],T\"dist1\",},{M[1],M[21],T\"rho\",},{M[1],M[22],T\"rho1\",},{M[8],M[0],T\"is_active_c4_laneKeepingArcSplinesFF2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 7, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c4_laneKeepingArcSplinesFF2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
    chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF2013aMachineNumber_,
           4,
           1,
           1,
           14,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"CircleData");
          _SFD_SET_DATA_PROPS(1,2,0,1,"dist");
          _SFD_SET_DATA_PROPS(2,1,1,0,"LineData");
          _SFD_SET_DATA_PROPS(3,1,1,0,"X1");
          _SFD_SET_DATA_PROPS(4,1,1,0,"Y1");
          _SFD_SET_DATA_PROPS(5,1,1,0,"Psi");
          _SFD_SET_DATA_PROPS(6,1,1,0,"dPsi");
          _SFD_SET_DATA_PROPS(7,1,1,0,"vel");
          _SFD_SET_DATA_PROPS(8,1,1,0,"l_S");
          _SFD_SET_DATA_PROPS(9,2,0,1,"dist1");
          _SFD_SET_DATA_PROPS(10,2,0,1,"deltaPsi");
          _SFD_SET_DATA_PROPS(11,2,0,1,"deltadPsi");
          _SFD_SET_DATA_PROPS(12,2,0,1,"rho");
          _SFD_SET_DATA_PROPS(13,2,0,1,"rho1");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,24,0,0,0,4,0,20,10);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,4443);
        _SFD_CV_INIT_EML_IF(0,1,0,658,688,941,1205);
        _SFD_CV_INIT_EML_IF(0,1,1,697,721,827,936);
        _SFD_CV_INIT_EML_IF(0,1,2,734,776,-1,818);
        _SFD_CV_INIT_EML_IF(0,1,3,843,884,-1,924);
        _SFD_CV_INIT_EML_IF(0,1,4,954,978,1084,1193);
        _SFD_CV_INIT_EML_IF(0,1,5,991,1033,-1,1075);
        _SFD_CV_INIT_EML_IF(0,1,6,1100,1141,-1,1181);
        _SFD_CV_INIT_EML_IF(0,1,7,1415,1442,-1,1712);
        _SFD_CV_INIT_EML_IF(0,1,8,1575,1591,1636,1657);
        _SFD_CV_INIT_EML_IF(0,1,9,1636,1657,-1,1657);
        _SFD_CV_INIT_EML_IF(0,1,10,1965,1982,2005,2393);
        _SFD_CV_INIT_EML_IF(0,1,11,2044,2071,-1,2385);
        _SFD_CV_INIT_EML_IF(0,1,12,2223,2239,2294,2315);
        _SFD_CV_INIT_EML_IF(0,1,13,2294,2315,-1,2315);
        _SFD_CV_INIT_EML_IF(0,1,14,2696,2726,2983,3251);
        _SFD_CV_INIT_EML_IF(0,1,15,2735,2759,2867,2978);
        _SFD_CV_INIT_EML_IF(0,1,16,2772,2816,-1,2858);
        _SFD_CV_INIT_EML_IF(0,1,17,2883,2926,-1,2966);
        _SFD_CV_INIT_EML_IF(0,1,18,2996,3020,3128,3239);
        _SFD_CV_INIT_EML_IF(0,1,19,3033,3077,-1,3119);
        _SFD_CV_INIT_EML_IF(0,1,20,3144,3187,-1,3227);
        _SFD_CV_INIT_EML_IF(0,1,21,3471,3500,-1,3788);
        _SFD_CV_INIT_EML_IF(0,1,22,3995,4012,4035,4432);
        _SFD_CV_INIT_EML_IF(0,1,23,4076,4105,-1,4424);
        _SFD_CV_INIT_EML_FOR(0,1,0,362,385,1762);
        _SFD_CV_INIT_EML_FOR(0,1,1,1812,1835,2397);
        _SFD_CV_INIT_EML_FOR(0,1,2,2399,2422,3838);
        _SFD_CV_INIT_EML_FOR(0,1,3,3840,3863,4436);

        {
          static int condStart[] = { 737, 758 };

          static int condEnd[] = { 754, 776 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,0,737,776,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 846, 867 };

          static int condEnd[] = { 863, 884 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,1,846,884,2,2,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 994, 1015 };

          static int condEnd[] = { 1011, 1033 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,2,994,1033,2,4,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1103, 1124 };

          static int condEnd[] = { 1120, 1141 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,3,1103,1141,2,6,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1968, 1977 };

          static int condEnd[] = { 1973, 1982 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,4,1968,1982,2,8,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2775, 2797 };

          static int condEnd[] = { 2793, 2816 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,5,2775,2816,2,10,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2886, 2908 };

          static int condEnd[] = { 2904, 2926 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,6,2886,2926,2,12,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3036, 3058 };

          static int condEnd[] = { 3054, 3077 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,7,3036,3077,2,14,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3147, 3169 };

          static int condEnd[] = { 3165, 3187 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,8,3147,3187,2,16,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3998, 4007 };

          static int condEnd[] = { 4003, 4012 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,9,3998,4012,2,18,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          unsigned int dimVector[2];
          dimVector[0]= 6;
          dimVector[1]= 52;
          _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c4_c_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);

        {
          unsigned int dimVector[2];
          dimVector[0]= 5;
          dimVector[1]= 13;
          _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c4_b_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c4_sf_marshallOut,(MexInFcnForType)c4_sf_marshallIn);

        {
          real_T *c4_dist;
          real_T *c4_X1;
          real_T *c4_Y1;
          real_T *c4_Psi;
          real_T *c4_dPsi;
          real_T *c4_vel;
          real_T *c4_l_S;
          real_T *c4_dist1;
          real_T *c4_deltaPsi;
          real_T *c4_deltadPsi;
          real_T *c4_rho;
          real_T *c4_rho1;
          real_T (*c4_CircleData)[312];
          real_T (*c4_LineData)[65];
          c4_rho1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 6);
          c4_rho = (real_T *)ssGetOutputPortSignal(chartInstance->S, 5);
          c4_deltadPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 4);
          c4_deltaPsi = (real_T *)ssGetOutputPortSignal(chartInstance->S, 3);
          c4_dist1 = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c4_l_S = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
          c4_vel = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c4_dPsi = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c4_Psi = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c4_Y1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c4_X1 = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c4_LineData = (real_T (*)[65])ssGetInputPortSignal(chartInstance->S, 1);
          c4_dist = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c4_CircleData = (real_T (*)[312])ssGetInputPortSignal(chartInstance->S,
            0);
          _SFD_SET_DATA_VALUE_PTR(0U, *c4_CircleData);
          _SFD_SET_DATA_VALUE_PTR(1U, c4_dist);
          _SFD_SET_DATA_VALUE_PTR(2U, *c4_LineData);
          _SFD_SET_DATA_VALUE_PTR(3U, c4_X1);
          _SFD_SET_DATA_VALUE_PTR(4U, c4_Y1);
          _SFD_SET_DATA_VALUE_PTR(5U, c4_Psi);
          _SFD_SET_DATA_VALUE_PTR(6U, c4_dPsi);
          _SFD_SET_DATA_VALUE_PTR(7U, c4_vel);
          _SFD_SET_DATA_VALUE_PTR(8U, c4_l_S);
          _SFD_SET_DATA_VALUE_PTR(9U, c4_dist1);
          _SFD_SET_DATA_VALUE_PTR(10U, c4_deltaPsi);
          _SFD_SET_DATA_VALUE_PTR(11U, c4_deltadPsi);
          _SFD_SET_DATA_VALUE_PTR(12U, c4_rho);
          _SFD_SET_DATA_VALUE_PTR(13U, c4_rho1);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "3zmJNd7LYqZn8w3t5nDpBD";
}

static void sf_opaque_initialize_c4_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
  initialize_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c4_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  enable_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c4_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  disable_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c4_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  sf_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c4_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c4_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c4_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c4_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c4_laneKeepingArcSplinesFF2013a(S);
}

static void sf_opaque_set_sim_state_c4_laneKeepingArcSplinesFF2013a(SimStruct* S,
  const mxArray *st)
{
  sf_internal_set_sim_state_c4_laneKeepingArcSplinesFF2013a(S, st);
}

static void sf_opaque_terminate_c4_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF2013a_optimization_info();
    }

    finalize_c4_laneKeepingArcSplinesFF2013a
      ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc4_laneKeepingArcSplinesFF2013a
    ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c4_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c4_laneKeepingArcSplinesFF2013a
      ((SFc4_laneKeepingArcSplinesFF2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c4_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      4);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,4,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,4,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,4);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 7, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,4,8);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,4,6);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=6; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 8; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,4);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(2780328392U));
  ssSetChecksum1(S,(3138387166U));
  ssSetChecksum2(S,(2281440394U));
  ssSetChecksum3(S,(2409875858U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c4_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c4_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct *)utMalloc
    (sizeof(SFc4_laneKeepingArcSplinesFF2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc4_laneKeepingArcSplinesFF2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c4_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c4_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c4_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c4_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c4_laneKeepingArcSplinesFF2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c4_laneKeepingArcSplinesFF2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
