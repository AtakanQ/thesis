/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "c3_laneKeepingArcSplinesFF2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c3_debug_family_names[17] = { "aSym", "bSym", "mSym", "ISym",
  "cfSym", "crSym", "kSym", "KSym", "RSym", "betaSym", "nargin", "nargout",
  "rho", "beta", "ds", "dds", "delta" };

/* Function Declarations */
static void initialize_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initialize_params_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void enable_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void disable_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c3_update_debugger_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void set_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_st);
static void finalize_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void sf_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c3_chartstep_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initSimStructsc3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void registerMessagesc3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber);
static const mxArray *c3_sf_marshallOut(void *chartInstanceVoid, void *c3_inData);
static real_T c3_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_delta, const char_T *c3_identifier);
static real_T c3_b_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData);
static void c3_info_helper(c3_ResolvedFunctionInfo c3_info[21]);
static real_T c3_mpower(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c3_a);
static void c3_eml_scalar_eg(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c3_b_mpower(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c3_a);
static void c3_eml_error(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static void c3_b_eml_error(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static const mxArray *c3_b_sf_marshallOut(void *chartInstanceVoid, void
  *c3_inData);
static int32_T c3_c_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData);
static uint8_T c3_d_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_b_is_active_c3_laneKeepingArcSplinesFF2013a, const char_T *c3_identifier);
static uint8_T c3_e_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void init_dsm_address_info
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  chartInstance->c3_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c3_is_active_c3_laneKeepingArcSplinesFF2013a = 0U;
}

static void initialize_params_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void enable_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c3_update_debugger_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  const mxArray *c3_st;
  const mxArray *c3_y = NULL;
  real_T c3_hoistedGlobal;
  real_T c3_u;
  const mxArray *c3_b_y = NULL;
  uint8_T c3_b_hoistedGlobal;
  uint8_T c3_b_u;
  const mxArray *c3_c_y = NULL;
  real_T *c3_delta;
  c3_delta = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c3_st = NULL;
  c3_st = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_createcellarray(2), FALSE);
  c3_hoistedGlobal = *c3_delta;
  c3_u = c3_hoistedGlobal;
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", &c3_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c3_y, 0, c3_b_y);
  c3_b_hoistedGlobal =
    chartInstance->c3_is_active_c3_laneKeepingArcSplinesFF2013a;
  c3_b_u = c3_b_hoistedGlobal;
  c3_c_y = NULL;
  sf_mex_assign(&c3_c_y, sf_mex_create("y", &c3_b_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c3_y, 1, c3_c_y);
  sf_mex_assign(&c3_st, c3_y, FALSE);
  return c3_st;
}

static void set_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_st)
{
  const mxArray *c3_u;
  real_T *c3_delta;
  c3_delta = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c3_doneDoubleBufferReInit = TRUE;
  c3_u = sf_mex_dup(c3_st);
  *c3_delta = c3_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c3_u,
    0)), "delta");
  chartInstance->c3_is_active_c3_laneKeepingArcSplinesFF2013a =
    c3_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c3_u, 1)),
    "is_active_c3_laneKeepingArcSplinesFF2013a");
  sf_mex_destroy(&c3_u);
  c3_update_debugger_state_c3_laneKeepingArcSplinesFF2013a(chartInstance);
  sf_mex_destroy(&c3_st);
}

static void finalize_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void sf_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T *c3_rho;
  real_T *c3_delta;
  real_T *c3_beta;
  real_T *c3_ds;
  real_T *c3_dds;
  c3_dds = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c3_ds = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c3_beta = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c3_delta = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c3_rho = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
  _SFD_DATA_RANGE_CHECK(*c3_rho, 0U);
  _SFD_DATA_RANGE_CHECK(*c3_delta, 1U);
  _SFD_DATA_RANGE_CHECK(*c3_beta, 2U);
  _SFD_DATA_RANGE_CHECK(*c3_ds, 3U);
  _SFD_DATA_RANGE_CHECK(*c3_dds, 4U);
  chartInstance->c3_sfEvent = CALL_EVENT;
  c3_chartstep_c3_laneKeepingArcSplinesFF2013a(chartInstance);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_laneKeepingArcSplinesFF2013aMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c3_chartstep_c3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T c3_hoistedGlobal;
  real_T c3_b_hoistedGlobal;
  real_T c3_c_hoistedGlobal;
  real_T c3_d_hoistedGlobal;
  real_T c3_rho;
  real_T c3_beta;
  real_T c3_ds;
  real_T c3_dds;
  uint32_T c3_debug_family_var_map[17];
  real_T c3_aSym;
  real_T c3_bSym;
  real_T c3_mSym;
  real_T c3_ISym;
  real_T c3_cfSym;
  real_T c3_crSym;
  real_T c3_kSym;
  real_T c3_KSym;
  real_T c3_RSym;
  real_T c3_betaSym;
  real_T c3_nargin = 4.0;
  real_T c3_nargout = 1.0;
  real_T c3_delta;
  real_T c3_B;
  real_T c3_y;
  real_T c3_b_y;
  real_T c3_b;
  real_T c3_c_y;
  real_T c3_b_b;
  real_T c3_d_y;
  real_T c3_a;
  real_T c3_c_b;
  real_T c3_e_y;
  real_T c3_b_a;
  real_T c3_f_y;
  real_T c3_c_a;
  real_T c3_g_y;
  real_T c3_d_a;
  real_T c3_d_b;
  real_T c3_h_y;
  real_T c3_e_a;
  real_T c3_i_y;
  real_T c3_e_b;
  real_T c3_j_y;
  real_T c3_f_a;
  real_T c3_k_y;
  real_T c3_g_a;
  real_T c3_l_y;
  real_T c3_b_B;
  real_T c3_m_y;
  real_T c3_n_y;
  real_T c3_o_y;
  real_T c3_x;
  real_T c3_b_x;
  real_T c3_h_a;
  real_T c3_f_b;
  real_T c3_p_y;
  real_T c3_i_a;
  real_T c3_q_y;
  real_T c3_j_a;
  real_T c3_r_y;
  real_T c3_c_x;
  real_T c3_d_x;
  real_T c3_k_a;
  real_T c3_g_b;
  real_T c3_s_y;
  real_T c3_h_b;
  real_T c3_t_y;
  real_T c3_l_a;
  real_T c3_u_y;
  real_T c3_m_a;
  real_T c3_v_y;
  real_T c3_n_a;
  real_T c3_i_b;
  real_T c3_w_y;
  real_T c3_o_a;
  real_T c3_x_y;
  real_T c3_e_x;
  real_T c3_f_x;
  real_T c3_p_a;
  real_T c3_j_b;
  real_T c3_y_y;
  real_T c3_k_b;
  real_T c3_ab_y;
  real_T c3_q_a;
  real_T c3_l_b;
  real_T c3_bb_y;
  real_T c3_r_a;
  real_T c3_m_b;
  real_T c3_cb_y;
  real_T c3_s_a;
  real_T c3_db_y;
  real_T c3_n_b;
  real_T c3_eb_y;
  real_T c3_t_a;
  real_T c3_fb_y;
  real_T c3_u_a;
  real_T c3_gb_y;
  real_T c3_v_a;
  real_T c3_o_b;
  real_T c3_hb_y;
  real_T c3_c_B;
  real_T c3_ib_y;
  real_T c3_jb_y;
  real_T c3_kb_y;
  real_T c3_g_x;
  real_T c3_h_x;
  real_T c3_w_a;
  real_T c3_p_b;
  real_T c3_lb_y;
  real_T c3_q_b;
  real_T c3_mb_y;
  real_T c3_x_a;
  real_T c3_nb_y;
  real_T c3_y_a;
  real_T c3_r_b;
  real_T c3_ob_y;
  real_T c3_ab_a;
  real_T c3_pb_y;
  real_T c3_bb_a;
  real_T c3_qb_y;
  real_T c3_i_x;
  real_T c3_j_x;
  real_T c3_cb_a;
  real_T c3_s_b;
  real_T c3_rb_y;
  real_T c3_t_b;
  real_T c3_sb_y;
  real_T c3_db_a;
  real_T c3_tb_y;
  real_T c3_eb_a;
  real_T c3_u_b;
  real_T c3_ub_y;
  real_T c3_fb_a;
  real_T c3_vb_y;
  real_T c3_gb_a;
  real_T c3_wb_y;
  real_T c3_d_B;
  real_T c3_xb_y;
  real_T c3_yb_y;
  real_T c3_ac_y;
  real_T c3_k_x;
  real_T c3_l_x;
  real_T c3_hb_a;
  real_T c3_v_b;
  real_T c3_bc_y;
  real_T c3_w_b;
  real_T c3_cc_y;
  real_T c3_ib_a;
  real_T c3_dc_y;
  real_T c3_jb_a;
  real_T c3_x_b;
  real_T c3_ec_y;
  real_T c3_kb_a;
  real_T c3_y_b;
  real_T c3_fc_y;
  real_T c3_lb_a;
  real_T c3_gc_y;
  real_T c3_mb_a;
  real_T c3_hc_y;
  real_T c3_ab_b;
  real_T c3_ic_y;
  real_T c3_nb_a;
  real_T c3_jc_y;
  real_T c3_ob_a;
  real_T c3_kc_y;
  real_T c3_pb_a;
  real_T c3_bb_b;
  real_T c3_lc_y;
  real_T c3_qb_a;
  real_T c3_mc_y;
  real_T c3_rb_a;
  real_T c3_cb_b;
  real_T c3_nc_y;
  real_T c3_sb_a;
  real_T c3_oc_y;
  real_T c3_e_B;
  real_T c3_pc_y;
  real_T c3_qc_y;
  real_T c3_rc_y;
  real_T c3_m_x;
  real_T c3_n_x;
  real_T c3_tb_a;
  real_T c3_db_b;
  real_T c3_sc_y;
  real_T c3_eb_b;
  real_T c3_tc_y;
  real_T c3_ub_a;
  real_T c3_uc_y;
  real_T c3_vb_a;
  real_T c3_fb_b;
  real_T c3_vc_y;
  real_T c3_wb_a;
  real_T c3_gb_b;
  real_T c3_wc_y;
  real_T c3_xb_a;
  real_T c3_hb_b;
  real_T c3_xc_y;
  real_T c3_yb_a;
  real_T c3_yc_y;
  real_T c3_ib_b;
  real_T c3_ad_y;
  real_T c3_ac_a;
  real_T c3_bd_y;
  real_T c3_bc_a;
  real_T c3_jb_b;
  real_T c3_cd_y;
  real_T c3_cc_a;
  real_T c3_dd_y;
  real_T c3_dc_a;
  real_T c3_ed_y;
  real_T c3_f_B;
  real_T c3_fd_y;
  real_T c3_gd_y;
  real_T c3_hd_y;
  real_T c3_o_x;
  real_T c3_p_x;
  real_T c3_ec_a;
  real_T c3_kb_b;
  real_T c3_id_y;
  real_T c3_q_x;
  real_T c3_r_x;
  real_T c3_fc_a;
  real_T c3_lb_b;
  real_T c3_jd_y;
  real_T c3_mb_b;
  real_T c3_kd_y;
  real_T c3_gc_a;
  real_T c3_ld_y;
  real_T c3_hc_a;
  real_T c3_md_y;
  real_T c3_ic_a;
  real_T c3_nb_b;
  real_T c3_nd_y;
  real_T c3_jc_a;
  real_T c3_od_y;
  real_T c3_kc_a;
  real_T c3_pd_y;
  real_T c3_g_B;
  real_T c3_qd_y;
  real_T c3_rd_y;
  real_T c3_sd_y;
  real_T c3_s_x;
  real_T c3_t_x;
  real_T c3_lc_a;
  real_T c3_ob_b;
  real_T c3_td_y;
  real_T c3_u_x;
  real_T c3_v_x;
  real_T c3_mc_a;
  real_T c3_pb_b;
  real_T c3_ud_y;
  real_T c3_qb_b;
  real_T c3_vd_y;
  real_T c3_nc_a;
  real_T c3_wd_y;
  real_T c3_oc_a;
  real_T c3_xd_y;
  real_T c3_pc_a;
  real_T c3_yd_y;
  real_T c3_qc_a;
  real_T c3_ae_y;
  real_T c3_h_B;
  real_T c3_be_y;
  real_T c3_ce_y;
  real_T c3_de_y;
  real_T c3_w_x;
  real_T c3_x_x;
  real_T c3_rc_a;
  real_T c3_rb_b;
  real_T c3_ee_y;
  real_T c3_i_B;
  real_T c3_fe_y;
  real_T c3_ge_y;
  real_T c3_he_y;
  real_T c3_y_x;
  real_T c3_ab_x;
  real_T c3_sc_a;
  real_T c3_sb_b;
  real_T c3_ie_y;
  real_T c3_bb_x;
  real_T c3_cb_x;
  real_T c3_tc_a;
  real_T c3_tb_b;
  real_T c3_je_y;
  real_T c3_ub_b;
  real_T c3_ke_y;
  real_T c3_uc_a;
  real_T c3_le_y;
  real_T c3_vc_a;
  real_T c3_vb_b;
  real_T c3_me_y;
  real_T c3_wc_a;
  real_T c3_ne_y;
  real_T c3_xc_a;
  real_T c3_wb_b;
  real_T c3_oe_y;
  real_T c3_db_x;
  real_T c3_eb_x;
  real_T c3_yc_a;
  real_T c3_xb_b;
  real_T c3_pe_y;
  real_T c3_yb_b;
  real_T c3_qe_y;
  real_T c3_ad_a;
  real_T c3_re_y;
  real_T c3_bd_a;
  real_T c3_se_y;
  real_T c3_cd_a;
  real_T c3_ac_b;
  real_T c3_te_y;
  real_T c3_j_B;
  real_T c3_ue_y;
  real_T c3_ve_y;
  real_T c3_we_y;
  real_T c3_fb_x;
  real_T c3_gb_x;
  real_T c3_dd_a;
  real_T c3_bc_b;
  real_T c3_xe_y;
  real_T c3_hb_x;
  real_T c3_ib_x;
  real_T c3_ed_a;
  real_T c3_cc_b;
  real_T c3_ye_y;
  real_T c3_dc_b;
  real_T c3_af_y;
  real_T c3_fd_a;
  real_T c3_ec_b;
  real_T c3_bf_y;
  real_T c3_gd_a;
  real_T c3_cf_y;
  real_T c3_hd_a;
  real_T c3_df_y;
  real_T c3_id_a;
  real_T c3_ef_y;
  real_T c3_jb_x;
  real_T c3_kb_x;
  real_T c3_jd_a;
  real_T c3_fc_b;
  real_T c3_ff_y;
  real_T c3_gc_b;
  real_T c3_gf_y;
  real_T c3_kd_a;
  real_T c3_hc_b;
  real_T c3_hf_y;
  real_T c3_ld_a;
  real_T c3_if_y;
  real_T c3_md_a;
  real_T c3_ic_b;
  real_T c3_jf_y;
  real_T c3_nd_a;
  real_T c3_kf_y;
  real_T c3_od_a;
  real_T c3_lf_y;
  real_T c3_pd_a;
  real_T c3_jc_b;
  real_T c3_mf_y;
  real_T c3_qd_a;
  real_T c3_nf_y;
  real_T c3_rd_a;
  real_T c3_kc_b;
  real_T c3_of_y;
  real_T c3_A;
  real_T c3_k_B;
  real_T c3_lb_x;
  real_T c3_pf_y;
  real_T c3_mb_x;
  real_T c3_qf_y;
  real_T c3_rf_y;
  real_T c3_nb_x;
  real_T c3_ob_x;
  real_T c3_sd_a;
  real_T c3_lc_b;
  real_T c3_sf_y;
  real_T c3_td_a;
  real_T c3_tf_y;
  real_T c3_ud_a;
  real_T c3_uf_y;
  real_T c3_vd_a;
  real_T c3_mc_b;
  real_T c3_vf_y;
  real_T c3_b_A;
  real_T c3_l_B;
  real_T c3_pb_x;
  real_T c3_wf_y;
  real_T c3_qb_x;
  real_T c3_xf_y;
  real_T c3_yf_y;
  real_T c3_rb_x;
  real_T c3_sb_x;
  real_T c3_wd_a;
  real_T c3_nc_b;
  real_T c3_ag_y;
  real_T c3_oc_b;
  real_T c3_bg_y;
  real_T c3_pc_b;
  real_T c3_cg_y;
  real_T c3_xd_a;
  real_T c3_qc_b;
  real_T c3_dg_y;
  real_T c3_yd_a;
  real_T c3_eg_y;
  real_T c3_c_A;
  real_T c3_m_B;
  real_T c3_tb_x;
  real_T c3_fg_y;
  real_T c3_ub_x;
  real_T c3_gg_y;
  real_T c3_n_B;
  real_T c3_hg_y;
  real_T c3_ig_y;
  real_T c3_rc_b;
  real_T c3_jg_y;
  real_T c3_sc_b;
  real_T c3_kg_y;
  real_T c3_ae_a;
  real_T c3_tc_b;
  real_T c3_lg_y;
  real_T c3_be_a;
  real_T c3_mg_y;
  real_T c3_ce_a;
  real_T c3_ng_y;
  real_T c3_de_a;
  real_T c3_uc_b;
  real_T c3_og_y;
  real_T c3_ee_a;
  real_T c3_pg_y;
  real_T c3_vc_b;
  real_T c3_qg_y;
  real_T c3_fe_a;
  real_T c3_rg_y;
  real_T c3_ge_a;
  real_T c3_sg_y;
  real_T c3_o_B;
  real_T c3_tg_y;
  real_T c3_ug_y;
  real_T c3_vg_y;
  real_T c3_vb_x;
  real_T c3_wb_x;
  real_T c3_he_a;
  real_T c3_wc_b;
  real_T c3_wg_y;
  real_T c3_ie_a;
  real_T c3_xg_y;
  real_T c3_je_a;
  real_T c3_yg_y;
  real_T c3_xb_x;
  real_T c3_yb_x;
  real_T c3_ke_a;
  real_T c3_xc_b;
  real_T c3_ah_y;
  real_T c3_yc_b;
  real_T c3_bh_y;
  real_T c3_le_a;
  real_T c3_ch_y;
  real_T c3_me_a;
  real_T c3_dh_y;
  real_T c3_ne_a;
  real_T c3_ad_b;
  real_T c3_eh_y;
  real_T c3_oe_a;
  real_T c3_fh_y;
  real_T c3_ac_x;
  real_T c3_bc_x;
  real_T c3_pe_a;
  real_T c3_bd_b;
  real_T c3_gh_y;
  real_T c3_cd_b;
  real_T c3_hh_y;
  real_T c3_qe_a;
  real_T c3_dd_b;
  real_T c3_ih_y;
  real_T c3_re_a;
  real_T c3_ed_b;
  real_T c3_jh_y;
  real_T c3_se_a;
  real_T c3_kh_y;
  real_T c3_fd_b;
  real_T c3_lh_y;
  real_T c3_te_a;
  real_T c3_mh_y;
  real_T c3_ue_a;
  real_T c3_nh_y;
  real_T c3_ve_a;
  real_T c3_gd_b;
  real_T c3_oh_y;
  real_T c3_p_B;
  real_T c3_ph_y;
  real_T c3_qh_y;
  real_T c3_rh_y;
  real_T c3_cc_x;
  real_T c3_dc_x;
  real_T c3_we_a;
  real_T c3_hd_b;
  real_T c3_sh_y;
  real_T c3_id_b;
  real_T c3_th_y;
  real_T c3_xe_a;
  real_T c3_uh_y;
  real_T c3_ye_a;
  real_T c3_jd_b;
  real_T c3_vh_y;
  real_T c3_af_a;
  real_T c3_wh_y;
  real_T c3_bf_a;
  real_T c3_xh_y;
  real_T c3_ec_x;
  real_T c3_fc_x;
  real_T c3_cf_a;
  real_T c3_kd_b;
  real_T c3_yh_y;
  real_T c3_ld_b;
  real_T c3_ai_y;
  real_T c3_df_a;
  real_T c3_bi_y;
  real_T c3_ef_a;
  real_T c3_md_b;
  real_T c3_ci_y;
  real_T c3_ff_a;
  real_T c3_di_y;
  real_T c3_gf_a;
  real_T c3_ei_y;
  real_T c3_q_B;
  real_T c3_fi_y;
  real_T c3_gi_y;
  real_T c3_hi_y;
  real_T c3_gc_x;
  real_T c3_hc_x;
  real_T c3_hf_a;
  real_T c3_nd_b;
  real_T c3_ii_y;
  real_T c3_od_b;
  real_T c3_ji_y;
  real_T c3_if_a;
  real_T c3_ki_y;
  real_T c3_jf_a;
  real_T c3_pd_b;
  real_T c3_li_y;
  real_T c3_kf_a;
  real_T c3_qd_b;
  real_T c3_mi_y;
  real_T c3_lf_a;
  real_T c3_ni_y;
  real_T c3_mf_a;
  real_T c3_oi_y;
  real_T c3_rd_b;
  real_T c3_pi_y;
  real_T c3_nf_a;
  real_T c3_qi_y;
  real_T c3_of_a;
  real_T c3_ri_y;
  real_T c3_pf_a;
  real_T c3_sd_b;
  real_T c3_si_y;
  real_T c3_qf_a;
  real_T c3_ti_y;
  real_T c3_rf_a;
  real_T c3_td_b;
  real_T c3_ui_y;
  real_T c3_sf_a;
  real_T c3_vi_y;
  real_T c3_r_B;
  real_T c3_wi_y;
  real_T c3_xi_y;
  real_T c3_yi_y;
  real_T c3_ic_x;
  real_T c3_jc_x;
  real_T c3_tf_a;
  real_T c3_ud_b;
  real_T c3_aj_y;
  real_T c3_vd_b;
  real_T c3_bj_y;
  real_T c3_uf_a;
  real_T c3_cj_y;
  real_T c3_vf_a;
  real_T c3_wd_b;
  real_T c3_dj_y;
  real_T c3_wf_a;
  real_T c3_xd_b;
  real_T c3_ej_y;
  real_T c3_xf_a;
  real_T c3_yd_b;
  real_T c3_fj_y;
  real_T c3_yf_a;
  real_T c3_gj_y;
  real_T c3_ae_b;
  real_T c3_hj_y;
  real_T c3_ag_a;
  real_T c3_ij_y;
  real_T c3_bg_a;
  real_T c3_be_b;
  real_T c3_jj_y;
  real_T c3_cg_a;
  real_T c3_kj_y;
  real_T c3_dg_a;
  real_T c3_lj_y;
  real_T c3_s_B;
  real_T c3_mj_y;
  real_T c3_nj_y;
  real_T c3_oj_y;
  real_T c3_kc_x;
  real_T c3_lc_x;
  real_T c3_eg_a;
  real_T c3_ce_b;
  real_T c3_pj_y;
  real_T c3_mc_x;
  real_T c3_nc_x;
  real_T c3_fg_a;
  real_T c3_de_b;
  real_T c3_qj_y;
  real_T c3_ee_b;
  real_T c3_rj_y;
  real_T c3_gg_a;
  real_T c3_sj_y;
  real_T c3_hg_a;
  real_T c3_tj_y;
  real_T c3_ig_a;
  real_T c3_fe_b;
  real_T c3_uj_y;
  real_T c3_jg_a;
  real_T c3_vj_y;
  real_T c3_kg_a;
  real_T c3_wj_y;
  real_T c3_t_B;
  real_T c3_xj_y;
  real_T c3_yj_y;
  real_T c3_ak_y;
  real_T c3_oc_x;
  real_T c3_pc_x;
  real_T c3_lg_a;
  real_T c3_ge_b;
  real_T c3_bk_y;
  real_T c3_qc_x;
  real_T c3_rc_x;
  real_T c3_mg_a;
  real_T c3_he_b;
  real_T c3_ck_y;
  real_T c3_ie_b;
  real_T c3_dk_y;
  real_T c3_ng_a;
  real_T c3_ek_y;
  real_T c3_og_a;
  real_T c3_fk_y;
  real_T c3_pg_a;
  real_T c3_gk_y;
  real_T c3_qg_a;
  real_T c3_hk_y;
  real_T c3_u_B;
  real_T c3_ik_y;
  real_T c3_jk_y;
  real_T c3_kk_y;
  real_T c3_sc_x;
  real_T c3_tc_x;
  real_T c3_rg_a;
  real_T c3_je_b;
  real_T c3_lk_y;
  real_T c3_v_B;
  real_T c3_mk_y;
  real_T c3_nk_y;
  real_T c3_ok_y;
  real_T c3_uc_x;
  real_T c3_vc_x;
  real_T c3_sg_a;
  real_T c3_ke_b;
  real_T c3_pk_y;
  real_T c3_wc_x;
  real_T c3_xc_x;
  real_T c3_tg_a;
  real_T c3_le_b;
  real_T c3_qk_y;
  real_T c3_me_b;
  real_T c3_rk_y;
  real_T c3_ug_a;
  real_T c3_sk_y;
  real_T c3_vg_a;
  real_T c3_ne_b;
  real_T c3_tk_y;
  real_T c3_wg_a;
  real_T c3_uk_y;
  real_T c3_xg_a;
  real_T c3_oe_b;
  real_T c3_vk_y;
  real_T c3_yc_x;
  real_T c3_ad_x;
  real_T c3_yg_a;
  real_T c3_pe_b;
  real_T c3_wk_y;
  real_T c3_qe_b;
  real_T c3_xk_y;
  real_T c3_ah_a;
  real_T c3_yk_y;
  real_T c3_bh_a;
  real_T c3_al_y;
  real_T c3_ch_a;
  real_T c3_re_b;
  real_T c3_bl_y;
  real_T c3_w_B;
  real_T c3_cl_y;
  real_T c3_dl_y;
  real_T c3_el_y;
  real_T c3_bd_x;
  real_T c3_cd_x;
  real_T c3_dh_a;
  real_T c3_se_b;
  real_T c3_fl_y;
  real_T c3_dd_x;
  real_T c3_ed_x;
  real_T c3_eh_a;
  real_T c3_te_b;
  real_T c3_gl_y;
  real_T c3_ue_b;
  real_T c3_hl_y;
  real_T c3_fh_a;
  real_T c3_ve_b;
  real_T c3_il_y;
  real_T c3_gh_a;
  real_T c3_jl_y;
  real_T c3_hh_a;
  real_T c3_kl_y;
  real_T c3_ih_a;
  real_T c3_ll_y;
  real_T c3_fd_x;
  real_T c3_gd_x;
  real_T c3_jh_a;
  real_T c3_we_b;
  real_T c3_ml_y;
  real_T c3_xe_b;
  real_T c3_nl_y;
  real_T c3_kh_a;
  real_T c3_ye_b;
  real_T c3_ol_y;
  real_T c3_lh_a;
  real_T c3_pl_y;
  real_T c3_mh_a;
  real_T c3_af_b;
  real_T c3_ql_y;
  real_T c3_nh_a;
  real_T c3_rl_y;
  real_T c3_oh_a;
  real_T c3_sl_y;
  real_T c3_ph_a;
  real_T c3_bf_b;
  real_T c3_tl_y;
  real_T c3_qh_a;
  real_T c3_ul_y;
  real_T c3_rh_a;
  real_T c3_cf_b;
  real_T c3_vl_y;
  real_T c3_d_A;
  real_T c3_x_B;
  real_T c3_hd_x;
  real_T c3_wl_y;
  real_T c3_id_x;
  real_T c3_xl_y;
  real_T c3_yl_y;
  real_T c3_jd_x;
  real_T c3_kd_x;
  real_T c3_sh_a;
  real_T c3_df_b;
  real_T c3_am_y;
  real_T c3_th_a;
  real_T c3_bm_y;
  real_T c3_uh_a;
  real_T c3_cm_y;
  real_T c3_vh_a;
  real_T c3_ef_b;
  real_T c3_dm_y;
  real_T c3_e_A;
  real_T c3_y_B;
  real_T c3_ld_x;
  real_T c3_em_y;
  real_T c3_md_x;
  real_T c3_fm_y;
  real_T c3_gm_y;
  real_T c3_nd_x;
  real_T c3_od_x;
  real_T c3_wh_a;
  real_T c3_ff_b;
  real_T c3_hm_y;
  real_T c3_gf_b;
  real_T c3_im_y;
  real_T c3_hf_b;
  real_T c3_jm_y;
  real_T c3_xh_a;
  real_T c3_if_b;
  real_T c3_km_y;
  real_T c3_yh_a;
  real_T c3_lm_y;
  real_T c3_f_A;
  real_T c3_ab_B;
  real_T c3_pd_x;
  real_T c3_mm_y;
  real_T c3_qd_x;
  real_T c3_nm_y;
  real_T *c3_b_dds;
  real_T *c3_b_ds;
  real_T *c3_b_beta;
  real_T *c3_b_rho;
  real_T *c3_b_delta;
  c3_b_dds = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c3_b_ds = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c3_b_beta = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c3_b_delta = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c3_b_rho = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
  c3_hoistedGlobal = *c3_b_rho;
  c3_b_hoistedGlobal = *c3_b_beta;
  c3_c_hoistedGlobal = *c3_b_ds;
  c3_d_hoistedGlobal = *c3_b_dds;
  c3_rho = c3_hoistedGlobal;
  c3_beta = c3_b_hoistedGlobal;
  c3_ds = c3_c_hoistedGlobal;
  c3_dds = c3_d_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 17U, 17U, c3_debug_family_names,
    c3_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_aSym, 0U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_bSym, 1U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_mSym, 2U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_ISym, 3U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_cfSym, 4U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_crSym, 5U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_kSym, 6U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_KSym, 7U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_RSym, 8U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_betaSym, 9U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_nargin, 10U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_nargout, 11U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_rho, 12U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_beta, 13U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_ds, 14U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_dds, 15U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_delta, 16U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 3);
  c3_aSym = 1.421;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 4);
  c3_bSym = 1.029;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 5);
  c3_mSym = 1480.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 6);
  c3_ISym = 1950.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 7);
  c3_cfSym = -150000.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 8);
  c3_crSym = -150000.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 10);
  c3_kSym = -4.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 11);
  c3_KSym = 0.4;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 13);
  if (CV_EML_IF(0, 1, 0, c3_rho == 0.0)) {
    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 14);
    c3_delta = 0.0;
  } else {
    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 15);
    if (CV_EML_IF(0, 1, 1, c3_rho <= 0.0)) {
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 16);
      c3_B = c3_rho;
      c3_y = c3_B;
      c3_b_y = c3_y;
      c3_RSym = 1.0 / c3_b_y;
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 17);
      c3_betaSym = c3_beta;
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 20);
      c3_b = c3_mpower(chartInstance, c3_ds);
      c3_c_y = 1.2168000000000002E+6 * c3_b;
      c3_b_b = c3_mpower(chartInstance, c3_RSym);
      c3_d_y = 7.605E+6 * c3_b_b;
      c3_a = c3_d_y;
      c3_c_b = c3_mpower(chartInstance, c3_betaSym);
      c3_e_y = c3_a * c3_c_b;
      c3_b_a = c3_e_y;
      c3_f_y = c3_b_a * 16.0;
      c3_c_a = c3_mpower(chartInstance, c3_RSym);
      c3_g_y = c3_c_a * 2.019241;
      c3_d_a = c3_g_y;
      c3_d_b = c3_mpower(chartInstance, c3_dds);
      c3_h_y = c3_d_a * c3_d_b;
      c3_e_a = c3_h_y;
      c3_i_y = c3_e_a * 2.1904E+6;
      c3_e_b = c3_mpower(chartInstance, c3_RSym);
      c3_j_y = 2.0 * c3_e_b;
      c3_f_a = c3_j_y;
      c3_k_y = c3_f_a * 1.058841;
      c3_g_a = c3_k_y;
      c3_l_y = c3_g_a * 2.25E+10;
      c3_b_B = c3_RSym;
      c3_m_y = c3_b_B;
      c3_n_y = c3_m_y;
      c3_o_y = 1.029 / c3_n_y;
      c3_x = c3_betaSym - c3_o_y;
      c3_b_x = c3_x;
      c3_b_x = muDoubleScalarAtan(c3_b_x);
      c3_h_a = c3_l_y;
      c3_f_b = c3_mpower(chartInstance, c3_b_x);
      c3_p_y = c3_h_a * c3_f_b;
      c3_i_a = c3_mpower(chartInstance, c3_RSym);
      c3_q_y = c3_i_a * 2.019241;
      c3_j_a = c3_q_y;
      c3_r_y = c3_j_a * 2.25E+10;
      c3_c_x = c3_betaSym;
      c3_d_x = c3_c_x;
      c3_d_x = muDoubleScalarCos(c3_d_x);
      c3_k_a = c3_r_y;
      c3_g_b = c3_mpower(chartInstance, c3_d_x);
      c3_s_y = c3_k_a * c3_g_b;
      c3_h_b = c3_mpower(chartInstance, c3_RSym);
      c3_t_y = 2.0 * c3_h_b;
      c3_l_a = c3_t_y;
      c3_u_y = c3_l_a * 2.019241;
      c3_m_a = c3_u_y;
      c3_v_y = c3_m_a * -150000.0;
      c3_n_a = c3_v_y;
      c3_i_b = c3_dds;
      c3_w_y = c3_n_a * c3_i_b;
      c3_o_a = c3_w_y;
      c3_x_y = c3_o_a * 1480.0;
      c3_e_x = c3_betaSym;
      c3_f_x = c3_e_x;
      c3_f_x = muDoubleScalarCos(c3_f_x);
      c3_p_a = c3_x_y;
      c3_j_b = c3_f_x;
      c3_y_y = c3_p_a * c3_j_b;
      c3_k_b = c3_RSym;
      c3_ab_y = 6.084E+6 * c3_k_b;
      c3_q_a = c3_ab_y;
      c3_l_b = c3_betaSym;
      c3_bb_y = c3_q_a * c3_l_b;
      c3_r_a = c3_bb_y;
      c3_m_b = c3_ds;
      c3_cb_y = c3_r_a * c3_m_b;
      c3_s_a = c3_cb_y;
      c3_db_y = c3_s_a * -4.0;
      c3_n_b = c3_RSym;
      c3_eb_y = 3120.0 * c3_n_b;
      c3_t_a = c3_eb_y;
      c3_fb_y = c3_t_a * 1.029;
      c3_u_a = c3_fb_y;
      c3_gb_y = c3_u_a * -150000.0;
      c3_v_a = c3_gb_y;
      c3_o_b = c3_ds;
      c3_hb_y = c3_v_a * c3_o_b;
      c3_c_B = c3_RSym;
      c3_ib_y = c3_c_B;
      c3_jb_y = c3_ib_y;
      c3_kb_y = 1.029 / c3_jb_y;
      c3_g_x = c3_betaSym - c3_kb_y;
      c3_h_x = c3_g_x;
      c3_h_x = muDoubleScalarAtan(c3_h_x);
      c3_w_a = c3_hb_y;
      c3_p_b = c3_h_x;
      c3_lb_y = c3_w_a * c3_p_b;
      c3_q_b = c3_mpower(chartInstance, c3_RSym);
      c3_mb_y = 3900.0 * c3_q_b;
      c3_x_a = c3_mb_y;
      c3_nb_y = c3_x_a * 1.421;
      c3_y_a = c3_nb_y;
      c3_r_b = c3_mpower(chartInstance, c3_betaSym);
      c3_ob_y = c3_y_a * c3_r_b;
      c3_ab_a = c3_ob_y;
      c3_pb_y = c3_ab_a * -150000.0;
      c3_bb_a = c3_pb_y;
      c3_qb_y = c3_bb_a * -4.0;
      c3_i_x = c3_betaSym;
      c3_j_x = c3_i_x;
      c3_j_x = muDoubleScalarCos(c3_j_x);
      c3_cb_a = c3_qb_y;
      c3_s_b = c3_j_x;
      c3_rb_y = c3_cb_a * c3_s_b;
      c3_t_b = c3_mpower(chartInstance, c3_RSym);
      c3_sb_y = 7800.0 * c3_t_b;
      c3_db_a = c3_sb_y;
      c3_tb_y = c3_db_a * 1.029;
      c3_eb_a = c3_tb_y;
      c3_u_b = c3_betaSym;
      c3_ub_y = c3_eb_a * c3_u_b;
      c3_fb_a = c3_ub_y;
      c3_vb_y = c3_fb_a * -150000.0;
      c3_gb_a = c3_vb_y;
      c3_wb_y = c3_gb_a * -4.0;
      c3_d_B = c3_RSym;
      c3_xb_y = c3_d_B;
      c3_yb_y = c3_xb_y;
      c3_ac_y = 1.029 / c3_yb_y;
      c3_k_x = c3_betaSym - c3_ac_y;
      c3_l_x = c3_k_x;
      c3_l_x = muDoubleScalarAtan(c3_l_x);
      c3_hb_a = c3_wb_y;
      c3_v_b = c3_l_x;
      c3_bc_y = c3_hb_a * c3_v_b;
      c3_w_b = c3_mpower(chartInstance, c3_RSym);
      c3_cc_y = 3900.0 * c3_w_b;
      c3_ib_a = c3_cc_y;
      c3_dc_y = c3_ib_a * 1.421;
      c3_jb_a = c3_dc_y;
      c3_x_b = c3_mpower(chartInstance, c3_betaSym);
      c3_ec_y = c3_jb_a * c3_x_b;
      c3_kb_a = c3_ec_y;
      c3_y_b = c3_dds;
      c3_fc_y = c3_kb_a * c3_y_b;
      c3_lb_a = c3_fc_y;
      c3_gc_y = c3_lb_a * -4.0;
      c3_mb_a = c3_gc_y;
      c3_hc_y = c3_mb_a * 1480.0;
      c3_ab_b = c3_mpower(chartInstance, c3_RSym);
      c3_ic_y = 2.0 * c3_ab_b;
      c3_nb_a = c3_ic_y;
      c3_jc_y = c3_nb_a * 1.421;
      c3_ob_a = c3_jc_y;
      c3_kc_y = c3_ob_a * 1.029;
      c3_pb_a = c3_kc_y;
      c3_bb_b = c3_betaSym;
      c3_lc_y = c3_pb_a * c3_bb_b;
      c3_qb_a = c3_lc_y;
      c3_mc_y = c3_qb_a * -150000.0;
      c3_rb_a = c3_mc_y;
      c3_cb_b = c3_dds;
      c3_nc_y = c3_rb_a * c3_cb_b;
      c3_sb_a = c3_nc_y;
      c3_oc_y = c3_sb_a * 1480.0;
      c3_e_B = c3_RSym;
      c3_pc_y = c3_e_B;
      c3_qc_y = c3_pc_y;
      c3_rc_y = 1.029 / c3_qc_y;
      c3_m_x = c3_betaSym - c3_rc_y;
      c3_n_x = c3_m_x;
      c3_n_x = muDoubleScalarAtan(c3_n_x);
      c3_tb_a = c3_oc_y;
      c3_db_b = c3_n_x;
      c3_sc_y = c3_tb_a * c3_db_b;
      c3_eb_b = c3_RSym;
      c3_tc_y = 1560.0 * c3_eb_b;
      c3_ub_a = c3_tc_y;
      c3_uc_y = c3_ub_a * 1.421;
      c3_vb_a = c3_uc_y;
      c3_fb_b = c3_betaSym;
      c3_vc_y = c3_vb_a * c3_fb_b;
      c3_wb_a = c3_vc_y;
      c3_gb_b = c3_dds;
      c3_wc_y = c3_wb_a * c3_gb_b;
      c3_xb_a = c3_wc_y;
      c3_hb_b = c3_ds;
      c3_xc_y = c3_xb_a * c3_hb_b;
      c3_yb_a = c3_xc_y;
      c3_yc_y = c3_yb_a * 1480.0;
      c3_ib_b = c3_mpower(chartInstance, c3_RSym);
      c3_ad_y = 3900.0 * c3_ib_b;
      c3_ac_a = c3_ad_y;
      c3_bd_y = c3_ac_a * 1.421;
      c3_bc_a = c3_bd_y;
      c3_jb_b = c3_betaSym;
      c3_cd_y = c3_bc_a * c3_jb_b;
      c3_cc_a = c3_cd_y;
      c3_dd_y = c3_cc_a * -150000.0;
      c3_dc_a = c3_dd_y;
      c3_ed_y = c3_dc_a * -4.0;
      c3_f_B = c3_RSym;
      c3_fd_y = c3_f_B;
      c3_gd_y = c3_fd_y;
      c3_hd_y = 1.421 / c3_gd_y;
      c3_o_x = c3_betaSym + c3_hd_y;
      c3_p_x = c3_o_x;
      c3_p_x = muDoubleScalarAtan(c3_p_x);
      c3_ec_a = c3_ed_y;
      c3_kb_b = c3_p_x;
      c3_id_y = c3_ec_a * c3_kb_b;
      c3_q_x = c3_betaSym;
      c3_r_x = c3_q_x;
      c3_r_x = muDoubleScalarCos(c3_r_x);
      c3_fc_a = c3_id_y;
      c3_lb_b = c3_r_x;
      c3_jd_y = c3_fc_a * c3_lb_b;
      c3_mb_b = c3_mpower(chartInstance, c3_RSym);
      c3_kd_y = 2.0 * c3_mb_b;
      c3_gc_a = c3_kd_y;
      c3_ld_y = c3_gc_a * 1.421;
      c3_hc_a = c3_ld_y;
      c3_md_y = c3_hc_a * 1.029;
      c3_ic_a = c3_md_y;
      c3_nb_b = c3_betaSym;
      c3_nd_y = c3_ic_a * c3_nb_b;
      c3_jc_a = c3_nd_y;
      c3_od_y = c3_jc_a * -150000.0;
      c3_kc_a = c3_od_y;
      c3_pd_y = c3_kc_a * -150000.0;
      c3_g_B = c3_RSym;
      c3_qd_y = c3_g_B;
      c3_rd_y = c3_qd_y;
      c3_sd_y = 1.029 / c3_rd_y;
      c3_s_x = c3_betaSym - c3_sd_y;
      c3_t_x = c3_s_x;
      c3_t_x = muDoubleScalarAtan(c3_t_x);
      c3_lc_a = c3_pd_y;
      c3_ob_b = c3_t_x;
      c3_td_y = c3_lc_a * c3_ob_b;
      c3_u_x = c3_betaSym;
      c3_v_x = c3_u_x;
      c3_v_x = muDoubleScalarCos(c3_v_x);
      c3_mc_a = c3_td_y;
      c3_pb_b = c3_v_x;
      c3_ud_y = c3_mc_a * c3_pb_b;
      c3_qb_b = c3_mpower(chartInstance, c3_RSym);
      c3_vd_y = 2.0 * c3_qb_b;
      c3_nc_a = c3_vd_y;
      c3_wd_y = c3_nc_a * 1.421;
      c3_oc_a = c3_wd_y;
      c3_xd_y = c3_oc_a * 1.029;
      c3_pc_a = c3_xd_y;
      c3_yd_y = c3_pc_a * -150000.0;
      c3_qc_a = c3_yd_y;
      c3_ae_y = c3_qc_a * -150000.0;
      c3_h_B = c3_RSym;
      c3_be_y = c3_h_B;
      c3_ce_y = c3_be_y;
      c3_de_y = 1.421 / c3_ce_y;
      c3_w_x = c3_betaSym + c3_de_y;
      c3_x_x = c3_w_x;
      c3_x_x = muDoubleScalarAtan(c3_x_x);
      c3_rc_a = c3_ae_y;
      c3_rb_b = c3_x_x;
      c3_ee_y = c3_rc_a * c3_rb_b;
      c3_i_B = c3_RSym;
      c3_fe_y = c3_i_B;
      c3_ge_y = c3_fe_y;
      c3_he_y = 1.029 / c3_ge_y;
      c3_y_x = c3_betaSym - c3_he_y;
      c3_ab_x = c3_y_x;
      c3_ab_x = muDoubleScalarAtan(c3_ab_x);
      c3_sc_a = c3_ee_y;
      c3_sb_b = c3_ab_x;
      c3_ie_y = c3_sc_a * c3_sb_b;
      c3_bb_x = c3_betaSym;
      c3_cb_x = c3_bb_x;
      c3_cb_x = muDoubleScalarCos(c3_cb_x);
      c3_tc_a = c3_ie_y;
      c3_tb_b = c3_cb_x;
      c3_je_y = c3_tc_a * c3_tb_b;
      c3_ub_b = c3_RSym;
      c3_ke_y = 1560.0 * c3_ub_b;
      c3_uc_a = c3_ke_y;
      c3_le_y = c3_uc_a * 1.421;
      c3_vc_a = c3_le_y;
      c3_vb_b = c3_betaSym;
      c3_me_y = c3_vc_a * c3_vb_b;
      c3_wc_a = c3_me_y;
      c3_ne_y = c3_wc_a * -150000.0;
      c3_xc_a = c3_ne_y;
      c3_wb_b = c3_ds;
      c3_oe_y = c3_xc_a * c3_wb_b;
      c3_db_x = c3_betaSym;
      c3_eb_x = c3_db_x;
      c3_eb_x = muDoubleScalarCos(c3_eb_x);
      c3_yc_a = c3_oe_y;
      c3_xb_b = c3_eb_x;
      c3_pe_y = c3_yc_a * c3_xb_b;
      c3_yb_b = c3_RSym;
      c3_qe_y = 1560.0 * c3_yb_b;
      c3_ad_a = c3_qe_y;
      c3_re_y = c3_ad_a * 1.421;
      c3_bd_a = c3_re_y;
      c3_se_y = c3_bd_a * -150000.0;
      c3_cd_a = c3_se_y;
      c3_ac_b = c3_ds;
      c3_te_y = c3_cd_a * c3_ac_b;
      c3_j_B = c3_RSym;
      c3_ue_y = c3_j_B;
      c3_ve_y = c3_ue_y;
      c3_we_y = 1.421 / c3_ve_y;
      c3_fb_x = c3_betaSym + c3_we_y;
      c3_gb_x = c3_fb_x;
      c3_gb_x = muDoubleScalarAtan(c3_gb_x);
      c3_dd_a = c3_te_y;
      c3_bc_b = c3_gb_x;
      c3_xe_y = c3_dd_a * c3_bc_b;
      c3_hb_x = c3_betaSym;
      c3_ib_x = c3_hb_x;
      c3_ib_x = muDoubleScalarCos(c3_ib_x);
      c3_ed_a = c3_xe_y;
      c3_cc_b = c3_ib_x;
      c3_ye_y = c3_ed_a * c3_cc_b;
      c3_dc_b = c3_RSym;
      c3_af_y = 1950.0 * c3_dc_b;
      c3_fd_a = c3_af_y;
      c3_ec_b = c3_mpower(chartInstance, c3_betaSym);
      c3_bf_y = c3_fd_a * c3_ec_b;
      c3_gd_a = c3_bf_y;
      c3_cf_y = c3_gd_a * -4.0;
      c3_hd_a = c3_RSym;
      c3_df_y = c3_hd_a * 1.421;
      c3_id_a = c3_df_y;
      c3_ef_y = c3_id_a * -150000.0;
      c3_jb_x = c3_betaSym;
      c3_kb_x = c3_jb_x;
      c3_kb_x = muDoubleScalarCos(c3_kb_x);
      c3_jd_a = c3_ef_y;
      c3_fc_b = c3_kb_x;
      c3_ff_y = c3_jd_a * c3_fc_b;
      c3_gc_b = c3_betaSym;
      c3_gf_y = 780.0 * c3_gc_b;
      c3_kd_a = c3_gf_y;
      c3_hc_b = c3_ds;
      c3_hf_y = c3_kd_a * c3_hc_b;
      c3_ld_a = c3_RSym;
      c3_if_y = c3_ld_a * 1.421;
      c3_md_a = c3_if_y;
      c3_ic_b = c3_dds;
      c3_jf_y = c3_md_a * c3_ic_b;
      c3_nd_a = c3_jf_y;
      c3_kf_y = c3_nd_a * 1480.0;
      c3_od_a = c3_RSym;
      c3_lf_y = c3_od_a * 1.029;
      c3_pd_a = c3_lf_y;
      c3_jc_b = c3_betaSym;
      c3_mf_y = c3_pd_a * c3_jc_b;
      c3_qd_a = c3_mf_y;
      c3_nf_y = c3_qd_a * -150000.0;
      c3_rd_a = c3_RSym;
      c3_kc_b = c3_betaSym;
      c3_of_y = c3_rd_a * c3_kc_b;
      c3_A = c3_bSym - c3_of_y;
      c3_k_B = c3_RSym;
      c3_lb_x = c3_A;
      c3_pf_y = c3_k_B;
      c3_mb_x = c3_lb_x;
      c3_qf_y = c3_pf_y;
      c3_rf_y = c3_mb_x / c3_qf_y;
      c3_nb_x = c3_rf_y;
      c3_ob_x = c3_nb_x;
      c3_ob_x = muDoubleScalarAtan(c3_ob_x);
      c3_sd_a = c3_nf_y;
      c3_lc_b = c3_ob_x;
      c3_sf_y = c3_sd_a * c3_lc_b;
      c3_td_a = c3_RSym;
      c3_tf_y = c3_td_a * 1.029;
      c3_ud_a = c3_tf_y;
      c3_uf_y = c3_ud_a * -150000.0;
      c3_vd_a = c3_RSym;
      c3_mc_b = c3_betaSym;
      c3_vf_y = c3_vd_a * c3_mc_b;
      c3_b_A = c3_bSym - c3_vf_y;
      c3_l_B = c3_RSym;
      c3_pb_x = c3_b_A;
      c3_wf_y = c3_l_B;
      c3_qb_x = c3_pb_x;
      c3_xf_y = c3_wf_y;
      c3_yf_y = c3_qb_x / c3_xf_y;
      c3_rb_x = c3_yf_y;
      c3_sb_x = c3_rb_x;
      c3_sb_x = muDoubleScalarAtan(c3_sb_x);
      c3_wd_a = c3_uf_y;
      c3_nc_b = c3_sb_x;
      c3_ag_y = c3_wd_a * c3_nc_b;
      c3_oc_b = c3_ds;
      c3_bg_y = 780.0 * c3_oc_b;
      c3_pc_b = c3_RSym;
      c3_cg_y = 1950.0 * c3_pc_b;
      c3_xd_a = c3_cg_y;
      c3_qc_b = c3_betaSym;
      c3_dg_y = c3_xd_a * c3_qc_b;
      c3_yd_a = c3_dg_y;
      c3_eg_y = c3_yd_a * -4.0;
      c3_c_A = ((((c3_b_mpower(chartInstance, ((((((((((((((((c3_c_y + c3_f_y) +
        c3_i_y) + c3_p_y) + c3_s_y) - c3_y_y) - c3_db_y) + c3_lb_y) - c3_rb_y) -
        c3_bc_y) + c3_hc_y) - c3_sc_y) - c3_yc_y) + c3_jd_y) + c3_ud_y) -
        c3_je_y) + c3_pe_y) - c3_ye_y) + c3_cf_y) - c3_ff_y) - c3_hf_y) +
                c3_kf_y) + c3_sf_y;
      c3_m_B = (c3_ag_y - c3_bg_y) + c3_eg_y;
      c3_tb_x = c3_c_A;
      c3_fg_y = c3_m_B;
      c3_ub_x = c3_tb_x;
      c3_gg_y = c3_fg_y;
      c3_delta = c3_ub_x / c3_gg_y;
    } else {
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 22);
      c3_n_B = c3_rho;
      c3_hg_y = c3_n_B;
      c3_ig_y = c3_hg_y;
      c3_RSym = 1.0 / c3_ig_y;
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 23);
      c3_betaSym = c3_beta;
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 25);
      c3_rc_b = c3_mpower(chartInstance, c3_ds);
      c3_jg_y = 1.2168000000000002E+6 * c3_rc_b;
      c3_sc_b = c3_mpower(chartInstance, c3_RSym);
      c3_kg_y = 7.605E+6 * c3_sc_b;
      c3_ae_a = c3_kg_y;
      c3_tc_b = c3_mpower(chartInstance, c3_betaSym);
      c3_lg_y = c3_ae_a * c3_tc_b;
      c3_be_a = c3_lg_y;
      c3_mg_y = c3_be_a * 16.0;
      c3_ce_a = c3_mpower(chartInstance, c3_RSym);
      c3_ng_y = c3_ce_a * 2.019241;
      c3_de_a = c3_ng_y;
      c3_uc_b = c3_mpower(chartInstance, c3_dds);
      c3_og_y = c3_de_a * c3_uc_b;
      c3_ee_a = c3_og_y;
      c3_pg_y = c3_ee_a * 2.1904E+6;
      c3_vc_b = c3_mpower(chartInstance, c3_RSym);
      c3_qg_y = 2.0 * c3_vc_b;
      c3_fe_a = c3_qg_y;
      c3_rg_y = c3_fe_a * 1.058841;
      c3_ge_a = c3_rg_y;
      c3_sg_y = c3_ge_a * 2.25E+10;
      c3_o_B = c3_RSym;
      c3_tg_y = c3_o_B;
      c3_ug_y = c3_tg_y;
      c3_vg_y = 1.029 / c3_ug_y;
      c3_vb_x = c3_betaSym - c3_vg_y;
      c3_wb_x = c3_vb_x;
      c3_wb_x = muDoubleScalarAtan(c3_wb_x);
      c3_he_a = c3_sg_y;
      c3_wc_b = c3_mpower(chartInstance, c3_wb_x);
      c3_wg_y = c3_he_a * c3_wc_b;
      c3_ie_a = c3_mpower(chartInstance, c3_RSym);
      c3_xg_y = c3_ie_a * 2.019241;
      c3_je_a = c3_xg_y;
      c3_yg_y = c3_je_a * 2.25E+10;
      c3_xb_x = c3_betaSym;
      c3_yb_x = c3_xb_x;
      c3_yb_x = muDoubleScalarCos(c3_yb_x);
      c3_ke_a = c3_yg_y;
      c3_xc_b = c3_mpower(chartInstance, c3_yb_x);
      c3_ah_y = c3_ke_a * c3_xc_b;
      c3_yc_b = c3_mpower(chartInstance, c3_RSym);
      c3_bh_y = 2.0 * c3_yc_b;
      c3_le_a = c3_bh_y;
      c3_ch_y = c3_le_a * 2.019241;
      c3_me_a = c3_ch_y;
      c3_dh_y = c3_me_a * -150000.0;
      c3_ne_a = c3_dh_y;
      c3_ad_b = c3_dds;
      c3_eh_y = c3_ne_a * c3_ad_b;
      c3_oe_a = c3_eh_y;
      c3_fh_y = c3_oe_a * 1480.0;
      c3_ac_x = c3_betaSym;
      c3_bc_x = c3_ac_x;
      c3_bc_x = muDoubleScalarCos(c3_bc_x);
      c3_pe_a = c3_fh_y;
      c3_bd_b = c3_bc_x;
      c3_gh_y = c3_pe_a * c3_bd_b;
      c3_cd_b = c3_RSym;
      c3_hh_y = 6.084E+6 * c3_cd_b;
      c3_qe_a = c3_hh_y;
      c3_dd_b = c3_betaSym;
      c3_ih_y = c3_qe_a * c3_dd_b;
      c3_re_a = c3_ih_y;
      c3_ed_b = c3_ds;
      c3_jh_y = c3_re_a * c3_ed_b;
      c3_se_a = c3_jh_y;
      c3_kh_y = c3_se_a * -4.0;
      c3_fd_b = c3_RSym;
      c3_lh_y = 3120.0 * c3_fd_b;
      c3_te_a = c3_lh_y;
      c3_mh_y = c3_te_a * 1.029;
      c3_ue_a = c3_mh_y;
      c3_nh_y = c3_ue_a * -150000.0;
      c3_ve_a = c3_nh_y;
      c3_gd_b = c3_ds;
      c3_oh_y = c3_ve_a * c3_gd_b;
      c3_p_B = c3_RSym;
      c3_ph_y = c3_p_B;
      c3_qh_y = c3_ph_y;
      c3_rh_y = 1.029 / c3_qh_y;
      c3_cc_x = c3_betaSym - c3_rh_y;
      c3_dc_x = c3_cc_x;
      c3_dc_x = muDoubleScalarAtan(c3_dc_x);
      c3_we_a = c3_oh_y;
      c3_hd_b = c3_dc_x;
      c3_sh_y = c3_we_a * c3_hd_b;
      c3_id_b = c3_mpower(chartInstance, c3_RSym);
      c3_th_y = 3900.0 * c3_id_b;
      c3_xe_a = c3_th_y;
      c3_uh_y = c3_xe_a * 1.421;
      c3_ye_a = c3_uh_y;
      c3_jd_b = c3_mpower(chartInstance, c3_betaSym);
      c3_vh_y = c3_ye_a * c3_jd_b;
      c3_af_a = c3_vh_y;
      c3_wh_y = c3_af_a * -150000.0;
      c3_bf_a = c3_wh_y;
      c3_xh_y = c3_bf_a * -4.0;
      c3_ec_x = c3_betaSym;
      c3_fc_x = c3_ec_x;
      c3_fc_x = muDoubleScalarCos(c3_fc_x);
      c3_cf_a = c3_xh_y;
      c3_kd_b = c3_fc_x;
      c3_yh_y = c3_cf_a * c3_kd_b;
      c3_ld_b = c3_mpower(chartInstance, c3_RSym);
      c3_ai_y = 7800.0 * c3_ld_b;
      c3_df_a = c3_ai_y;
      c3_bi_y = c3_df_a * 1.029;
      c3_ef_a = c3_bi_y;
      c3_md_b = c3_betaSym;
      c3_ci_y = c3_ef_a * c3_md_b;
      c3_ff_a = c3_ci_y;
      c3_di_y = c3_ff_a * -150000.0;
      c3_gf_a = c3_di_y;
      c3_ei_y = c3_gf_a * -4.0;
      c3_q_B = c3_RSym;
      c3_fi_y = c3_q_B;
      c3_gi_y = c3_fi_y;
      c3_hi_y = 1.029 / c3_gi_y;
      c3_gc_x = c3_betaSym - c3_hi_y;
      c3_hc_x = c3_gc_x;
      c3_hc_x = muDoubleScalarAtan(c3_hc_x);
      c3_hf_a = c3_ei_y;
      c3_nd_b = c3_hc_x;
      c3_ii_y = c3_hf_a * c3_nd_b;
      c3_od_b = c3_mpower(chartInstance, c3_RSym);
      c3_ji_y = 3900.0 * c3_od_b;
      c3_if_a = c3_ji_y;
      c3_ki_y = c3_if_a * 1.421;
      c3_jf_a = c3_ki_y;
      c3_pd_b = c3_mpower(chartInstance, c3_betaSym);
      c3_li_y = c3_jf_a * c3_pd_b;
      c3_kf_a = c3_li_y;
      c3_qd_b = c3_dds;
      c3_mi_y = c3_kf_a * c3_qd_b;
      c3_lf_a = c3_mi_y;
      c3_ni_y = c3_lf_a * -4.0;
      c3_mf_a = c3_ni_y;
      c3_oi_y = c3_mf_a * 1480.0;
      c3_rd_b = c3_mpower(chartInstance, c3_RSym);
      c3_pi_y = 2.0 * c3_rd_b;
      c3_nf_a = c3_pi_y;
      c3_qi_y = c3_nf_a * 1.421;
      c3_of_a = c3_qi_y;
      c3_ri_y = c3_of_a * 1.029;
      c3_pf_a = c3_ri_y;
      c3_sd_b = c3_betaSym;
      c3_si_y = c3_pf_a * c3_sd_b;
      c3_qf_a = c3_si_y;
      c3_ti_y = c3_qf_a * -150000.0;
      c3_rf_a = c3_ti_y;
      c3_td_b = c3_dds;
      c3_ui_y = c3_rf_a * c3_td_b;
      c3_sf_a = c3_ui_y;
      c3_vi_y = c3_sf_a * 1480.0;
      c3_r_B = c3_RSym;
      c3_wi_y = c3_r_B;
      c3_xi_y = c3_wi_y;
      c3_yi_y = 1.029 / c3_xi_y;
      c3_ic_x = c3_betaSym - c3_yi_y;
      c3_jc_x = c3_ic_x;
      c3_jc_x = muDoubleScalarAtan(c3_jc_x);
      c3_tf_a = c3_vi_y;
      c3_ud_b = c3_jc_x;
      c3_aj_y = c3_tf_a * c3_ud_b;
      c3_vd_b = c3_RSym;
      c3_bj_y = 1560.0 * c3_vd_b;
      c3_uf_a = c3_bj_y;
      c3_cj_y = c3_uf_a * 1.421;
      c3_vf_a = c3_cj_y;
      c3_wd_b = c3_betaSym;
      c3_dj_y = c3_vf_a * c3_wd_b;
      c3_wf_a = c3_dj_y;
      c3_xd_b = c3_dds;
      c3_ej_y = c3_wf_a * c3_xd_b;
      c3_xf_a = c3_ej_y;
      c3_yd_b = c3_ds;
      c3_fj_y = c3_xf_a * c3_yd_b;
      c3_yf_a = c3_fj_y;
      c3_gj_y = c3_yf_a * 1480.0;
      c3_ae_b = c3_mpower(chartInstance, c3_RSym);
      c3_hj_y = 3900.0 * c3_ae_b;
      c3_ag_a = c3_hj_y;
      c3_ij_y = c3_ag_a * 1.421;
      c3_bg_a = c3_ij_y;
      c3_be_b = c3_betaSym;
      c3_jj_y = c3_bg_a * c3_be_b;
      c3_cg_a = c3_jj_y;
      c3_kj_y = c3_cg_a * -150000.0;
      c3_dg_a = c3_kj_y;
      c3_lj_y = c3_dg_a * -4.0;
      c3_s_B = c3_RSym;
      c3_mj_y = c3_s_B;
      c3_nj_y = c3_mj_y;
      c3_oj_y = 1.421 / c3_nj_y;
      c3_kc_x = c3_betaSym + c3_oj_y;
      c3_lc_x = c3_kc_x;
      c3_lc_x = muDoubleScalarAtan(c3_lc_x);
      c3_eg_a = c3_lj_y;
      c3_ce_b = c3_lc_x;
      c3_pj_y = c3_eg_a * c3_ce_b;
      c3_mc_x = c3_betaSym;
      c3_nc_x = c3_mc_x;
      c3_nc_x = muDoubleScalarCos(c3_nc_x);
      c3_fg_a = c3_pj_y;
      c3_de_b = c3_nc_x;
      c3_qj_y = c3_fg_a * c3_de_b;
      c3_ee_b = c3_mpower(chartInstance, c3_RSym);
      c3_rj_y = 2.0 * c3_ee_b;
      c3_gg_a = c3_rj_y;
      c3_sj_y = c3_gg_a * 1.421;
      c3_hg_a = c3_sj_y;
      c3_tj_y = c3_hg_a * 1.029;
      c3_ig_a = c3_tj_y;
      c3_fe_b = c3_betaSym;
      c3_uj_y = c3_ig_a * c3_fe_b;
      c3_jg_a = c3_uj_y;
      c3_vj_y = c3_jg_a * -150000.0;
      c3_kg_a = c3_vj_y;
      c3_wj_y = c3_kg_a * -150000.0;
      c3_t_B = c3_RSym;
      c3_xj_y = c3_t_B;
      c3_yj_y = c3_xj_y;
      c3_ak_y = 1.029 / c3_yj_y;
      c3_oc_x = c3_betaSym - c3_ak_y;
      c3_pc_x = c3_oc_x;
      c3_pc_x = muDoubleScalarAtan(c3_pc_x);
      c3_lg_a = c3_wj_y;
      c3_ge_b = c3_pc_x;
      c3_bk_y = c3_lg_a * c3_ge_b;
      c3_qc_x = c3_betaSym;
      c3_rc_x = c3_qc_x;
      c3_rc_x = muDoubleScalarCos(c3_rc_x);
      c3_mg_a = c3_bk_y;
      c3_he_b = c3_rc_x;
      c3_ck_y = c3_mg_a * c3_he_b;
      c3_ie_b = c3_mpower(chartInstance, c3_RSym);
      c3_dk_y = 2.0 * c3_ie_b;
      c3_ng_a = c3_dk_y;
      c3_ek_y = c3_ng_a * 1.421;
      c3_og_a = c3_ek_y;
      c3_fk_y = c3_og_a * 1.029;
      c3_pg_a = c3_fk_y;
      c3_gk_y = c3_pg_a * -150000.0;
      c3_qg_a = c3_gk_y;
      c3_hk_y = c3_qg_a * -150000.0;
      c3_u_B = c3_RSym;
      c3_ik_y = c3_u_B;
      c3_jk_y = c3_ik_y;
      c3_kk_y = 1.421 / c3_jk_y;
      c3_sc_x = c3_betaSym + c3_kk_y;
      c3_tc_x = c3_sc_x;
      c3_tc_x = muDoubleScalarAtan(c3_tc_x);
      c3_rg_a = c3_hk_y;
      c3_je_b = c3_tc_x;
      c3_lk_y = c3_rg_a * c3_je_b;
      c3_v_B = c3_RSym;
      c3_mk_y = c3_v_B;
      c3_nk_y = c3_mk_y;
      c3_ok_y = 1.029 / c3_nk_y;
      c3_uc_x = c3_betaSym - c3_ok_y;
      c3_vc_x = c3_uc_x;
      c3_vc_x = muDoubleScalarAtan(c3_vc_x);
      c3_sg_a = c3_lk_y;
      c3_ke_b = c3_vc_x;
      c3_pk_y = c3_sg_a * c3_ke_b;
      c3_wc_x = c3_betaSym;
      c3_xc_x = c3_wc_x;
      c3_xc_x = muDoubleScalarCos(c3_xc_x);
      c3_tg_a = c3_pk_y;
      c3_le_b = c3_xc_x;
      c3_qk_y = c3_tg_a * c3_le_b;
      c3_me_b = c3_RSym;
      c3_rk_y = 1560.0 * c3_me_b;
      c3_ug_a = c3_rk_y;
      c3_sk_y = c3_ug_a * 1.421;
      c3_vg_a = c3_sk_y;
      c3_ne_b = c3_betaSym;
      c3_tk_y = c3_vg_a * c3_ne_b;
      c3_wg_a = c3_tk_y;
      c3_uk_y = c3_wg_a * -150000.0;
      c3_xg_a = c3_uk_y;
      c3_oe_b = c3_ds;
      c3_vk_y = c3_xg_a * c3_oe_b;
      c3_yc_x = c3_betaSym;
      c3_ad_x = c3_yc_x;
      c3_ad_x = muDoubleScalarCos(c3_ad_x);
      c3_yg_a = c3_vk_y;
      c3_pe_b = c3_ad_x;
      c3_wk_y = c3_yg_a * c3_pe_b;
      c3_qe_b = c3_RSym;
      c3_xk_y = 1560.0 * c3_qe_b;
      c3_ah_a = c3_xk_y;
      c3_yk_y = c3_ah_a * 1.421;
      c3_bh_a = c3_yk_y;
      c3_al_y = c3_bh_a * -150000.0;
      c3_ch_a = c3_al_y;
      c3_re_b = c3_ds;
      c3_bl_y = c3_ch_a * c3_re_b;
      c3_w_B = c3_RSym;
      c3_cl_y = c3_w_B;
      c3_dl_y = c3_cl_y;
      c3_el_y = 1.421 / c3_dl_y;
      c3_bd_x = c3_betaSym + c3_el_y;
      c3_cd_x = c3_bd_x;
      c3_cd_x = muDoubleScalarAtan(c3_cd_x);
      c3_dh_a = c3_bl_y;
      c3_se_b = c3_cd_x;
      c3_fl_y = c3_dh_a * c3_se_b;
      c3_dd_x = c3_betaSym;
      c3_ed_x = c3_dd_x;
      c3_ed_x = muDoubleScalarCos(c3_ed_x);
      c3_eh_a = c3_fl_y;
      c3_te_b = c3_ed_x;
      c3_gl_y = c3_eh_a * c3_te_b;
      c3_ue_b = c3_RSym;
      c3_hl_y = 1950.0 * c3_ue_b;
      c3_fh_a = c3_hl_y;
      c3_ve_b = c3_mpower(chartInstance, c3_betaSym);
      c3_il_y = c3_fh_a * c3_ve_b;
      c3_gh_a = c3_il_y;
      c3_jl_y = c3_gh_a * -4.0;
      c3_hh_a = c3_RSym;
      c3_kl_y = c3_hh_a * 1.421;
      c3_ih_a = c3_kl_y;
      c3_ll_y = c3_ih_a * -150000.0;
      c3_fd_x = c3_betaSym;
      c3_gd_x = c3_fd_x;
      c3_gd_x = muDoubleScalarCos(c3_gd_x);
      c3_jh_a = c3_ll_y;
      c3_we_b = c3_gd_x;
      c3_ml_y = c3_jh_a * c3_we_b;
      c3_xe_b = c3_betaSym;
      c3_nl_y = 780.0 * c3_xe_b;
      c3_kh_a = c3_nl_y;
      c3_ye_b = c3_ds;
      c3_ol_y = c3_kh_a * c3_ye_b;
      c3_lh_a = c3_RSym;
      c3_pl_y = c3_lh_a * 1.421;
      c3_mh_a = c3_pl_y;
      c3_af_b = c3_dds;
      c3_ql_y = c3_mh_a * c3_af_b;
      c3_nh_a = c3_ql_y;
      c3_rl_y = c3_nh_a * 1480.0;
      c3_oh_a = c3_RSym;
      c3_sl_y = c3_oh_a * 1.029;
      c3_ph_a = c3_sl_y;
      c3_bf_b = c3_betaSym;
      c3_tl_y = c3_ph_a * c3_bf_b;
      c3_qh_a = c3_tl_y;
      c3_ul_y = c3_qh_a * -150000.0;
      c3_rh_a = c3_RSym;
      c3_cf_b = c3_betaSym;
      c3_vl_y = c3_rh_a * c3_cf_b;
      c3_d_A = c3_bSym - c3_vl_y;
      c3_x_B = c3_RSym;
      c3_hd_x = c3_d_A;
      c3_wl_y = c3_x_B;
      c3_id_x = c3_hd_x;
      c3_xl_y = c3_wl_y;
      c3_yl_y = c3_id_x / c3_xl_y;
      c3_jd_x = c3_yl_y;
      c3_kd_x = c3_jd_x;
      c3_kd_x = muDoubleScalarAtan(c3_kd_x);
      c3_sh_a = c3_ul_y;
      c3_df_b = c3_kd_x;
      c3_am_y = c3_sh_a * c3_df_b;
      c3_th_a = c3_RSym;
      c3_bm_y = c3_th_a * 1.029;
      c3_uh_a = c3_bm_y;
      c3_cm_y = c3_uh_a * -150000.0;
      c3_vh_a = c3_RSym;
      c3_ef_b = c3_betaSym;
      c3_dm_y = c3_vh_a * c3_ef_b;
      c3_e_A = c3_bSym - c3_dm_y;
      c3_y_B = c3_RSym;
      c3_ld_x = c3_e_A;
      c3_em_y = c3_y_B;
      c3_md_x = c3_ld_x;
      c3_fm_y = c3_em_y;
      c3_gm_y = c3_md_x / c3_fm_y;
      c3_nd_x = c3_gm_y;
      c3_od_x = c3_nd_x;
      c3_od_x = muDoubleScalarAtan(c3_od_x);
      c3_wh_a = c3_cm_y;
      c3_ff_b = c3_od_x;
      c3_hm_y = c3_wh_a * c3_ff_b;
      c3_gf_b = c3_ds;
      c3_im_y = 780.0 * c3_gf_b;
      c3_hf_b = c3_RSym;
      c3_jm_y = 1950.0 * c3_hf_b;
      c3_xh_a = c3_jm_y;
      c3_if_b = c3_betaSym;
      c3_km_y = c3_xh_a * c3_if_b;
      c3_yh_a = c3_km_y;
      c3_lm_y = c3_yh_a * -4.0;
      c3_f_A = -(((((c3_b_mpower(chartInstance, ((((((((((((((((c3_jg_y +
        c3_mg_y) + c3_pg_y) + c3_wg_y) + c3_ah_y) - c3_gh_y) - c3_kh_y) +
        c3_sh_y) - c3_yh_y) - c3_ii_y) + c3_oi_y) - c3_aj_y) - c3_gj_y) +
        c3_qj_y) + c3_ck_y) - c3_qk_y) + c3_wk_y) - c3_gl_y) - c3_jl_y) +
                    c3_ml_y) + c3_ol_y) - c3_rl_y) - c3_am_y);
      c3_ab_B = (c3_hm_y - c3_im_y) + c3_lm_y;
      c3_pd_x = c3_f_A;
      c3_mm_y = c3_ab_B;
      c3_qd_x = c3_pd_x;
      c3_nm_y = c3_mm_y;
      c3_delta = c3_qd_x / c3_nm_y;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, -25);
  _SFD_SYMBOL_SCOPE_POP();
  *c3_b_delta = c3_delta;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
}

static void initSimStructsc3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc3_laneKeepingArcSplinesFF2013a
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber)
{
}

static const mxArray *c3_sf_marshallOut(void *chartInstanceVoid, void *c3_inData)
{
  const mxArray *c3_mxArrayOutData = NULL;
  real_T c3_u;
  const mxArray *c3_y = NULL;
  SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c3_mxArrayOutData = NULL;
  c3_u = *(real_T *)c3_inData;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c3_mxArrayOutData, c3_y, FALSE);
  return c3_mxArrayOutData;
}

static real_T c3_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_delta, const char_T *c3_identifier)
{
  real_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_delta), &c3_thisId);
  sf_mex_destroy(&c3_delta);
  return c3_y;
}

static real_T c3_b_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  real_T c3_y;
  real_T c3_d0;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_d0, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d0;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData)
{
  const mxArray *c3_delta;
  const char_T *c3_identifier;
  emlrtMsgIdentifier c3_thisId;
  real_T c3_y;
  SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c3_delta = sf_mex_dup(c3_mxArrayInData);
  c3_identifier = c3_varName;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_delta), &c3_thisId);
  sf_mex_destroy(&c3_delta);
  *(real_T *)c3_outData = c3_y;
  sf_mex_destroy(&c3_mxArrayInData);
}

const mxArray
  *sf_c3_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c3_nameCaptureInfo;
  c3_ResolvedFunctionInfo c3_info[21];
  const mxArray *c3_m0 = NULL;
  int32_T c3_i0;
  c3_ResolvedFunctionInfo *c3_r0;
  c3_nameCaptureInfo = NULL;
  c3_nameCaptureInfo = NULL;
  c3_info_helper(c3_info);
  sf_mex_assign(&c3_m0, sf_mex_createstruct("nameCaptureInfo", 1, 21), FALSE);
  for (c3_i0 = 0; c3_i0 < 21; c3_i0++) {
    c3_r0 = &c3_info[c3_i0];
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c3_r0->context)), "context", "nameCaptureInfo",
                    c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c3_r0->name)), "name", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c3_r0->dominantType)), "dominantType",
                    "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c3_r0->resolved)), "resolved", "nameCaptureInfo",
                    c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->mFileTimeLo,
      7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->mFileTimeHi,
      7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo", c3_i0);
  }

  sf_mex_assign(&c3_nameCaptureInfo, c3_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c3_nameCaptureInfo);
  return c3_nameCaptureInfo;
}

static void c3_info_helper(c3_ResolvedFunctionInfo c3_info[21])
{
  c3_info[0].context = "";
  c3_info[0].name = "mrdivide";
  c3_info[0].dominantType = "double";
  c3_info[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c3_info[0].fileTimeLo = 1357947948U;
  c3_info[0].fileTimeHi = 0U;
  c3_info[0].mFileTimeLo = 1319726366U;
  c3_info[0].mFileTimeHi = 0U;
  c3_info[1].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c3_info[1].name = "rdivide";
  c3_info[1].dominantType = "double";
  c3_info[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c3_info[1].fileTimeLo = 1346506788U;
  c3_info[1].fileTimeHi = 0U;
  c3_info[1].mFileTimeLo = 0U;
  c3_info[1].mFileTimeHi = 0U;
  c3_info[2].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c3_info[2].name = "eml_scalexp_compatible";
  c3_info[2].dominantType = "double";
  c3_info[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  c3_info[2].fileTimeLo = 1286815196U;
  c3_info[2].fileTimeHi = 0U;
  c3_info[2].mFileTimeLo = 0U;
  c3_info[2].mFileTimeHi = 0U;
  c3_info[3].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c3_info[3].name = "eml_div";
  c3_info[3].dominantType = "double";
  c3_info[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c3_info[3].fileTimeLo = 1313344210U;
  c3_info[3].fileTimeHi = 0U;
  c3_info[3].mFileTimeLo = 0U;
  c3_info[3].mFileTimeHi = 0U;
  c3_info[4].context = "";
  c3_info[4].name = "mpower";
  c3_info[4].dominantType = "double";
  c3_info[4].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c3_info[4].fileTimeLo = 1286815242U;
  c3_info[4].fileTimeHi = 0U;
  c3_info[4].mFileTimeLo = 0U;
  c3_info[4].mFileTimeHi = 0U;
  c3_info[5].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c3_info[5].name = "power";
  c3_info[5].dominantType = "double";
  c3_info[5].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  c3_info[5].fileTimeLo = 1348188330U;
  c3_info[5].fileTimeHi = 0U;
  c3_info[5].mFileTimeLo = 0U;
  c3_info[5].mFileTimeHi = 0U;
  c3_info[6].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c3_info[6].name = "eml_scalar_eg";
  c3_info[6].dominantType = "double";
  c3_info[6].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c3_info[6].fileTimeLo = 1286815196U;
  c3_info[6].fileTimeHi = 0U;
  c3_info[6].mFileTimeLo = 0U;
  c3_info[6].mFileTimeHi = 0U;
  c3_info[7].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c3_info[7].name = "eml_scalexp_alloc";
  c3_info[7].dominantType = "double";
  c3_info[7].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c3_info[7].fileTimeLo = 1352421260U;
  c3_info[7].fileTimeHi = 0U;
  c3_info[7].mFileTimeLo = 0U;
  c3_info[7].mFileTimeHi = 0U;
  c3_info[8].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c3_info[8].name = "floor";
  c3_info[8].dominantType = "double";
  c3_info[8].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c3_info[8].fileTimeLo = 1343826780U;
  c3_info[8].fileTimeHi = 0U;
  c3_info[8].mFileTimeLo = 0U;
  c3_info[8].mFileTimeHi = 0U;
  c3_info[9].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c3_info[9].name = "eml_scalar_floor";
  c3_info[9].dominantType = "double";
  c3_info[9].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c3_info[9].fileTimeLo = 1286815126U;
  c3_info[9].fileTimeHi = 0U;
  c3_info[9].mFileTimeLo = 0U;
  c3_info[9].mFileTimeHi = 0U;
  c3_info[10].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c3_info[10].name = "eml_scalar_eg";
  c3_info[10].dominantType = "double";
  c3_info[10].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c3_info[10].fileTimeLo = 1286815196U;
  c3_info[10].fileTimeHi = 0U;
  c3_info[10].mFileTimeLo = 0U;
  c3_info[10].mFileTimeHi = 0U;
  c3_info[11].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c3_info[11].name = "mtimes";
  c3_info[11].dominantType = "double";
  c3_info[11].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[11].fileTimeLo = 1289516092U;
  c3_info[11].fileTimeHi = 0U;
  c3_info[11].mFileTimeLo = 0U;
  c3_info[11].mFileTimeHi = 0U;
  c3_info[12].context = "";
  c3_info[12].name = "mtimes";
  c3_info[12].dominantType = "double";
  c3_info[12].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[12].fileTimeLo = 1289516092U;
  c3_info[12].fileTimeHi = 0U;
  c3_info[12].mFileTimeLo = 0U;
  c3_info[12].mFileTimeHi = 0U;
  c3_info[13].context = "";
  c3_info[13].name = "atan";
  c3_info[13].dominantType = "double";
  c3_info[13].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan.m";
  c3_info[13].fileTimeLo = 1343826772U;
  c3_info[13].fileTimeHi = 0U;
  c3_info[13].mFileTimeLo = 0U;
  c3_info[13].mFileTimeHi = 0U;
  c3_info[14].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan.m";
  c3_info[14].name = "eml_scalar_atan";
  c3_info[14].dominantType = "double";
  c3_info[14].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_atan.m";
  c3_info[14].fileTimeLo = 1286815118U;
  c3_info[14].fileTimeHi = 0U;
  c3_info[14].mFileTimeLo = 0U;
  c3_info[14].mFileTimeHi = 0U;
  c3_info[15].context = "";
  c3_info[15].name = "cos";
  c3_info[15].dominantType = "double";
  c3_info[15].resolved = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[15].fileTimeLo = 1343826772U;
  c3_info[15].fileTimeHi = 0U;
  c3_info[15].mFileTimeLo = 0U;
  c3_info[15].mFileTimeHi = 0U;
  c3_info[16].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[16].name = "eml_scalar_cos";
  c3_info[16].dominantType = "double";
  c3_info[16].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c3_info[16].fileTimeLo = 1286815122U;
  c3_info[16].fileTimeHi = 0U;
  c3_info[16].mFileTimeLo = 0U;
  c3_info[16].mFileTimeHi = 0U;
  c3_info[17].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c3_info[17].name = "eml_error";
  c3_info[17].dominantType = "char";
  c3_info[17].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c3_info[17].fileTimeLo = 1343826758U;
  c3_info[17].fileTimeHi = 0U;
  c3_info[17].mFileTimeLo = 0U;
  c3_info[17].mFileTimeHi = 0U;
  c3_info[18].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c3_info[18].name = "sqrt";
  c3_info[18].dominantType = "double";
  c3_info[18].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c3_info[18].fileTimeLo = 1343826786U;
  c3_info[18].fileTimeHi = 0U;
  c3_info[18].mFileTimeLo = 0U;
  c3_info[18].mFileTimeHi = 0U;
  c3_info[19].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c3_info[19].name = "eml_error";
  c3_info[19].dominantType = "char";
  c3_info[19].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c3_info[19].fileTimeLo = 1343826758U;
  c3_info[19].fileTimeHi = 0U;
  c3_info[19].mFileTimeLo = 0U;
  c3_info[19].mFileTimeHi = 0U;
  c3_info[20].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c3_info[20].name = "eml_scalar_sqrt";
  c3_info[20].dominantType = "double";
  c3_info[20].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c3_info[20].fileTimeLo = 1286815138U;
  c3_info[20].fileTimeHi = 0U;
  c3_info[20].mFileTimeLo = 0U;
  c3_info[20].mFileTimeHi = 0U;
}

static real_T c3_mpower(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c3_a)
{
  real_T c3_b_a;
  real_T c3_c_a;
  real_T c3_ak;
  real_T c3_d_a;
  real_T c3_e_a;
  real_T c3_b;
  c3_b_a = c3_a;
  c3_c_a = c3_b_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_c_a;
  c3_d_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  c3_e_a = c3_d_a;
  c3_b = c3_d_a;
  return c3_e_a * c3_b;
}

static void c3_eml_scalar_eg(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
}

static real_T c3_b_mpower(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c3_a)
{
  real_T c3_c;
  real_T c3_b_a;
  real_T c3_c_a;
  real_T c3_ak;
  real_T c3_d_a;
  real_T c3_x;
  c3_b_a = c3_a;
  c3_c_a = c3_b_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_c_a;
  if (c3_ak < 0.0) {
    c3_eml_error(chartInstance);
  }

  c3_d_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  c3_x = c3_d_a;
  c3_c = c3_x;
  if (c3_c < 0.0) {
    c3_b_eml_error(chartInstance);
  }

  return muDoubleScalarSqrt(c3_c);
}

static void c3_eml_error(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c3_i1;
  static char_T c3_cv0[31] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'p', 'o', 'w', 'e', 'r', '_', 'd', 'o', 'm', 'a', 'i',
    'n', 'E', 'r', 'r', 'o', 'r' };

  char_T c3_u[31];
  const mxArray *c3_y = NULL;
  for (c3_i1 = 0; c3_i1 < 31; c3_i1++) {
    c3_u[c3_i1] = c3_cv0[c3_i1];
  }

  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", c3_u, 10, 0U, 1U, 0U, 2, 1, 31), FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 1U, 14,
    c3_y));
}

static void c3_b_eml_error(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c3_i2;
  static char_T c3_cv1[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  char_T c3_u[30];
  const mxArray *c3_y = NULL;
  int32_T c3_i3;
  static char_T c3_cv2[4] = { 's', 'q', 'r', 't' };

  char_T c3_b_u[4];
  const mxArray *c3_b_y = NULL;
  for (c3_i2 = 0; c3_i2 < 30; c3_i2++) {
    c3_u[c3_i2] = c3_cv1[c3_i2];
  }

  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", c3_u, 10, 0U, 1U, 0U, 2, 1, 30), FALSE);
  for (c3_i3 = 0; c3_i3 < 4; c3_i3++) {
    c3_b_u[c3_i3] = c3_cv2[c3_i3];
  }

  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", c3_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 2U, 14,
    c3_y, 14, c3_b_y));
}

static const mxArray *c3_b_sf_marshallOut(void *chartInstanceVoid, void
  *c3_inData)
{
  const mxArray *c3_mxArrayOutData = NULL;
  int32_T c3_u;
  const mxArray *c3_y = NULL;
  SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c3_mxArrayOutData = NULL;
  c3_u = *(int32_T *)c3_inData;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c3_mxArrayOutData, c3_y, FALSE);
  return c3_mxArrayOutData;
}

static int32_T c3_c_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  int32_T c3_y;
  int32_T c3_i4;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_i4, 1, 6, 0U, 0, 0U, 0);
  c3_y = c3_i4;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData)
{
  const mxArray *c3_b_sfEvent;
  const char_T *c3_identifier;
  emlrtMsgIdentifier c3_thisId;
  int32_T c3_y;
  SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c3_b_sfEvent = sf_mex_dup(c3_mxArrayInData);
  c3_identifier = c3_varName;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_sfEvent),
    &c3_thisId);
  sf_mex_destroy(&c3_b_sfEvent);
  *(int32_T *)c3_outData = c3_y;
  sf_mex_destroy(&c3_mxArrayInData);
}

static uint8_T c3_d_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_b_is_active_c3_laneKeepingArcSplinesFF2013a, const char_T *c3_identifier)
{
  uint8_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c3_b_is_active_c3_laneKeepingArcSplinesFF2013a), &c3_thisId);
  sf_mex_destroy(&c3_b_is_active_c3_laneKeepingArcSplinesFF2013a);
  return c3_y;
}

static uint8_T c3_e_emlrt_marshallIn
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const mxArray
   *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint8_T c3_y;
  uint8_T c3_u0;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_u0, 1, 3, 0U, 0, 0U, 0);
  c3_y = c3_u0;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void init_dsm_address_info
  (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c3_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(479475036U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2399525676U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(319741946U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2377612312U);
}

mxArray *sf_c3_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("dTaei0OrSIp1jneDOt2kbB");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c3_laneKeepingArcSplinesFF2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c3_laneKeepingArcSplinesFF2013a(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"delta\",},{M[8],M[0],T\"is_active_c3_laneKeepingArcSplinesFF2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c3_laneKeepingArcSplinesFF2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
    chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF2013aMachineNumber_,
           3,
           1,
           1,
           5,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"rho");
          _SFD_SET_DATA_PROPS(1,2,0,1,"delta");
          _SFD_SET_DATA_PROPS(2,1,1,0,"beta");
          _SFD_SET_DATA_PROPS(3,1,1,0,"ds");
          _SFD_SET_DATA_PROPS(4,1,1,0,"dds");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,2,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,4636);
        _SFD_CV_INIT_EML_IF(0,1,0,165,176,192,4636);
        _SFD_CV_INIT_EML_IF(0,1,1,192,207,2469,4636);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)c3_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);

        {
          real_T *c3_rho;
          real_T *c3_delta;
          real_T *c3_beta;
          real_T *c3_ds;
          real_T *c3_dds;
          c3_dds = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c3_ds = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c3_beta = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c3_delta = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c3_rho = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c3_rho);
          _SFD_SET_DATA_VALUE_PTR(1U, c3_delta);
          _SFD_SET_DATA_VALUE_PTR(2U, c3_beta);
          _SFD_SET_DATA_VALUE_PTR(3U, c3_ds);
          _SFD_SET_DATA_VALUE_PTR(4U, c3_dds);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "tgC2FZ6yoLgqShxLr5FcrC";
}

static void sf_opaque_initialize_c3_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
  initialize_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c3_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  enable_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c3_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  disable_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c3_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  sf_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c3_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c3_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c3_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c3_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c3_laneKeepingArcSplinesFF2013a(S);
}

static void sf_opaque_set_sim_state_c3_laneKeepingArcSplinesFF2013a(SimStruct* S,
  const mxArray *st)
{
  sf_internal_set_sim_state_c3_laneKeepingArcSplinesFF2013a(S, st);
}

static void sf_opaque_terminate_c3_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF2013a_optimization_info();
    }

    finalize_c3_laneKeepingArcSplinesFF2013a
      ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc3_laneKeepingArcSplinesFF2013a
    ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c3_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c3_laneKeepingArcSplinesFF2013a
      ((SFc3_laneKeepingArcSplinesFF2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c3_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      3);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,3,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,3,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,3);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,3,4);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,3,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 4; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,3);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(1493964067U));
  ssSetChecksum1(S,(1875664225U));
  ssSetChecksum2(S,(687547981U));
  ssSetChecksum3(S,(1668505421U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c3_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c3_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct *)utMalloc
    (sizeof(SFc3_laneKeepingArcSplinesFF2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc3_laneKeepingArcSplinesFF2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c3_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c3_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c3_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c3_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c3_laneKeepingArcSplinesFF2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c3_laneKeepingArcSplinesFF2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
