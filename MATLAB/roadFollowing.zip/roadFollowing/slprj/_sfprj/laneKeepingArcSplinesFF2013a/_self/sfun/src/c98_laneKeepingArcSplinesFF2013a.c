/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "c98_laneKeepingArcSplinesFF2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c98_debug_family_names[6] = { "nargin", "nargout", "delta",
  "VOmegax", "VOmegay", "alphafs" };

/* Function Declarations */
static void initialize_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initialize_params_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void enable_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void disable_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c98_update_debugger_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void set_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_st);
static void finalize_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void sf_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initSimStructsc98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void registerMessagesc98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c98_machineNumber, uint32_T
  c98_chartNumber);
static const mxArray *c98_sf_marshallOut(void *chartInstanceVoid, void
  *c98_inData);
static real_T c98_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_alphafs, const char_T *c98_identifier);
static real_T c98_b_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId);
static void c98_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c98_mxArrayInData, const char_T *c98_varName, void *c98_outData);
static const mxArray *c98_b_sf_marshallOut(void *chartInstanceVoid, void
  *c98_inData);
static int32_T c98_c_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId);
static void c98_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c98_mxArrayInData, const char_T *c98_varName, void *c98_outData);
static uint8_T c98_d_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_b_is_active_c98_laneKeepingArcSplinesFF2013a, const char_T
   *c98_identifier);
static uint8_T c98_e_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId);
static void init_dsm_address_info
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  chartInstance->c98_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c98_is_active_c98_laneKeepingArcSplinesFF2013a = 0U;
}

static void initialize_params_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void enable_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c98_update_debugger_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  const mxArray *c98_st;
  const mxArray *c98_y = NULL;
  real_T c98_hoistedGlobal;
  real_T c98_u;
  const mxArray *c98_b_y = NULL;
  uint8_T c98_b_hoistedGlobal;
  uint8_T c98_b_u;
  const mxArray *c98_c_y = NULL;
  real_T *c98_alphafs;
  c98_alphafs = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c98_st = NULL;
  c98_st = NULL;
  c98_y = NULL;
  sf_mex_assign(&c98_y, sf_mex_createcellarray(2), FALSE);
  c98_hoistedGlobal = *c98_alphafs;
  c98_u = c98_hoistedGlobal;
  c98_b_y = NULL;
  sf_mex_assign(&c98_b_y, sf_mex_create("y", &c98_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c98_y, 0, c98_b_y);
  c98_b_hoistedGlobal =
    chartInstance->c98_is_active_c98_laneKeepingArcSplinesFF2013a;
  c98_b_u = c98_b_hoistedGlobal;
  c98_c_y = NULL;
  sf_mex_assign(&c98_c_y, sf_mex_create("y", &c98_b_u, 3, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c98_y, 1, c98_c_y);
  sf_mex_assign(&c98_st, c98_y, FALSE);
  return c98_st;
}

static void set_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_st)
{
  const mxArray *c98_u;
  real_T *c98_alphafs;
  c98_alphafs = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c98_doneDoubleBufferReInit = TRUE;
  c98_u = sf_mex_dup(c98_st);
  *c98_alphafs = c98_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c98_u, 0)), "alphafs");
  chartInstance->c98_is_active_c98_laneKeepingArcSplinesFF2013a =
    c98_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c98_u, 1)),
    "is_active_c98_laneKeepingArcSplinesFF2013a");
  sf_mex_destroy(&c98_u);
  c98_update_debugger_state_c98_laneKeepingArcSplinesFF2013a(chartInstance);
  sf_mex_destroy(&c98_st);
}

static void finalize_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void sf_c98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T c98_hoistedGlobal;
  real_T c98_b_hoistedGlobal;
  real_T c98_c_hoistedGlobal;
  real_T c98_delta;
  real_T c98_VOmegax;
  real_T c98_VOmegay;
  uint32_T c98_debug_family_var_map[6];
  real_T c98_nargin = 3.0;
  real_T c98_nargout = 1.0;
  real_T c98_alphafs;
  real_T c98_A;
  real_T c98_B;
  real_T c98_x;
  real_T c98_y;
  real_T c98_b_x;
  real_T c98_b_y;
  real_T c98_c_y;
  real_T c98_c_x;
  real_T c98_d_x;
  real_T *c98_b_VOmegay;
  real_T *c98_b_VOmegax;
  real_T *c98_b_delta;
  real_T *c98_b_alphafs;
  c98_b_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c98_b_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c98_b_alphafs = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c98_b_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 9U, chartInstance->c98_sfEvent);
  _SFD_DATA_RANGE_CHECK(*c98_b_delta, 0U);
  _SFD_DATA_RANGE_CHECK(*c98_b_alphafs, 1U);
  _SFD_DATA_RANGE_CHECK(*c98_b_VOmegax, 2U);
  _SFD_DATA_RANGE_CHECK(*c98_b_VOmegay, 3U);
  chartInstance->c98_sfEvent = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 9U, chartInstance->c98_sfEvent);
  c98_hoistedGlobal = *c98_b_delta;
  c98_b_hoistedGlobal = *c98_b_VOmegax;
  c98_c_hoistedGlobal = *c98_b_VOmegay;
  c98_delta = c98_hoistedGlobal;
  c98_VOmegax = c98_b_hoistedGlobal;
  c98_VOmegay = c98_c_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 6U, 6U, c98_debug_family_names,
    c98_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c98_nargin, 0U, c98_sf_marshallOut,
    c98_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c98_nargout, 1U, c98_sf_marshallOut,
    c98_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c98_delta, 2U, c98_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c98_VOmegax, 3U, c98_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c98_VOmegay, 4U, c98_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c98_alphafs, 5U, c98_sf_marshallOut,
    c98_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c98_sfEvent, 4);
  c98_A = c98_VOmegax;
  c98_B = c98_VOmegay;
  c98_x = c98_A;
  c98_y = c98_B;
  c98_b_x = c98_x;
  c98_b_y = c98_y;
  c98_c_y = c98_b_x / c98_b_y;
  c98_c_x = c98_c_y;
  c98_d_x = c98_c_x;
  c98_d_x = muDoubleScalarAtan(c98_d_x);
  c98_alphafs = c98_delta - c98_d_x;
  _SFD_EML_CALL(0U, chartInstance->c98_sfEvent, -4);
  _SFD_SYMBOL_SCOPE_POP();
  *c98_b_alphafs = c98_alphafs;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 9U, chartInstance->c98_sfEvent);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_laneKeepingArcSplinesFF2013aMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void initSimStructsc98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc98_laneKeepingArcSplinesFF2013a
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c98_machineNumber, uint32_T
  c98_chartNumber)
{
}

static const mxArray *c98_sf_marshallOut(void *chartInstanceVoid, void
  *c98_inData)
{
  const mxArray *c98_mxArrayOutData = NULL;
  real_T c98_u;
  const mxArray *c98_y = NULL;
  SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c98_mxArrayOutData = NULL;
  c98_u = *(real_T *)c98_inData;
  c98_y = NULL;
  sf_mex_assign(&c98_y, sf_mex_create("y", &c98_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c98_mxArrayOutData, c98_y, FALSE);
  return c98_mxArrayOutData;
}

static real_T c98_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_alphafs, const char_T *c98_identifier)
{
  real_T c98_y;
  emlrtMsgIdentifier c98_thisId;
  c98_thisId.fIdentifier = c98_identifier;
  c98_thisId.fParent = NULL;
  c98_y = c98_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c98_alphafs),
    &c98_thisId);
  sf_mex_destroy(&c98_alphafs);
  return c98_y;
}

static real_T c98_b_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId)
{
  real_T c98_y;
  real_T c98_d0;
  sf_mex_import(c98_parentId, sf_mex_dup(c98_u), &c98_d0, 1, 0, 0U, 0, 0U, 0);
  c98_y = c98_d0;
  sf_mex_destroy(&c98_u);
  return c98_y;
}

static void c98_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c98_mxArrayInData, const char_T *c98_varName, void *c98_outData)
{
  const mxArray *c98_alphafs;
  const char_T *c98_identifier;
  emlrtMsgIdentifier c98_thisId;
  real_T c98_y;
  SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c98_alphafs = sf_mex_dup(c98_mxArrayInData);
  c98_identifier = c98_varName;
  c98_thisId.fIdentifier = c98_identifier;
  c98_thisId.fParent = NULL;
  c98_y = c98_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c98_alphafs),
    &c98_thisId);
  sf_mex_destroy(&c98_alphafs);
  *(real_T *)c98_outData = c98_y;
  sf_mex_destroy(&c98_mxArrayInData);
}

const mxArray
  *sf_c98_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c98_nameCaptureInfo;
  c98_ResolvedFunctionInfo c98_info[6];
  c98_ResolvedFunctionInfo (*c98_b_info)[6];
  const mxArray *c98_m0 = NULL;
  int32_T c98_i0;
  c98_ResolvedFunctionInfo *c98_r0;
  c98_nameCaptureInfo = NULL;
  c98_nameCaptureInfo = NULL;
  c98_b_info = (c98_ResolvedFunctionInfo (*)[6])c98_info;
  (*c98_b_info)[0].context = "";
  (*c98_b_info)[0].name = "mrdivide";
  (*c98_b_info)[0].dominantType = "double";
  (*c98_b_info)[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c98_b_info)[0].fileTimeLo = 1357947948U;
  (*c98_b_info)[0].fileTimeHi = 0U;
  (*c98_b_info)[0].mFileTimeLo = 1319726366U;
  (*c98_b_info)[0].mFileTimeHi = 0U;
  (*c98_b_info)[1].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c98_b_info)[1].name = "rdivide";
  (*c98_b_info)[1].dominantType = "double";
  (*c98_b_info)[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c98_b_info)[1].fileTimeLo = 1346506788U;
  (*c98_b_info)[1].fileTimeHi = 0U;
  (*c98_b_info)[1].mFileTimeLo = 0U;
  (*c98_b_info)[1].mFileTimeHi = 0U;
  (*c98_b_info)[2].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c98_b_info)[2].name = "eml_scalexp_compatible";
  (*c98_b_info)[2].dominantType = "double";
  (*c98_b_info)[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  (*c98_b_info)[2].fileTimeLo = 1286815196U;
  (*c98_b_info)[2].fileTimeHi = 0U;
  (*c98_b_info)[2].mFileTimeLo = 0U;
  (*c98_b_info)[2].mFileTimeHi = 0U;
  (*c98_b_info)[3].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c98_b_info)[3].name = "eml_div";
  (*c98_b_info)[3].dominantType = "double";
  (*c98_b_info)[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  (*c98_b_info)[3].fileTimeLo = 1313344210U;
  (*c98_b_info)[3].fileTimeHi = 0U;
  (*c98_b_info)[3].mFileTimeLo = 0U;
  (*c98_b_info)[3].mFileTimeHi = 0U;
  (*c98_b_info)[4].context = "";
  (*c98_b_info)[4].name = "atan";
  (*c98_b_info)[4].dominantType = "double";
  (*c98_b_info)[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan.m";
  (*c98_b_info)[4].fileTimeLo = 1343826772U;
  (*c98_b_info)[4].fileTimeHi = 0U;
  (*c98_b_info)[4].mFileTimeLo = 0U;
  (*c98_b_info)[4].mFileTimeHi = 0U;
  (*c98_b_info)[5].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/atan.m";
  (*c98_b_info)[5].name = "eml_scalar_atan";
  (*c98_b_info)[5].dominantType = "double";
  (*c98_b_info)[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_atan.m";
  (*c98_b_info)[5].fileTimeLo = 1286815118U;
  (*c98_b_info)[5].fileTimeHi = 0U;
  (*c98_b_info)[5].mFileTimeLo = 0U;
  (*c98_b_info)[5].mFileTimeHi = 0U;
  sf_mex_assign(&c98_m0, sf_mex_createstruct("nameCaptureInfo", 1, 6), FALSE);
  for (c98_i0 = 0; c98_i0 < 6; c98_i0++) {
    c98_r0 = &c98_info[c98_i0];
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo", c98_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c98_r0->context)), "context", "nameCaptureInfo",
                    c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo", c98_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c98_r0->name)), "name", "nameCaptureInfo", c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo",
      c98_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c98_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo", c98_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c98_r0->resolved)), "resolved",
                    "nameCaptureInfo", c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo", &c98_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo", &c98_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo",
      &c98_r0->mFileTimeLo, 7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo",
                    c98_i0);
    sf_mex_addfield(c98_m0, sf_mex_create("nameCaptureInfo",
      &c98_r0->mFileTimeHi, 7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo",
                    c98_i0);
  }

  sf_mex_assign(&c98_nameCaptureInfo, c98_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c98_nameCaptureInfo);
  return c98_nameCaptureInfo;
}

static const mxArray *c98_b_sf_marshallOut(void *chartInstanceVoid, void
  *c98_inData)
{
  const mxArray *c98_mxArrayOutData = NULL;
  int32_T c98_u;
  const mxArray *c98_y = NULL;
  SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c98_mxArrayOutData = NULL;
  c98_u = *(int32_T *)c98_inData;
  c98_y = NULL;
  sf_mex_assign(&c98_y, sf_mex_create("y", &c98_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c98_mxArrayOutData, c98_y, FALSE);
  return c98_mxArrayOutData;
}

static int32_T c98_c_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId)
{
  int32_T c98_y;
  int32_T c98_i1;
  sf_mex_import(c98_parentId, sf_mex_dup(c98_u), &c98_i1, 1, 6, 0U, 0, 0U, 0);
  c98_y = c98_i1;
  sf_mex_destroy(&c98_u);
  return c98_y;
}

static void c98_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c98_mxArrayInData, const char_T *c98_varName, void *c98_outData)
{
  const mxArray *c98_b_sfEvent;
  const char_T *c98_identifier;
  emlrtMsgIdentifier c98_thisId;
  int32_T c98_y;
  SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c98_b_sfEvent = sf_mex_dup(c98_mxArrayInData);
  c98_identifier = c98_varName;
  c98_thisId.fIdentifier = c98_identifier;
  c98_thisId.fParent = NULL;
  c98_y = c98_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c98_b_sfEvent),
    &c98_thisId);
  sf_mex_destroy(&c98_b_sfEvent);
  *(int32_T *)c98_outData = c98_y;
  sf_mex_destroy(&c98_mxArrayInData);
}

static uint8_T c98_d_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_b_is_active_c98_laneKeepingArcSplinesFF2013a, const char_T
   *c98_identifier)
{
  uint8_T c98_y;
  emlrtMsgIdentifier c98_thisId;
  c98_thisId.fIdentifier = c98_identifier;
  c98_thisId.fParent = NULL;
  c98_y = c98_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c98_b_is_active_c98_laneKeepingArcSplinesFF2013a), &c98_thisId);
  sf_mex_destroy(&c98_b_is_active_c98_laneKeepingArcSplinesFF2013a);
  return c98_y;
}

static uint8_T c98_e_emlrt_marshallIn
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c98_u, const emlrtMsgIdentifier *c98_parentId)
{
  uint8_T c98_y;
  uint8_T c98_u0;
  sf_mex_import(c98_parentId, sf_mex_dup(c98_u), &c98_u0, 1, 3, 0U, 0, 0U, 0);
  c98_y = c98_u0;
  sf_mex_destroy(&c98_u);
  return c98_y;
}

static void init_dsm_address_info
  (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c98_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1121202566U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3328966805U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1044102115U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4243183002U);
}

mxArray *sf_c98_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("q8xE5MPdWaoHMO4PZkYTHF");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c98_laneKeepingArcSplinesFF2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c98_laneKeepingArcSplinesFF2013a
  (void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"alphafs\",},{M[8],M[0],T\"is_active_c98_laneKeepingArcSplinesFF2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c98_laneKeepingArcSplinesFF2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
    chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF2013aMachineNumber_,
           98,
           1,
           1,
           4,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"delta");
          _SFD_SET_DATA_PROPS(1,2,0,1,"alphafs");
          _SFD_SET_DATA_PROPS(2,1,1,0,"VOmegax");
          _SFD_SET_DATA_PROPS(3,1,1,0,"VOmegay");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,97);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c98_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c98_sf_marshallOut,(MexInFcnForType)c98_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c98_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c98_sf_marshallOut,(MexInFcnForType)NULL);

        {
          real_T *c98_delta;
          real_T *c98_alphafs;
          real_T *c98_VOmegax;
          real_T *c98_VOmegay;
          c98_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c98_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c98_alphafs = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c98_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c98_delta);
          _SFD_SET_DATA_VALUE_PTR(1U, c98_alphafs);
          _SFD_SET_DATA_VALUE_PTR(2U, c98_VOmegax);
          _SFD_SET_DATA_VALUE_PTR(3U, c98_VOmegay);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "ZUYIpguPfIcuSu5GSxkMw";
}

static void sf_opaque_initialize_c98_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
  initialize_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c98_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  enable_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c98_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  disable_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c98_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  sf_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c98_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c98_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c98_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c98_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c98_laneKeepingArcSplinesFF2013a(S);
}

static void sf_opaque_set_sim_state_c98_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  sf_internal_set_sim_state_c98_laneKeepingArcSplinesFF2013a(S, st);
}

static void sf_opaque_terminate_c98_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF2013a_optimization_info();
    }

    finalize_c98_laneKeepingArcSplinesFF2013a
      ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc98_laneKeepingArcSplinesFF2013a
    ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c98_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c98_laneKeepingArcSplinesFF2013a
      ((SFc98_laneKeepingArcSplinesFF2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c98_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      98);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,98,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,98,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,98);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,98,3);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,98,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 3; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,98);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(683629952U));
  ssSetChecksum1(S,(640870062U));
  ssSetChecksum2(S,(23758442U));
  ssSetChecksum3(S,(3293553972U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c98_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c98_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct *)utMalloc
    (sizeof(SFc98_laneKeepingArcSplinesFF2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc98_laneKeepingArcSplinesFF2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c98_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c98_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c98_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c98_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c98_laneKeepingArcSplinesFF2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c98_laneKeepingArcSplinesFF2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
