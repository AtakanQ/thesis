/* Include files */

#include <stddef.h>
#include "blas.h"
#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "c100_laneKeepingArcSplinesFF2013a.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static const char * c100_debug_family_names[45] = { "R", "k", "S", "L", "m",
  "Iomega", "Cx", "Cy", "Bdelta", "Br", "C0", "Cr", "ea", "zeta", "df_D1_dalpha",
  "df_D2_dalpha", "df_D1_dlambda", "df_D2_dlambda", "sprime", "nargin",
  "nargout", "r", "Flf", "Flf_dot", "delta_dot", "r_dot", "dy", "delta", "alpha",
  "dx", "VOmegax", "VOmega", "IOmega", "df_D_lambda", "ddx", "df_D_dalpha",
  "ddy", "VOmegay", "mup", "Fz0", "VOmegaa", "Omega", "Fa", "lambda", "T" };

/* Function Declarations */
static void initialize_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initialize_params_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void enable_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void disable_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c100_update_debugger_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void set_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_st);
static void finalize_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void sf_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void c100_chartstep_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void initSimStructsc100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void registerMessagesc100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c100_machineNumber, uint32_T
  c100_chartNumber);
static const mxArray *c100_sf_marshallOut(void *chartInstanceVoid, void
  *c100_inData);
static real_T c100_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_T, const char_T *c100_identifier);
static real_T c100_b_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId);
static void c100_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c100_mxArrayInData, const char_T *c100_varName, void *c100_outData);
static void c100_info_helper(c100_ResolvedFunctionInfo c100_info[28]);
static real_T c100_abs(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_x);
static real_T c100_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a);
static void c100_eml_scalar_eg(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c100_b_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a);
static real_T c100_c_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a);
static void c100_eml_error(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static real_T c100_d_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a);
static real_T c100_sign(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_x);
static real_T c100_e_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a);
static void c100_b_eml_error(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance);
static const mxArray *c100_b_sf_marshallOut(void *chartInstanceVoid, void
  *c100_inData);
static int32_T c100_c_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId);
static void c100_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c100_mxArrayInData, const char_T *c100_varName, void *c100_outData);
static uint8_T c100_d_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_b_is_active_c100_laneKeepingArcSplinesFF2013a, const char_T
   *c100_identifier);
static uint8_T c100_e_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId);
static void c100_b_sign(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T *c100_x);
static void init_dsm_address_info
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  chartInstance->c100_sfEvent = CALL_EVENT;
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c100_is_active_c100_laneKeepingArcSplinesFF2013a = 0U;
}

static void initialize_params_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void enable_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c100_update_debugger_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  const mxArray *c100_st;
  const mxArray *c100_y = NULL;
  real_T c100_hoistedGlobal;
  real_T c100_u;
  const mxArray *c100_b_y = NULL;
  uint8_T c100_b_hoistedGlobal;
  uint8_T c100_b_u;
  const mxArray *c100_c_y = NULL;
  real_T *c100_T;
  c100_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c100_st = NULL;
  c100_st = NULL;
  c100_y = NULL;
  sf_mex_assign(&c100_y, sf_mex_createcellarray(2), FALSE);
  c100_hoistedGlobal = *c100_T;
  c100_u = c100_hoistedGlobal;
  c100_b_y = NULL;
  sf_mex_assign(&c100_b_y, sf_mex_create("y", &c100_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_setcell(c100_y, 0, c100_b_y);
  c100_b_hoistedGlobal =
    chartInstance->c100_is_active_c100_laneKeepingArcSplinesFF2013a;
  c100_b_u = c100_b_hoistedGlobal;
  c100_c_y = NULL;
  sf_mex_assign(&c100_c_y, sf_mex_create("y", &c100_b_u, 3, 0U, 0U, 0U, 0),
                FALSE);
  sf_mex_setcell(c100_y, 1, c100_c_y);
  sf_mex_assign(&c100_st, c100_y, FALSE);
  return c100_st;
}

static void set_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_st)
{
  const mxArray *c100_u;
  real_T *c100_T;
  c100_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c100_doneDoubleBufferReInit = TRUE;
  c100_u = sf_mex_dup(c100_st);
  *c100_T = c100_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c100_u, 0)), "T");
  chartInstance->c100_is_active_c100_laneKeepingArcSplinesFF2013a =
    c100_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c100_u, 1)),
    "is_active_c100_laneKeepingArcSplinesFF2013a");
  sf_mex_destroy(&c100_u);
  c100_update_debugger_state_c100_laneKeepingArcSplinesFF2013a(chartInstance);
  sf_mex_destroy(&c100_st);
}

static void finalize_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void sf_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T *c100_r;
  real_T *c100_Flf;
  real_T *c100_Flf_dot;
  real_T *c100_delta_dot;
  real_T *c100_r_dot;
  real_T *c100_dy;
  real_T *c100_delta;
  real_T *c100_alpha;
  real_T *c100_dx;
  real_T *c100_VOmegax;
  real_T *c100_VOmega;
  real_T *c100_IOmega;
  real_T *c100_df_D_lambda;
  real_T *c100_ddx;
  real_T *c100_df_D_dalpha;
  real_T *c100_ddy;
  real_T *c100_VOmegay;
  real_T *c100_mup;
  real_T *c100_Fz0;
  real_T *c100_VOmegaa;
  real_T *c100_Omega;
  real_T *c100_Fa;
  real_T *c100_lambda;
  real_T *c100_T;
  c100_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c100_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
  c100_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
  c100_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
  c100_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
  c100_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
  c100_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
  c100_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
  c100_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
  c100_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
  c100_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
  c100_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
  c100_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
  c100_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
  c100_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c100_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c100_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c100_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c100_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c100_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c100_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c100_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c100_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c100_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 11U, chartInstance->c100_sfEvent);
  _SFD_DATA_RANGE_CHECK(*c100_r, 0U);
  _SFD_DATA_RANGE_CHECK(*c100_Flf, 1U);
  _SFD_DATA_RANGE_CHECK(*c100_Flf_dot, 2U);
  _SFD_DATA_RANGE_CHECK(*c100_delta_dot, 3U);
  _SFD_DATA_RANGE_CHECK(*c100_r_dot, 4U);
  _SFD_DATA_RANGE_CHECK(*c100_dy, 5U);
  _SFD_DATA_RANGE_CHECK(*c100_delta, 6U);
  _SFD_DATA_RANGE_CHECK(*c100_alpha, 7U);
  _SFD_DATA_RANGE_CHECK(*c100_dx, 8U);
  _SFD_DATA_RANGE_CHECK(*c100_VOmegax, 9U);
  _SFD_DATA_RANGE_CHECK(*c100_VOmega, 10U);
  _SFD_DATA_RANGE_CHECK(*c100_IOmega, 11U);
  _SFD_DATA_RANGE_CHECK(*c100_df_D_lambda, 12U);
  _SFD_DATA_RANGE_CHECK(*c100_ddx, 13U);
  _SFD_DATA_RANGE_CHECK(*c100_df_D_dalpha, 14U);
  _SFD_DATA_RANGE_CHECK(*c100_ddy, 15U);
  _SFD_DATA_RANGE_CHECK(*c100_VOmegay, 16U);
  _SFD_DATA_RANGE_CHECK(*c100_mup, 17U);
  _SFD_DATA_RANGE_CHECK(*c100_Fz0, 18U);
  _SFD_DATA_RANGE_CHECK(*c100_VOmegaa, 19U);
  _SFD_DATA_RANGE_CHECK(*c100_Omega, 20U);
  _SFD_DATA_RANGE_CHECK(*c100_Fa, 21U);
  _SFD_DATA_RANGE_CHECK(*c100_lambda, 22U);
  _SFD_DATA_RANGE_CHECK(*c100_T, 23U);
  chartInstance->c100_sfEvent = CALL_EVENT;
  c100_chartstep_c100_laneKeepingArcSplinesFF2013a(chartInstance);
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_laneKeepingArcSplinesFF2013aMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void c100_chartstep_c100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
  real_T c100_hoistedGlobal;
  real_T c100_b_hoistedGlobal;
  real_T c100_c_hoistedGlobal;
  real_T c100_d_hoistedGlobal;
  real_T c100_e_hoistedGlobal;
  real_T c100_f_hoistedGlobal;
  real_T c100_g_hoistedGlobal;
  real_T c100_h_hoistedGlobal;
  real_T c100_i_hoistedGlobal;
  real_T c100_j_hoistedGlobal;
  real_T c100_k_hoistedGlobal;
  real_T c100_l_hoistedGlobal;
  real_T c100_m_hoistedGlobal;
  real_T c100_n_hoistedGlobal;
  real_T c100_o_hoistedGlobal;
  real_T c100_p_hoistedGlobal;
  real_T c100_q_hoistedGlobal;
  real_T c100_r_hoistedGlobal;
  real_T c100_s_hoistedGlobal;
  real_T c100_t_hoistedGlobal;
  real_T c100_u_hoistedGlobal;
  real_T c100_v_hoistedGlobal;
  real_T c100_w_hoistedGlobal;
  real_T c100_r;
  real_T c100_Flf;
  real_T c100_Flf_dot;
  real_T c100_delta_dot;
  real_T c100_r_dot;
  real_T c100_dy;
  real_T c100_delta;
  real_T c100_alpha;
  real_T c100_dx;
  real_T c100_VOmegax;
  real_T c100_VOmega;
  real_T c100_IOmega;
  real_T c100_df_D_lambda;
  real_T c100_ddx;
  real_T c100_df_D_dalpha;
  real_T c100_ddy;
  real_T c100_VOmegay;
  real_T c100_mup;
  real_T c100_Fz0;
  real_T c100_VOmegaa;
  real_T c100_Omega;
  real_T c100_Fa;
  real_T c100_lambda;
  uint32_T c100_debug_family_var_map[45];
  real_T c100_R;
  real_T c100_k;
  real_T c100_S;
  real_T c100_L;
  real_T c100_m;
  real_T c100_Iomega;
  real_T c100_Cx;
  real_T c100_Cy;
  real_T c100_Bdelta;
  real_T c100_Br;
  real_T c100_C0;
  real_T c100_Cr;
  real_T c100_ea;
  real_T c100_zeta;
  real_T c100_df_D1_dalpha;
  real_T c100_df_D2_dalpha;
  real_T c100_df_D1_dlambda;
  real_T c100_df_D2_dlambda;
  real_T c100_sprime;
  real_T c100_nargin = 23.0;
  real_T c100_nargout = 1.0;
  real_T c100_T;
  real_T c100_b;
  real_T c100_y;
  real_T c100_b_b;
  real_T c100_b_y;
  real_T c100_A;
  real_T c100_B;
  real_T c100_x;
  real_T c100_c_y;
  real_T c100_b_x;
  real_T c100_d_y;
  real_T c100_e_y;
  real_T c100_c_x;
  real_T c100_d_x;
  real_T c100_a;
  real_T c100_c_b;
  real_T c100_f_y;
  real_T c100_e_x;
  real_T c100_f_x;
  real_T c100_b_a;
  real_T c100_d_b;
  real_T c100_g_y;
  real_T c100_g_x;
  real_T c100_h_x;
  real_T c100_e_b;
  real_T c100_h_y;
  real_T c100_i_x;
  real_T c100_j_x;
  real_T c100_f_b;
  real_T c100_i_y;
  real_T c100_c_a;
  real_T c100_g_b;
  real_T c100_j_y;
  real_T c100_b_A;
  real_T c100_b_B;
  real_T c100_k_x;
  real_T c100_k_y;
  real_T c100_l_x;
  real_T c100_l_y;
  real_T c100_m_y;
  real_T c100_d_a;
  real_T c100_h_b;
  real_T c100_c_A;
  real_T c100_c_B;
  real_T c100_m_x;
  real_T c100_n_y;
  real_T c100_n_x;
  real_T c100_o_y;
  real_T c100_p_y;
  real_T c100_o_x;
  real_T c100_p_x;
  real_T c100_i_b;
  real_T c100_q_y;
  real_T c100_e_a;
  real_T c100_j_b;
  real_T c100_r_y;
  real_T c100_q_x;
  real_T c100_r_x;
  real_T c100_k_b;
  real_T c100_s_y;
  real_T c100_d_A;
  real_T c100_d_B;
  real_T c100_s_x;
  real_T c100_t_y;
  real_T c100_t_x;
  real_T c100_u_y;
  real_T c100_v_y;
  real_T c100_e_B;
  real_T c100_w_y;
  real_T c100_x_y;
  real_T c100_y_y;
  real_T c100_f_a;
  real_T c100_l_b;
  real_T c100_ab_y;
  real_T c100_g_a;
  real_T c100_m_b;
  real_T c100_bb_y;
  real_T c100_h_a;
  real_T c100_n_b;
  real_T c100_cb_y;
  real_T c100_i_a;
  real_T c100_o_b;
  real_T c100_db_y;
  real_T c100_j_a;
  real_T c100_p_b;
  real_T c100_eb_y;
  real_T c100_e_A;
  real_T c100_f_B;
  real_T c100_u_x;
  real_T c100_fb_y;
  real_T c100_v_x;
  real_T c100_gb_y;
  real_T c100_g_B;
  real_T c100_hb_y;
  real_T c100_ib_y;
  real_T c100_jb_y;
  real_T c100_k_a;
  real_T c100_kb_y;
  real_T c100_l_a;
  real_T c100_lb_y;
  real_T c100_m_a;
  real_T c100_q_b;
  real_T c100_mb_y;
  real_T c100_f_A;
  real_T c100_h_B;
  real_T c100_w_x;
  real_T c100_nb_y;
  real_T c100_x_x;
  real_T c100_ob_y;
  real_T c100_n_a;
  real_T c100_r_b;
  real_T c100_pb_y;
  real_T c100_o_a;
  real_T c100_s_b;
  real_T c100_qb_y;
  real_T c100_p_a;
  real_T c100_t_b;
  real_T c100_rb_y;
  real_T c100_y_x;
  real_T c100_ab_x;
  real_T c100_q_a;
  real_T c100_u_b;
  real_T c100_sb_y;
  real_T c100_bb_x;
  real_T c100_cb_x;
  real_T c100_r_a;
  real_T c100_v_b;
  real_T c100_tb_y;
  real_T c100_db_x;
  real_T c100_eb_x;
  real_T c100_w_b;
  real_T c100_ub_y;
  real_T c100_x_b;
  real_T c100_vb_y;
  real_T c100_s_a;
  real_T c100_y_b;
  real_T c100_wb_y;
  real_T c100_ab_b;
  real_T c100_xb_y;
  real_T c100_fb_x;
  real_T c100_gb_x;
  real_T c100_bb_b;
  real_T c100_yb_y;
  real_T c100_t_a;
  real_T c100_cb_b;
  real_T c100_ac_y;
  real_T c100_u_a;
  real_T c100_db_b;
  real_T c100_bc_y;
  real_T c100_v_a;
  real_T c100_eb_b;
  real_T c100_cc_y;
  real_T c100_fb_b;
  real_T c100_dc_y;
  real_T c100_hb_x;
  real_T c100_ib_x;
  real_T c100_gb_b;
  real_T c100_ec_y;
  real_T c100_w_a;
  real_T c100_hb_b;
  real_T c100_fc_y;
  real_T c100_ib_b;
  real_T c100_gc_y;
  real_T c100_jb_x;
  real_T c100_kb_x;
  real_T c100_x_a;
  real_T c100_jb_b;
  real_T c100_hc_y;
  real_T c100_y_a;
  real_T c100_kb_b;
  real_T c100_ic_y;
  real_T c100_lb_b;
  real_T c100_jc_y;
  real_T c100_lb_x;
  real_T c100_mb_x;
  real_T c100_mb_b;
  real_T c100_kc_y;
  real_T c100_nb_b;
  real_T c100_lc_y;
  real_T c100_g_A;
  real_T c100_i_B;
  real_T c100_nb_x;
  real_T c100_mc_y;
  real_T c100_ob_x;
  real_T c100_nc_y;
  real_T c100_ob_b;
  real_T c100_oc_y;
  real_T c100_ab_a;
  real_T c100_pb_b;
  real_T c100_pc_y;
  real_T c100_h_A;
  real_T c100_j_B;
  real_T c100_pb_x;
  real_T c100_qc_y;
  real_T c100_qb_x;
  real_T c100_rc_y;
  real_T c100_sc_y;
  real_T c100_k_B;
  real_T c100_tc_y;
  real_T c100_uc_y;
  real_T c100_vc_y;
  real_T c100_qb_b;
  real_T c100_wc_y;
  real_T c100_bb_a;
  real_T c100_rb_b;
  real_T c100_xc_y;
  real_T c100_sb_b;
  real_T c100_yc_y;
  real_T c100_rb_x;
  real_T c100_sb_x;
  real_T c100_tb_b;
  real_T c100_ad_y;
  real_T c100_i_A;
  real_T c100_l_B;
  real_T c100_tb_x;
  real_T c100_bd_y;
  real_T c100_ub_x;
  real_T c100_cd_y;
  real_T c100_dd_y;
  real_T c100_ub_b;
  real_T c100_ed_y;
  real_T c100_cb_a;
  real_T c100_vb_b;
  real_T c100_fd_y;
  real_T c100_wb_b;
  real_T c100_gd_y;
  real_T c100_vb_x;
  real_T c100_wb_x;
  real_T c100_xb_b;
  real_T c100_hd_y;
  real_T c100_yb_b;
  real_T c100_id_y;
  real_T c100_j_A;
  real_T c100_m_B;
  real_T c100_xb_x;
  real_T c100_jd_y;
  real_T c100_yb_x;
  real_T c100_kd_y;
  real_T c100_ld_y;
  real_T c100_ac_b;
  real_T c100_md_y;
  real_T c100_db_a;
  real_T c100_bc_b;
  real_T c100_nd_y;
  real_T c100_eb_a;
  real_T c100_cc_b;
  real_T c100_od_y;
  real_T c100_dc_b;
  real_T c100_pd_y;
  real_T c100_ac_x;
  real_T c100_bc_x;
  real_T c100_ec_b;
  real_T c100_qd_y;
  real_T c100_k_A;
  real_T c100_n_B;
  real_T c100_cc_x;
  real_T c100_rd_y;
  real_T c100_dc_x;
  real_T c100_sd_y;
  real_T c100_td_y;
  real_T c100_fc_b;
  real_T c100_ud_y;
  real_T c100_fb_a;
  real_T c100_gc_b;
  real_T c100_vd_y;
  real_T c100_gb_a;
  real_T c100_hc_b;
  real_T c100_wd_y;
  real_T c100_ic_b;
  real_T c100_xd_y;
  real_T c100_ec_x;
  real_T c100_fc_x;
  real_T c100_jc_b;
  real_T c100_yd_y;
  real_T c100_kc_b;
  real_T c100_ae_y;
  real_T c100_l_A;
  real_T c100_o_B;
  real_T c100_gc_x;
  real_T c100_be_y;
  real_T c100_hc_x;
  real_T c100_ce_y;
  real_T c100_de_y;
  real_T c100_lc_b;
  real_T c100_ee_y;
  real_T c100_hb_a;
  real_T c100_mc_b;
  real_T c100_fe_y;
  real_T c100_ib_a;
  real_T c100_nc_b;
  real_T c100_ge_y;
  real_T c100_ic_x;
  real_T c100_jc_x;
  real_T c100_oc_b;
  real_T c100_he_y;
  real_T c100_pc_b;
  real_T c100_ie_y;
  real_T c100_qc_b;
  real_T c100_je_y;
  real_T c100_kc_x;
  real_T c100_lc_x;
  real_T c100_jb_a;
  real_T c100_rc_b;
  real_T c100_ke_y;
  real_T c100_sc_b;
  real_T c100_le_y;
  real_T c100_m_A;
  real_T c100_p_B;
  real_T c100_mc_x;
  real_T c100_me_y;
  real_T c100_nc_x;
  real_T c100_ne_y;
  real_T c100_oe_y;
  real_T c100_tc_b;
  real_T c100_pe_y;
  real_T c100_kb_a;
  real_T c100_uc_b;
  real_T c100_qe_y;
  real_T c100_lb_a;
  real_T c100_vc_b;
  real_T c100_re_y;
  real_T c100_oc_x;
  real_T c100_pc_x;
  real_T c100_mb_a;
  real_T c100_wc_b;
  real_T c100_se_y;
  real_T c100_xc_b;
  real_T c100_te_y;
  real_T c100_qc_x;
  real_T c100_rc_x;
  real_T c100_yc_b;
  real_T c100_ue_y;
  real_T c100_ad_b;
  real_T c100_ve_y;
  real_T c100_n_A;
  real_T c100_q_B;
  real_T c100_sc_x;
  real_T c100_we_y;
  real_T c100_tc_x;
  real_T c100_xe_y;
  real_T c100_ye_y;
  real_T c100_bd_b;
  real_T c100_af_y;
  real_T c100_nb_a;
  real_T c100_cd_b;
  real_T c100_bf_y;
  real_T c100_ob_a;
  real_T c100_dd_b;
  real_T c100_cf_y;
  real_T c100_uc_x;
  real_T c100_vc_x;
  real_T c100_df_y;
  real_T c100_pb_a;
  real_T c100_ed_b;
  real_T c100_ef_y;
  real_T c100_wc_x;
  real_T c100_xc_x;
  real_T c100_fd_b;
  real_T c100_ff_y;
  real_T c100_gd_b;
  real_T c100_gf_y;
  real_T c100_hd_b;
  real_T c100_hf_y;
  real_T c100_yc_x;
  real_T c100_ad_x;
  real_T c100_qb_a;
  real_T c100_id_b;
  real_T c100_if_y;
  real_T c100_jd_b;
  real_T c100_jf_y;
  real_T c100_o_A;
  real_T c100_r_B;
  real_T c100_bd_x;
  real_T c100_kf_y;
  real_T c100_cd_x;
  real_T c100_lf_y;
  real_T c100_mf_y;
  real_T c100_rb_a;
  real_T c100_kd_b;
  real_T c100_nf_y;
  real_T c100_dd_x;
  real_T c100_ed_x;
  real_T c100_of_y;
  real_T c100_sb_a;
  real_T c100_ld_b;
  real_T c100_pf_y;
  real_T c100_md_b;
  real_T c100_qf_y;
  real_T c100_fd_x;
  real_T c100_gd_x;
  real_T c100_nd_b;
  real_T c100_rf_y;
  real_T c100_hd_x;
  real_T c100_id_x;
  real_T c100_od_b;
  real_T c100_sf_y;
  real_T c100_p_A;
  real_T c100_s_B;
  real_T c100_jd_x;
  real_T c100_tf_y;
  real_T c100_kd_x;
  real_T c100_uf_y;
  real_T c100_tb_a;
  real_T c100_vf_y;
  real_T c100_ub_a;
  real_T c100_pd_b;
  real_T c100_wf_y;
  real_T c100_t_B;
  real_T c100_xf_y;
  real_T c100_yf_y;
  real_T c100_ag_y;
  real_T c100_vb_a;
  real_T c100_qd_b;
  real_T c100_bg_y;
  real_T c100_ld_x;
  real_T c100_md_x;
  real_T c100_wb_a;
  real_T c100_rd_b;
  real_T c100_cg_y;
  real_T c100_xb_a;
  real_T c100_sd_b;
  real_T c100_dg_y;
  real_T c100_nd_x;
  real_T c100_od_x;
  real_T c100_yb_a;
  real_T c100_td_b;
  real_T c100_eg_y;
  real_T c100_ac_a;
  real_T c100_ud_b;
  real_T c100_fg_y;
  real_T c100_pd_x;
  real_T c100_qd_x;
  real_T c100_gg_y;
  real_T c100_q_A;
  real_T c100_u_B;
  real_T c100_rd_x;
  real_T c100_hg_y;
  real_T c100_sd_x;
  real_T c100_ig_y;
  real_T c100_jg_y;
  real_T c100_bc_a;
  real_T c100_vd_b;
  real_T c100_kg_y;
  real_T c100_cc_a;
  real_T c100_wd_b;
  real_T c100_lg_y;
  real_T c100_v_B;
  real_T c100_mg_y;
  real_T c100_ng_y;
  real_T c100_og_y;
  real_T c100_dc_a;
  real_T c100_xd_b;
  real_T c100_pg_y;
  real_T c100_ec_a;
  real_T c100_yd_b;
  real_T c100_qg_y;
  real_T c100_r_A;
  real_T c100_w_B;
  real_T c100_td_x;
  real_T c100_rg_y;
  real_T c100_ud_x;
  real_T c100_sg_y;
  real_T c100_tg_y;
  real_T c100_fc_a;
  real_T c100_ae_b;
  real_T c100_ug_y;
  real_T c100_s_A;
  real_T c100_x_B;
  real_T c100_vd_x;
  real_T c100_vg_y;
  real_T c100_wd_x;
  real_T c100_wg_y;
  real_T c100_xg_y;
  real_T c100_gc_a;
  real_T c100_be_b;
  real_T c100_yg_y;
  real_T c100_hc_a;
  real_T c100_ce_b;
  real_T c100_ah_y;
  real_T *c100_b_lambda;
  real_T *c100_b_Fa;
  real_T *c100_b_Omega;
  real_T *c100_b_VOmegaa;
  real_T *c100_b_Fz0;
  real_T *c100_b_mup;
  real_T *c100_b_VOmegay;
  real_T *c100_b_ddy;
  real_T *c100_b_df_D_dalpha;
  real_T *c100_b_ddx;
  real_T *c100_b_df_D_lambda;
  real_T *c100_b_IOmega;
  real_T *c100_b_VOmega;
  real_T *c100_b_VOmegax;
  real_T *c100_b_dx;
  real_T *c100_b_alpha;
  real_T *c100_b_delta;
  real_T *c100_b_dy;
  real_T *c100_b_r_dot;
  real_T *c100_b_delta_dot;
  real_T *c100_b_Flf_dot;
  real_T *c100_b_Flf;
  real_T *c100_b_r;
  real_T *c100_b_T;
  c100_b_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c100_b_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
  c100_b_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
  c100_b_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
  c100_b_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
  c100_b_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
  c100_b_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
  c100_b_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
  c100_b_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
  c100_b_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
  c100_b_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
  c100_b_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
  c100_b_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
  c100_b_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
  c100_b_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
  c100_b_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
  c100_b_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
  c100_b_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
  c100_b_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
  c100_b_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
  c100_b_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c100_b_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c100_b_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c100_b_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 11U, chartInstance->c100_sfEvent);
  c100_hoistedGlobal = *c100_b_r;
  c100_b_hoistedGlobal = *c100_b_Flf;
  c100_c_hoistedGlobal = *c100_b_Flf_dot;
  c100_d_hoistedGlobal = *c100_b_delta_dot;
  c100_e_hoistedGlobal = *c100_b_r_dot;
  c100_f_hoistedGlobal = *c100_b_dy;
  c100_g_hoistedGlobal = *c100_b_delta;
  c100_h_hoistedGlobal = *c100_b_alpha;
  c100_i_hoistedGlobal = *c100_b_dx;
  c100_j_hoistedGlobal = *c100_b_VOmegax;
  c100_k_hoistedGlobal = *c100_b_VOmega;
  c100_l_hoistedGlobal = *c100_b_IOmega;
  c100_m_hoistedGlobal = *c100_b_df_D_lambda;
  c100_n_hoistedGlobal = *c100_b_ddx;
  c100_o_hoistedGlobal = *c100_b_df_D_dalpha;
  c100_p_hoistedGlobal = *c100_b_ddy;
  c100_q_hoistedGlobal = *c100_b_VOmegay;
  c100_r_hoistedGlobal = *c100_b_mup;
  c100_s_hoistedGlobal = *c100_b_Fz0;
  c100_t_hoistedGlobal = *c100_b_VOmegaa;
  c100_u_hoistedGlobal = *c100_b_Omega;
  c100_v_hoistedGlobal = *c100_b_Fa;
  c100_w_hoistedGlobal = *c100_b_lambda;
  c100_r = c100_hoistedGlobal;
  c100_Flf = c100_b_hoistedGlobal;
  c100_Flf_dot = c100_c_hoistedGlobal;
  c100_delta_dot = c100_d_hoistedGlobal;
  c100_r_dot = c100_e_hoistedGlobal;
  c100_dy = c100_f_hoistedGlobal;
  c100_delta = c100_g_hoistedGlobal;
  c100_alpha = c100_h_hoistedGlobal;
  c100_dx = c100_i_hoistedGlobal;
  c100_VOmegax = c100_j_hoistedGlobal;
  c100_VOmega = c100_k_hoistedGlobal;
  c100_IOmega = c100_l_hoistedGlobal;
  c100_df_D_lambda = c100_m_hoistedGlobal;
  c100_ddx = c100_n_hoistedGlobal;
  c100_df_D_dalpha = c100_o_hoistedGlobal;
  c100_ddy = c100_p_hoistedGlobal;
  c100_VOmegay = c100_q_hoistedGlobal;
  c100_mup = c100_r_hoistedGlobal;
  c100_Fz0 = c100_s_hoistedGlobal;
  c100_VOmegaa = c100_t_hoistedGlobal;
  c100_Omega = c100_u_hoistedGlobal;
  c100_Fa = c100_v_hoistedGlobal;
  c100_lambda = c100_w_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 45U, 45U, c100_debug_family_names,
    c100_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_R, 0U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_k, 1U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_S, 2U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_L, 3U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_m, 4U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_Iomega, 5U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Cx, 6U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Cy, 7U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_Bdelta, 8U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_Br, 9U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_C0, 10U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_Cr, 11U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_ea, 12U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_zeta, 13U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_df_D1_dalpha, 14U,
    c100_sf_marshallOut, c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_df_D2_dalpha, 15U,
    c100_sf_marshallOut, c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_df_D1_dlambda, 16U,
    c100_sf_marshallOut, c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_df_D2_dlambda, 17U,
    c100_sf_marshallOut, c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_sprime, 18U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_nargin, 19U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_nargout, 20U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_r, 21U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Flf, 22U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Flf_dot, 23U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_delta_dot, 24U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_r_dot, 25U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_dy, 26U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_delta, 27U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_alpha, 28U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_dx, 29U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_VOmegax, 30U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_VOmega, 31U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_IOmega, 32U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_df_D_lambda, 33U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_ddx, 34U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_df_D_dalpha, 35U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_ddy, 36U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_VOmegay, 37U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_mup, 38U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Fz0, 39U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_VOmegaa, 40U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Omega, 41U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_Fa, 42U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c100_lambda, 43U, c100_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c100_T, 44U, c100_sf_marshallOut,
    c100_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 5);
  c100_R = 0.344;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 6);
  c100_k = 5.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 8);
  c100_S = 1.421;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 9);
  c100_L = 1.029;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 10);
  c100_m = 1480.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 11);
  c100_Iomega = 2.7;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 13);
  c100_Cx = 435000.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 14);
  c100_Cy = 166500.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 15);
  c100_b = c100_r;
  c100_y = 1.421 * c100_b;
  c100_VOmegax = c100_dx + c100_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 16);
  c100_b_b = c100_r;
  c100_b_y = 1.029 * c100_b_b;
  c100_VOmegay = c100_dy + c100_b_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 17);
  c100_A = 1.0 - c100_abs(chartInstance, c100_lambda);
  c100_B = c100_Fz0;
  c100_x = c100_A;
  c100_c_y = c100_B;
  c100_b_x = c100_x;
  c100_d_y = c100_c_y;
  c100_e_y = c100_b_x / c100_d_y;
  c100_c_x = c100_delta;
  c100_d_x = c100_c_x;
  c100_d_x = muDoubleScalarSin(c100_d_x);
  c100_a = c100_dx;
  c100_c_b = c100_d_x;
  c100_f_y = c100_a * c100_c_b;
  c100_e_x = c100_delta;
  c100_f_x = c100_e_x;
  c100_f_x = muDoubleScalarCos(c100_f_x);
  c100_b_a = c100_dy;
  c100_d_b = c100_f_x;
  c100_g_y = c100_b_a * c100_d_b;
  c100_g_x = c100_delta;
  c100_h_x = c100_g_x;
  c100_h_x = muDoubleScalarSin(c100_h_x);
  c100_e_b = c100_h_x;
  c100_h_y = 1.421 * c100_e_b;
  c100_i_x = c100_delta;
  c100_j_x = c100_i_x;
  c100_j_x = muDoubleScalarCos(c100_j_x);
  c100_f_b = c100_j_x;
  c100_i_y = 1.029 * c100_f_b;
  c100_c_a = c100_h_y - c100_i_y;
  c100_g_b = c100_r;
  c100_j_y = c100_c_a * c100_g_b;
  c100_b_A = c100_j_y;
  c100_b_B = c100_VOmegaa;
  c100_k_x = c100_b_A;
  c100_k_y = c100_b_B;
  c100_l_x = c100_k_x;
  c100_l_y = c100_k_y;
  c100_m_y = c100_l_x / c100_l_y;
  c100_d_a = c100_e_y;
  c100_h_b = (c100_f_y - c100_g_y) + c100_m_y;
  c100_Bdelta = c100_d_a * c100_h_b;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 18);
  c100_c_A = 1.0 - c100_abs(chartInstance, c100_lambda);
  c100_c_B = c100_Fz0;
  c100_m_x = c100_c_A;
  c100_n_y = c100_c_B;
  c100_n_x = c100_m_x;
  c100_o_y = c100_n_y;
  c100_p_y = c100_n_x / c100_o_y;
  c100_o_x = c100_delta;
  c100_p_x = c100_o_x;
  c100_p_x = muDoubleScalarCos(c100_p_x);
  c100_i_b = c100_p_x;
  c100_q_y = 1.421 * c100_i_b;
  c100_e_a = c100_p_y;
  c100_j_b = c100_q_y;
  c100_r_y = c100_e_a * c100_j_b;
  c100_q_x = c100_delta;
  c100_r_x = c100_q_x;
  c100_r_x = muDoubleScalarSin(c100_r_x);
  c100_k_b = c100_r_x;
  c100_s_y = 1.029 * c100_k_b;
  c100_d_A = c100_s_y;
  c100_d_B = c100_VOmegaa;
  c100_s_x = c100_d_A;
  c100_t_y = c100_d_B;
  c100_t_x = c100_s_x;
  c100_u_y = c100_t_y;
  c100_v_y = c100_t_x / c100_u_y;
  c100_Br = c100_r_y + c100_v_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 19);
  c100_e_B = c100_Fz0;
  c100_w_y = c100_e_B;
  c100_x_y = c100_w_y;
  c100_y_y = 1.0 / c100_x_y;
  c100_f_a = c100_dx;
  c100_l_b = c100_r;
  c100_ab_y = c100_f_a * c100_l_b;
  c100_g_a = c100_VOmegax;
  c100_m_b = c100_ddy - c100_ab_y;
  c100_bb_y = c100_g_a * c100_m_b;
  c100_h_a = c100_dy;
  c100_n_b = c100_r;
  c100_cb_y = c100_h_a * c100_n_b;
  c100_i_a = c100_VOmegay;
  c100_o_b = c100_ddx + c100_cb_y;
  c100_db_y = c100_i_a * c100_o_b;
  c100_j_a = -c100_y_y;
  c100_p_b = c100_bb_y - c100_db_y;
  c100_eb_y = c100_j_a * c100_p_b;
  c100_e_A = c100_eb_y;
  c100_f_B = c100_mpower(chartInstance, c100_VOmega);
  c100_u_x = c100_e_A;
  c100_fb_y = c100_f_B;
  c100_v_x = c100_u_x;
  c100_gb_y = c100_fb_y;
  c100_C0 = c100_v_x / c100_gb_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 20);
  c100_g_B = c100_Fz0;
  c100_hb_y = c100_g_B;
  c100_ib_y = c100_hb_y;
  c100_jb_y = 1.0 / c100_ib_y;
  c100_k_a = c100_VOmegax;
  c100_kb_y = c100_k_a * 1.029;
  c100_l_a = c100_VOmegay;
  c100_lb_y = c100_l_a * 1.421;
  c100_m_a = -c100_jb_y;
  c100_q_b = c100_kb_y - c100_lb_y;
  c100_mb_y = c100_m_a * c100_q_b;
  c100_f_A = c100_mb_y;
  c100_h_B = c100_mpower(chartInstance, c100_VOmega);
  c100_w_x = c100_f_A;
  c100_nb_y = c100_h_B;
  c100_x_x = c100_w_x;
  c100_ob_y = c100_nb_y;
  c100_Cr = c100_x_x / c100_ob_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 27);
  c100_ea = c100_Fa - c100_Flf;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 28);
  c100_n_a = c100_ea;
  c100_zeta = c100_n_a * 5.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 30);
  c100_df_D1_dalpha = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 31);
  c100_r_b = c100_Fz0;
  c100_pb_y = 1.205917875E+16 * c100_r_b;
  c100_o_a = c100_pb_y;
  c100_s_b = c100_lambda;
  c100_qb_y = c100_o_a * c100_s_b;
  c100_p_a = c100_qb_y;
  c100_t_b = c100_mup;
  c100_rb_y = c100_p_a * c100_t_b;
  c100_y_x = c100_alpha;
  c100_ab_x = c100_y_x;
  c100_ab_x = muDoubleScalarTan(c100_ab_x);
  c100_q_a = c100_rb_y;
  c100_u_b = c100_ab_x;
  c100_sb_y = c100_q_a * c100_u_b;
  c100_bb_x = c100_alpha;
  c100_cb_x = c100_bb_x;
  c100_cb_x = muDoubleScalarTan(c100_cb_x);
  c100_r_a = c100_sb_y;
  c100_v_b = c100_mpower(chartInstance, c100_cb_x) + 1.0;
  c100_tb_y = c100_r_a * c100_v_b;
  c100_db_x = c100_alpha;
  c100_eb_x = c100_db_x;
  c100_eb_x = muDoubleScalarTan(c100_eb_x);
  c100_w_b = c100_b_mpower(chartInstance, c100_eb_x);
  c100_ub_y = 1.537046290125E+21 * c100_w_b;
  c100_x_b = c100_b_mpower(chartInstance, c100_lambda);
  c100_vb_y = 7.161220125E+22 * c100_x_b;
  c100_s_a = c100_Fz0;
  c100_y_b = c100_mup;
  c100_wb_y = c100_s_a * c100_y_b;
  c100_ab_b = c100_mpower(chartInstance, c100_lambda);
  c100_xb_y = 1.89225E+11 * c100_ab_b;
  c100_fb_x = c100_alpha;
  c100_gb_x = c100_fb_x;
  c100_gb_x = muDoubleScalarTan(c100_gb_x);
  c100_bb_b = c100_mpower(chartInstance, c100_gb_x);
  c100_yb_y = 2.772225E+10 * c100_bb_b;
  c100_t_a = c100_wb_y;
  c100_cb_b = c100_c_mpower(chartInstance, c100_xb_y + c100_yb_y);
  c100_ac_y = c100_t_a * c100_cb_b;
  c100_u_a = c100_Fz0;
  c100_db_b = c100_mup;
  c100_bc_y = c100_u_a * c100_db_b;
  c100_v_a = c100_bc_y;
  c100_eb_b = c100_abs(chartInstance, c100_lambda);
  c100_cc_y = c100_v_a * c100_eb_b;
  c100_fb_b = c100_mpower(chartInstance, c100_lambda);
  c100_dc_y = 1.89225E+11 * c100_fb_b;
  c100_hb_x = c100_alpha;
  c100_ib_x = c100_hb_x;
  c100_ib_x = muDoubleScalarTan(c100_ib_x);
  c100_gb_b = c100_mpower(chartInstance, c100_ib_x);
  c100_ec_y = 2.772225E+10 * c100_gb_b;
  c100_w_a = c100_cc_y;
  c100_hb_b = c100_c_mpower(chartInstance, c100_dc_y + c100_ec_y);
  c100_fc_y = c100_w_a * c100_hb_b;
  c100_ib_b = c100_mpower(chartInstance, c100_lambda);
  c100_gc_y = 2.0982971025E+22 * c100_ib_b;
  c100_jb_x = c100_alpha;
  c100_kb_x = c100_jb_x;
  c100_kb_x = muDoubleScalarTan(c100_kb_x);
  c100_x_a = c100_gc_y;
  c100_jb_b = c100_mpower(chartInstance, c100_kb_x);
  c100_hc_y = c100_x_a * c100_jb_b;
  c100_y_a = c100_tb_y;
  c100_kb_b = (((c100_ub_y + c100_vb_y) - c100_ac_y) + c100_fc_y) + c100_hc_y;
  c100_ic_y = c100_y_a * c100_kb_b;
  c100_lb_b = c100_mpower(chartInstance, c100_lambda);
  c100_jc_y = 1.89225E+11 * c100_lb_b;
  c100_lb_x = c100_alpha;
  c100_mb_x = c100_lb_x;
  c100_mb_x = muDoubleScalarTan(c100_mb_x);
  c100_mb_b = c100_mpower(chartInstance, c100_mb_x);
  c100_kc_y = 2.772225E+10 * c100_mb_b;
  c100_nb_b = c100_d_mpower(chartInstance, c100_jc_y + c100_kc_y);
  c100_lc_y = 2.0 * c100_nb_b;
  c100_g_A = -c100_ic_y;
  c100_i_B = c100_lc_y;
  c100_nb_x = c100_g_A;
  c100_mc_y = c100_i_B;
  c100_ob_x = c100_nb_x;
  c100_nc_y = c100_mc_y;
  c100_df_D2_dalpha = c100_ob_x / c100_nc_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 34);
  c100_ob_b = c100_lambda;
  c100_oc_y = 435000.0 * c100_ob_b;
  c100_ab_a = c100_oc_y;
  c100_pb_b = c100_lambda;
  c100_b_sign(chartInstance, &c100_pb_b);
  c100_pc_y = c100_ab_a * c100_pb_b;
  c100_h_A = c100_pc_y;
  c100_j_B = c100_mpower(chartInstance, c100_abs(chartInstance, c100_lambda) -
    1.0);
  c100_pb_x = c100_h_A;
  c100_qc_y = c100_j_B;
  c100_qb_x = c100_pb_x;
  c100_rc_y = c100_qc_y;
  c100_sc_y = c100_qb_x / c100_rc_y;
  c100_k_B = c100_abs(chartInstance, c100_lambda) - 1.0;
  c100_tc_y = c100_k_B;
  c100_uc_y = c100_tc_y;
  c100_vc_y = 435000.0 / c100_uc_y;
  c100_df_D1_dlambda = c100_sc_y - c100_vc_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 35);
  c100_qb_b = c100_Fz0;
  c100_wc_y = 435000.0 * c100_qb_b;
  c100_bb_a = c100_wc_y;
  c100_rb_b = c100_mup;
  c100_xc_y = c100_bb_a * c100_rb_b;
  c100_sb_b = c100_mpower(chartInstance, c100_lambda);
  c100_yc_y = 1.89225E+11 * c100_sb_b;
  c100_rb_x = c100_alpha;
  c100_sb_x = c100_rb_x;
  c100_sb_x = muDoubleScalarTan(c100_sb_x);
  c100_tb_b = c100_mpower(chartInstance, c100_sb_x);
  c100_ad_y = 2.772225E+10 * c100_tb_b;
  c100_i_A = c100_xc_y;
  c100_l_B = c100_e_mpower(chartInstance, c100_yc_y + c100_ad_y);
  c100_tb_x = c100_i_A;
  c100_bd_y = c100_l_B;
  c100_ub_x = c100_tb_x;
  c100_cd_y = c100_bd_y;
  c100_dd_y = c100_ub_x / c100_cd_y;
  c100_ub_b = c100_mpower(chartInstance, c100_Fz0);
  c100_ed_y = 435000.0 * c100_ub_b;
  c100_cb_a = c100_ed_y;
  c100_vb_b = c100_mpower(chartInstance, c100_mup);
  c100_fd_y = c100_cb_a * c100_vb_b;
  c100_wb_b = c100_mpower(chartInstance, c100_lambda);
  c100_gd_y = 1.89225E+11 * c100_wb_b;
  c100_vb_x = c100_alpha;
  c100_wb_x = c100_vb_x;
  c100_wb_x = muDoubleScalarTan(c100_wb_x);
  c100_xb_b = c100_mpower(chartInstance, c100_wb_x);
  c100_hd_y = 2.772225E+10 * c100_xb_b;
  c100_yb_b = c100_gd_y + c100_hd_y;
  c100_id_y = 4.0 * c100_yb_b;
  c100_j_A = c100_fd_y;
  c100_m_B = c100_id_y;
  c100_xb_x = c100_j_A;
  c100_jd_y = c100_m_B;
  c100_yb_x = c100_xb_x;
  c100_kd_y = c100_jd_y;
  c100_ld_y = c100_yb_x / c100_kd_y;
  c100_ac_b = c100_Fz0;
  c100_md_y = 8.2312875E+16 * c100_ac_b;
  c100_db_a = c100_md_y;
  c100_bc_b = c100_mpower(chartInstance, c100_lambda);
  c100_nd_y = c100_db_a * c100_bc_b;
  c100_eb_a = c100_nd_y;
  c100_cc_b = c100_mup;
  c100_od_y = c100_eb_a * c100_cc_b;
  c100_dc_b = c100_mpower(chartInstance, c100_lambda);
  c100_pd_y = 1.89225E+11 * c100_dc_b;
  c100_ac_x = c100_alpha;
  c100_bc_x = c100_ac_x;
  c100_bc_x = muDoubleScalarTan(c100_bc_x);
  c100_ec_b = c100_mpower(chartInstance, c100_bc_x);
  c100_qd_y = 2.772225E+10 * c100_ec_b;
  c100_k_A = c100_od_y;
  c100_n_B = c100_c_mpower(chartInstance, c100_pd_y + c100_qd_y);
  c100_cc_x = c100_k_A;
  c100_rd_y = c100_n_B;
  c100_dc_x = c100_cc_x;
  c100_sd_y = c100_rd_y;
  c100_td_y = c100_dc_x / c100_sd_y;
  c100_fc_b = c100_mpower(chartInstance, c100_Fz0);
  c100_ud_y = 435000.0 * c100_fc_b;
  c100_fb_a = c100_ud_y;
  c100_gc_b = c100_mpower(chartInstance, c100_mup);
  c100_vd_y = c100_fb_a * c100_gc_b;
  c100_gb_a = c100_vd_y;
  c100_hc_b = c100_abs(chartInstance, c100_lambda);
  c100_wd_y = c100_gb_a * c100_hc_b;
  c100_ic_b = c100_mpower(chartInstance, c100_lambda);
  c100_xd_y = 1.89225E+11 * c100_ic_b;
  c100_ec_x = c100_alpha;
  c100_fc_x = c100_ec_x;
  c100_fc_x = muDoubleScalarTan(c100_fc_x);
  c100_jc_b = c100_mpower(chartInstance, c100_fc_x);
  c100_yd_y = 2.772225E+10 * c100_jc_b;
  c100_kc_b = c100_xd_y + c100_yd_y;
  c100_ae_y = 4.0 * c100_kc_b;
  c100_l_A = c100_wd_y;
  c100_o_B = c100_ae_y;
  c100_gc_x = c100_l_A;
  c100_be_y = c100_o_B;
  c100_hc_x = c100_gc_x;
  c100_ce_y = c100_be_y;
  c100_de_y = c100_hc_x / c100_ce_y;
  c100_lc_b = c100_mpower(chartInstance, c100_Fz0);
  c100_ee_y = 8.2312875E+16 * c100_lc_b;
  c100_hb_a = c100_ee_y;
  c100_mc_b = c100_mpower(chartInstance, c100_lambda);
  c100_fe_y = c100_hb_a * c100_mc_b;
  c100_ib_a = c100_fe_y;
  c100_nc_b = c100_mpower(chartInstance, c100_mup);
  c100_ge_y = c100_ib_a * c100_nc_b;
  c100_ic_x = c100_alpha;
  c100_jc_x = c100_ic_x;
  c100_jc_x = muDoubleScalarTan(c100_jc_x);
  c100_oc_b = c100_b_mpower(chartInstance, c100_jc_x);
  c100_he_y = 7.685231450625E+20 * c100_oc_b;
  c100_pc_b = c100_b_mpower(chartInstance, c100_lambda);
  c100_ie_y = 3.5806100625E+22 * c100_pc_b;
  c100_qc_b = c100_mpower(chartInstance, c100_lambda);
  c100_je_y = 1.04914855125E+22 * c100_qc_b;
  c100_kc_x = c100_alpha;
  c100_lc_x = c100_kc_x;
  c100_lc_x = muDoubleScalarTan(c100_lc_x);
  c100_jb_a = c100_je_y;
  c100_rc_b = c100_mpower(chartInstance, c100_lc_x);
  c100_ke_y = c100_jb_a * c100_rc_b;
  c100_sc_b = (c100_he_y + c100_ie_y) + c100_ke_y;
  c100_le_y = 2.0 * c100_sc_b;
  c100_m_A = c100_ge_y;
  c100_p_B = c100_le_y;
  c100_mc_x = c100_m_A;
  c100_me_y = c100_p_B;
  c100_nc_x = c100_mc_x;
  c100_ne_y = c100_me_y;
  c100_oe_y = c100_nc_x / c100_ne_y;
  c100_tc_b = c100_mpower(chartInstance, c100_Fz0);
  c100_pe_y = 435000.0 * c100_tc_b;
  c100_kb_a = c100_pe_y;
  c100_uc_b = c100_lambda;
  c100_qe_y = c100_kb_a * c100_uc_b;
  c100_lb_a = c100_qe_y;
  c100_vc_b = c100_mpower(chartInstance, c100_mup);
  c100_re_y = c100_lb_a * c100_vc_b;
  c100_oc_x = c100_lambda;
  c100_pc_x = c100_oc_x;
  c100_pc_x = muDoubleScalarSign(c100_pc_x);
  c100_mb_a = c100_re_y;
  c100_wc_b = c100_pc_x;
  c100_se_y = c100_mb_a * c100_wc_b;
  c100_xc_b = c100_mpower(chartInstance, c100_lambda);
  c100_te_y = 1.89225E+11 * c100_xc_b;
  c100_qc_x = c100_alpha;
  c100_rc_x = c100_qc_x;
  c100_rc_x = muDoubleScalarTan(c100_rc_x);
  c100_yc_b = c100_mpower(chartInstance, c100_rc_x);
  c100_ue_y = 2.772225E+10 * c100_yc_b;
  c100_ad_b = c100_te_y + c100_ue_y;
  c100_ve_y = 4.0 * c100_ad_b;
  c100_n_A = c100_se_y;
  c100_q_B = c100_ve_y;
  c100_sc_x = c100_n_A;
  c100_we_y = c100_q_B;
  c100_tc_x = c100_sc_x;
  c100_xe_y = c100_we_y;
  c100_ye_y = c100_tc_x / c100_xe_y;
  c100_bd_b = c100_mpower(chartInstance, c100_Fz0);
  c100_af_y = 8.2312875E+16 * c100_bd_b;
  c100_nb_a = c100_af_y;
  c100_cd_b = c100_mpower(chartInstance, c100_lambda);
  c100_bf_y = c100_nb_a * c100_cd_b;
  c100_ob_a = c100_bf_y;
  c100_dd_b = c100_mpower(chartInstance, c100_mup);
  c100_cf_y = c100_ob_a * c100_dd_b;
  c100_uc_x = c100_lambda;
  c100_vc_x = c100_uc_x;
  c100_df_y = muDoubleScalarAbs(c100_vc_x);
  c100_pb_a = c100_cf_y;
  c100_ed_b = c100_df_y;
  c100_ef_y = c100_pb_a * c100_ed_b;
  c100_wc_x = c100_alpha;
  c100_xc_x = c100_wc_x;
  c100_xc_x = muDoubleScalarTan(c100_xc_x);
  c100_fd_b = c100_b_mpower(chartInstance, c100_xc_x);
  c100_ff_y = 7.685231450625E+20 * c100_fd_b;
  c100_gd_b = c100_b_mpower(chartInstance, c100_lambda);
  c100_gf_y = 3.5806100625E+22 * c100_gd_b;
  c100_hd_b = c100_mpower(chartInstance, c100_lambda);
  c100_hf_y = 1.04914855125E+22 * c100_hd_b;
  c100_yc_x = c100_alpha;
  c100_ad_x = c100_yc_x;
  c100_ad_x = muDoubleScalarTan(c100_ad_x);
  c100_qb_a = c100_hf_y;
  c100_id_b = c100_mpower(chartInstance, c100_ad_x);
  c100_if_y = c100_qb_a * c100_id_b;
  c100_jd_b = (c100_ff_y + c100_gf_y) + c100_if_y;
  c100_jf_y = 2.0 * c100_jd_b;
  c100_o_A = c100_ef_y;
  c100_r_B = c100_jf_y;
  c100_bd_x = c100_o_A;
  c100_kf_y = c100_r_B;
  c100_cd_x = c100_bd_x;
  c100_lf_y = c100_kf_y;
  c100_mf_y = c100_cd_x / c100_lf_y;
  c100_df_D2_dlambda = (((((c100_dd_y - c100_ld_y) - c100_td_y) + c100_de_y) +
    c100_oe_y) + c100_ye_y) - c100_mf_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 37);
  c100_rb_a = c100_mup;
  c100_kd_b = c100_Fz0;
  c100_nf_y = c100_rb_a * c100_kd_b;
  c100_dd_x = c100_lambda;
  c100_ed_x = c100_dd_x;
  c100_of_y = muDoubleScalarAbs(c100_ed_x);
  c100_sb_a = c100_nf_y;
  c100_ld_b = 1.0 - c100_of_y;
  c100_pf_y = c100_sb_a * c100_ld_b;
  c100_md_b = c100_mpower(chartInstance, c100_lambda);
  c100_qf_y = 1.89225E+11 * c100_md_b;
  c100_fd_x = c100_alpha;
  c100_gd_x = c100_fd_x;
  c100_gd_x = muDoubleScalarTan(c100_gd_x);
  c100_nd_b = c100_mpower(chartInstance, c100_gd_x);
  c100_rf_y = 2.772225E+10 * c100_nd_b;
  c100_hd_x = c100_qf_y + c100_rf_y;
  c100_id_x = c100_hd_x;
  if (c100_id_x < 0.0) {
    c100_b_eml_error(chartInstance);
  }

  c100_id_x = muDoubleScalarSqrt(c100_id_x);
  c100_od_b = c100_id_x;
  c100_sf_y = 2.0 * c100_od_b;
  c100_p_A = c100_pf_y;
  c100_s_B = c100_sf_y;
  c100_jd_x = c100_p_A;
  c100_tf_y = c100_s_B;
  c100_kd_x = c100_jd_x;
  c100_uf_y = c100_tf_y;
  c100_sprime = c100_kd_x / c100_uf_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 39);
  if (CV_EML_IF(0, 1, 0, c100_sprime >= 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 40);
    c100_df_D_lambda = c100_df_D1_dlambda;
  }

  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 42);
  if (CV_EML_IF(0, 1, 1, c100_sprime < 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 43);
    c100_df_D_lambda = c100_df_D2_dlambda;
  }

  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 46);
  if (CV_EML_IF(0, 1, 2, c100_sprime >= 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 47);
    c100_df_D_dalpha = c100_df_D1_dalpha;
  }

  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 49);
  if (CV_EML_IF(0, 1, 3, c100_sprime < 1.0)) {
    _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 50);
    c100_df_D_dalpha = c100_df_D2_dalpha;
  }

  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, 53);
  c100_tb_a = c100_Flf;
  c100_vf_y = c100_tb_a * 0.344;
  c100_ub_a = c100_Omega;
  c100_pd_b = c100_IOmega;
  c100_wf_y = c100_ub_a * c100_pd_b;
  c100_t_B = c100_VOmegaa;
  c100_xf_y = c100_t_B;
  c100_yf_y = c100_xf_y;
  c100_ag_y = 1.0 / c100_yf_y;
  c100_vb_a = c100_dy;
  c100_qd_b = c100_r;
  c100_bg_y = c100_vb_a * c100_qd_b;
  c100_ld_x = c100_delta;
  c100_md_x = c100_ld_x;
  c100_md_x = muDoubleScalarCos(c100_md_x);
  c100_wb_a = c100_ddx + c100_bg_y;
  c100_rd_b = c100_md_x;
  c100_cg_y = c100_wb_a * c100_rd_b;
  c100_xb_a = c100_dx;
  c100_sd_b = c100_r;
  c100_dg_y = c100_xb_a * c100_sd_b;
  c100_nd_x = c100_delta;
  c100_od_x = c100_nd_x;
  c100_od_x = muDoubleScalarSin(c100_od_x);
  c100_yb_a = c100_ddy - c100_dg_y;
  c100_td_b = c100_od_x;
  c100_eg_y = c100_yb_a * c100_td_b;
  c100_ac_a = c100_ag_y;
  c100_ud_b = c100_cg_y + c100_eg_y;
  c100_fg_y = c100_ac_a * c100_ud_b;
  c100_pd_x = c100_lambda;
  c100_qd_x = c100_pd_x;
  c100_gg_y = muDoubleScalarAbs(c100_qd_x);
  c100_q_A = c100_Fz0;
  c100_u_B = 1.0 - c100_gg_y;
  c100_rd_x = c100_q_A;
  c100_hg_y = c100_u_B;
  c100_sd_x = c100_rd_x;
  c100_ig_y = c100_hg_y;
  c100_jg_y = c100_sd_x / c100_ig_y;
  c100_bc_a = c100_Br;
  c100_vd_b = c100_r_dot;
  c100_kg_y = c100_bc_a * c100_vd_b;
  c100_cc_a = c100_Bdelta;
  c100_wd_b = c100_delta_dot;
  c100_lg_y = c100_cc_a * c100_wd_b;
  c100_v_B = c100_df_D_lambda;
  c100_mg_y = c100_v_B;
  c100_ng_y = c100_mg_y;
  c100_og_y = 1.0 / c100_ng_y;
  c100_dc_a = c100_og_y;
  c100_xd_b = c100_df_D_dalpha;
  c100_pg_y = c100_dc_a * c100_xd_b;
  c100_ec_a = c100_Cr;
  c100_yd_b = c100_r_dot;
  c100_qg_y = c100_ec_a * c100_yd_b;
  c100_r_A = c100_delta_dot;
  c100_w_B = c100_Fz0;
  c100_td_x = c100_r_A;
  c100_rg_y = c100_w_B;
  c100_ud_x = c100_td_x;
  c100_sg_y = c100_rg_y;
  c100_tg_y = c100_ud_x / c100_sg_y;
  c100_fc_a = c100_pg_y;
  c100_ae_b = (c100_C0 + c100_qg_y) + c100_tg_y;
  c100_ug_y = c100_fc_a * c100_ae_b;
  c100_s_A = c100_zeta - c100_Flf_dot;
  c100_x_B = c100_Fz0;
  c100_vd_x = c100_s_A;
  c100_vg_y = c100_x_B;
  c100_wd_x = c100_vd_x;
  c100_wg_y = c100_vg_y;
  c100_xg_y = c100_wd_x / c100_wg_y;
  c100_gc_a = c100_jg_y;
  c100_be_b = ((c100_kg_y + c100_lg_y) + c100_ug_y) + c100_xg_y;
  c100_yg_y = c100_gc_a * c100_be_b;
  c100_hc_a = c100_wf_y;
  c100_ce_b = c100_fg_y - c100_yg_y;
  c100_ah_y = c100_hc_a * c100_ce_b;
  c100_T = c100_vf_y + c100_ah_y;
  _SFD_EML_CALL(0U, chartInstance->c100_sfEvent, -53);
  _SFD_SYMBOL_SCOPE_POP();
  *c100_b_T = c100_T;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 11U, chartInstance->c100_sfEvent);
}

static void initSimStructsc100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void registerMessagesc100_laneKeepingArcSplinesFF2013a
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c100_machineNumber, uint32_T
  c100_chartNumber)
{
}

static const mxArray *c100_sf_marshallOut(void *chartInstanceVoid, void
  *c100_inData)
{
  const mxArray *c100_mxArrayOutData = NULL;
  real_T c100_u;
  const mxArray *c100_y = NULL;
  SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c100_mxArrayOutData = NULL;
  c100_u = *(real_T *)c100_inData;
  c100_y = NULL;
  sf_mex_assign(&c100_y, sf_mex_create("y", &c100_u, 0, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c100_mxArrayOutData, c100_y, FALSE);
  return c100_mxArrayOutData;
}

static real_T c100_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_T, const char_T *c100_identifier)
{
  real_T c100_y;
  emlrtMsgIdentifier c100_thisId;
  c100_thisId.fIdentifier = c100_identifier;
  c100_thisId.fParent = NULL;
  c100_y = c100_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c100_T),
    &c100_thisId);
  sf_mex_destroy(&c100_T);
  return c100_y;
}

static real_T c100_b_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId)
{
  real_T c100_y;
  real_T c100_d0;
  sf_mex_import(c100_parentId, sf_mex_dup(c100_u), &c100_d0, 1, 0, 0U, 0, 0U, 0);
  c100_y = c100_d0;
  sf_mex_destroy(&c100_u);
  return c100_y;
}

static void c100_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c100_mxArrayInData, const char_T *c100_varName, void *c100_outData)
{
  const mxArray *c100_T;
  const char_T *c100_identifier;
  emlrtMsgIdentifier c100_thisId;
  real_T c100_y;
  SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c100_T = sf_mex_dup(c100_mxArrayInData);
  c100_identifier = c100_varName;
  c100_thisId.fIdentifier = c100_identifier;
  c100_thisId.fParent = NULL;
  c100_y = c100_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c100_T),
    &c100_thisId);
  sf_mex_destroy(&c100_T);
  *(real_T *)c100_outData = c100_y;
  sf_mex_destroy(&c100_mxArrayInData);
}

const mxArray
  *sf_c100_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info(void)
{
  const mxArray *c100_nameCaptureInfo;
  c100_ResolvedFunctionInfo c100_info[28];
  const mxArray *c100_m0 = NULL;
  int32_T c100_i0;
  c100_ResolvedFunctionInfo *c100_r0;
  c100_nameCaptureInfo = NULL;
  c100_nameCaptureInfo = NULL;
  c100_info_helper(c100_info);
  sf_mex_assign(&c100_m0, sf_mex_createstruct("nameCaptureInfo", 1, 28), FALSE);
  for (c100_i0 = 0; c100_i0 < 28; c100_i0++) {
    c100_r0 = &c100_info[c100_i0];
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo", c100_r0->context,
      15, 0U, 0U, 0U, 2, 1, strlen(c100_r0->context)), "context",
                    "nameCaptureInfo", c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo", c100_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c100_r0->name)), "name", "nameCaptureInfo",
                    c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo",
      c100_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c100_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo", c100_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c100_r0->resolved)), "resolved",
                    "nameCaptureInfo", c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo",
      &c100_r0->fileTimeLo, 7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo",
                    c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo",
      &c100_r0->fileTimeHi, 7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo",
                    c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo",
      &c100_r0->mFileTimeLo, 7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo",
                    c100_i0);
    sf_mex_addfield(c100_m0, sf_mex_create("nameCaptureInfo",
      &c100_r0->mFileTimeHi, 7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo",
                    c100_i0);
  }

  sf_mex_assign(&c100_nameCaptureInfo, c100_m0, FALSE);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c100_nameCaptureInfo);
  return c100_nameCaptureInfo;
}

static void c100_info_helper(c100_ResolvedFunctionInfo c100_info[28])
{
  c100_info[0].context = "";
  c100_info[0].name = "mtimes";
  c100_info[0].dominantType = "double";
  c100_info[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c100_info[0].fileTimeLo = 1289516092U;
  c100_info[0].fileTimeHi = 0U;
  c100_info[0].mFileTimeLo = 0U;
  c100_info[0].mFileTimeHi = 0U;
  c100_info[1].context = "";
  c100_info[1].name = "abs";
  c100_info[1].dominantType = "double";
  c100_info[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c100_info[1].fileTimeLo = 1343826766U;
  c100_info[1].fileTimeHi = 0U;
  c100_info[1].mFileTimeLo = 0U;
  c100_info[1].mFileTimeHi = 0U;
  c100_info[2].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m";
  c100_info[2].name = "eml_scalar_abs";
  c100_info[2].dominantType = "double";
  c100_info[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m";
  c100_info[2].fileTimeLo = 1286815112U;
  c100_info[2].fileTimeHi = 0U;
  c100_info[2].mFileTimeLo = 0U;
  c100_info[2].mFileTimeHi = 0U;
  c100_info[3].context = "";
  c100_info[3].name = "mrdivide";
  c100_info[3].dominantType = "double";
  c100_info[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c100_info[3].fileTimeLo = 1357947948U;
  c100_info[3].fileTimeHi = 0U;
  c100_info[3].mFileTimeLo = 1319726366U;
  c100_info[3].mFileTimeHi = 0U;
  c100_info[4].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  c100_info[4].name = "rdivide";
  c100_info[4].dominantType = "double";
  c100_info[4].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c100_info[4].fileTimeLo = 1346506788U;
  c100_info[4].fileTimeHi = 0U;
  c100_info[4].mFileTimeLo = 0U;
  c100_info[4].mFileTimeHi = 0U;
  c100_info[5].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c100_info[5].name = "eml_scalexp_compatible";
  c100_info[5].dominantType = "double";
  c100_info[5].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m";
  c100_info[5].fileTimeLo = 1286815196U;
  c100_info[5].fileTimeHi = 0U;
  c100_info[5].mFileTimeLo = 0U;
  c100_info[5].mFileTimeHi = 0U;
  c100_info[6].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c100_info[6].name = "eml_div";
  c100_info[6].dominantType = "double";
  c100_info[6].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c100_info[6].fileTimeLo = 1313344210U;
  c100_info[6].fileTimeHi = 0U;
  c100_info[6].mFileTimeLo = 0U;
  c100_info[6].mFileTimeHi = 0U;
  c100_info[7].context = "";
  c100_info[7].name = "sin";
  c100_info[7].dominantType = "double";
  c100_info[7].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c100_info[7].fileTimeLo = 1343826786U;
  c100_info[7].fileTimeHi = 0U;
  c100_info[7].mFileTimeLo = 0U;
  c100_info[7].mFileTimeHi = 0U;
  c100_info[8].context = "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c100_info[8].name = "eml_scalar_sin";
  c100_info[8].dominantType = "double";
  c100_info[8].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m";
  c100_info[8].fileTimeLo = 1286815136U;
  c100_info[8].fileTimeHi = 0U;
  c100_info[8].mFileTimeLo = 0U;
  c100_info[8].mFileTimeHi = 0U;
  c100_info[9].context = "";
  c100_info[9].name = "cos";
  c100_info[9].dominantType = "double";
  c100_info[9].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c100_info[9].fileTimeLo = 1343826772U;
  c100_info[9].fileTimeHi = 0U;
  c100_info[9].mFileTimeLo = 0U;
  c100_info[9].mFileTimeHi = 0U;
  c100_info[10].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c100_info[10].name = "eml_scalar_cos";
  c100_info[10].dominantType = "double";
  c100_info[10].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c100_info[10].fileTimeLo = 1286815122U;
  c100_info[10].fileTimeHi = 0U;
  c100_info[10].mFileTimeLo = 0U;
  c100_info[10].mFileTimeHi = 0U;
  c100_info[11].context = "";
  c100_info[11].name = "mpower";
  c100_info[11].dominantType = "double";
  c100_info[11].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c100_info[11].fileTimeLo = 1286815242U;
  c100_info[11].fileTimeHi = 0U;
  c100_info[11].mFileTimeLo = 0U;
  c100_info[11].mFileTimeHi = 0U;
  c100_info[12].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m";
  c100_info[12].name = "power";
  c100_info[12].dominantType = "double";
  c100_info[12].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m";
  c100_info[12].fileTimeLo = 1348188330U;
  c100_info[12].fileTimeHi = 0U;
  c100_info[12].mFileTimeLo = 0U;
  c100_info[12].mFileTimeHi = 0U;
  c100_info[13].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c100_info[13].name = "eml_scalar_eg";
  c100_info[13].dominantType = "double";
  c100_info[13].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c100_info[13].fileTimeLo = 1286815196U;
  c100_info[13].fileTimeHi = 0U;
  c100_info[13].mFileTimeLo = 0U;
  c100_info[13].mFileTimeHi = 0U;
  c100_info[14].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c100_info[14].name = "eml_scalexp_alloc";
  c100_info[14].dominantType = "double";
  c100_info[14].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m";
  c100_info[14].fileTimeLo = 1352421260U;
  c100_info[14].fileTimeHi = 0U;
  c100_info[14].mFileTimeLo = 0U;
  c100_info[14].mFileTimeHi = 0U;
  c100_info[15].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c100_info[15].name = "floor";
  c100_info[15].dominantType = "double";
  c100_info[15].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c100_info[15].fileTimeLo = 1343826780U;
  c100_info[15].fileTimeHi = 0U;
  c100_info[15].mFileTimeLo = 0U;
  c100_info[15].mFileTimeHi = 0U;
  c100_info[16].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m";
  c100_info[16].name = "eml_scalar_floor";
  c100_info[16].dominantType = "double";
  c100_info[16].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m";
  c100_info[16].fileTimeLo = 1286815126U;
  c100_info[16].fileTimeHi = 0U;
  c100_info[16].mFileTimeLo = 0U;
  c100_info[16].mFileTimeHi = 0U;
  c100_info[17].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c100_info[17].name = "eml_scalar_eg";
  c100_info[17].dominantType = "double";
  c100_info[17].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m";
  c100_info[17].fileTimeLo = 1286815196U;
  c100_info[17].fileTimeHi = 0U;
  c100_info[17].mFileTimeLo = 0U;
  c100_info[17].mFileTimeHi = 0U;
  c100_info[18].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c100_info[18].name = "mtimes";
  c100_info[18].dominantType = "double";
  c100_info[18].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c100_info[18].fileTimeLo = 1289516092U;
  c100_info[18].fileTimeHi = 0U;
  c100_info[18].mFileTimeLo = 0U;
  c100_info[18].mFileTimeHi = 0U;
  c100_info[19].context = "";
  c100_info[19].name = "tan";
  c100_info[19].dominantType = "double";
  c100_info[19].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/tan.m";
  c100_info[19].fileTimeLo = 1343826786U;
  c100_info[19].fileTimeHi = 0U;
  c100_info[19].mFileTimeLo = 0U;
  c100_info[19].mFileTimeHi = 0U;
  c100_info[20].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/tan.m";
  c100_info[20].name = "eml_scalar_tan";
  c100_info[20].dominantType = "double";
  c100_info[20].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_tan.m";
  c100_info[20].fileTimeLo = 1286815138U;
  c100_info[20].fileTimeHi = 0U;
  c100_info[20].mFileTimeLo = 0U;
  c100_info[20].mFileTimeHi = 0U;
  c100_info[21].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower";
  c100_info[21].name = "eml_error";
  c100_info[21].dominantType = "char";
  c100_info[21].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c100_info[21].fileTimeLo = 1343826758U;
  c100_info[21].fileTimeHi = 0U;
  c100_info[21].mFileTimeLo = 0U;
  c100_info[21].mFileTimeHi = 0U;
  c100_info[22].context = "";
  c100_info[22].name = "sign";
  c100_info[22].dominantType = "double";
  c100_info[22].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c100_info[22].fileTimeLo = 1354364464U;
  c100_info[22].fileTimeHi = 0U;
  c100_info[22].mFileTimeLo = 0U;
  c100_info[22].mFileTimeHi = 0U;
  c100_info[23].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sign.m";
  c100_info[23].name = "eml_scalar_sign";
  c100_info[23].dominantType = "double";
  c100_info[23].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sign.m";
  c100_info[23].fileTimeLo = 1354364464U;
  c100_info[23].fileTimeHi = 0U;
  c100_info[23].mFileTimeLo = 0U;
  c100_info[23].mFileTimeHi = 0U;
  c100_info[24].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power";
  c100_info[24].name = "sqrt";
  c100_info[24].dominantType = "double";
  c100_info[24].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c100_info[24].fileTimeLo = 1343826786U;
  c100_info[24].fileTimeHi = 0U;
  c100_info[24].mFileTimeLo = 0U;
  c100_info[24].mFileTimeHi = 0U;
  c100_info[25].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c100_info[25].name = "eml_error";
  c100_info[25].dominantType = "char";
  c100_info[25].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c100_info[25].fileTimeLo = 1343826758U;
  c100_info[25].fileTimeHi = 0U;
  c100_info[25].mFileTimeLo = 0U;
  c100_info[25].mFileTimeHi = 0U;
  c100_info[26].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c100_info[26].name = "eml_scalar_sqrt";
  c100_info[26].dominantType = "double";
  c100_info[26].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c100_info[26].fileTimeLo = 1286815138U;
  c100_info[26].fileTimeHi = 0U;
  c100_info[26].mFileTimeLo = 0U;
  c100_info[26].mFileTimeHi = 0U;
  c100_info[27].context = "";
  c100_info[27].name = "sqrt";
  c100_info[27].dominantType = "double";
  c100_info[27].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c100_info[27].fileTimeLo = 1343826786U;
  c100_info[27].fileTimeHi = 0U;
  c100_info[27].mFileTimeLo = 0U;
  c100_info[27].mFileTimeHi = 0U;
}

static real_T c100_abs(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_x)
{
  real_T c100_b_x;
  c100_b_x = c100_x;
  return muDoubleScalarAbs(c100_b_x);
}

static real_T c100_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a)
{
  real_T c100_b_a;
  real_T c100_c_a;
  real_T c100_ak;
  real_T c100_d_a;
  real_T c100_e_a;
  real_T c100_b;
  c100_b_a = c100_a;
  c100_c_a = c100_b_a;
  c100_eml_scalar_eg(chartInstance);
  c100_ak = c100_c_a;
  c100_d_a = c100_ak;
  c100_eml_scalar_eg(chartInstance);
  c100_e_a = c100_d_a;
  c100_b = c100_d_a;
  return c100_e_a * c100_b;
}

static void c100_eml_scalar_eg(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
}

static real_T c100_b_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a)
{
  real_T c100_b_a;
  real_T c100_c_a;
  real_T c100_ak;
  real_T c100_d_a;
  real_T c100_ar;
  c100_b_a = c100_a;
  c100_c_a = c100_b_a;
  c100_eml_scalar_eg(chartInstance);
  c100_ak = c100_c_a;
  c100_d_a = c100_ak;
  c100_eml_scalar_eg(chartInstance);
  c100_ar = c100_d_a;
  return muDoubleScalarPower(c100_ar, 4.0);
}

static real_T c100_c_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a)
{
  real_T c100_b_a;
  real_T c100_c_a;
  real_T c100_ak;
  real_T c100_d_a;
  real_T c100_ar;
  c100_b_a = c100_a;
  c100_c_a = c100_b_a;
  c100_eml_scalar_eg(chartInstance);
  c100_ak = c100_c_a;
  if (c100_ak < 0.0) {
    c100_eml_error(chartInstance);
  }

  c100_d_a = c100_ak;
  c100_eml_scalar_eg(chartInstance);
  c100_ar = c100_d_a;
  return muDoubleScalarPower(c100_ar, 1.5);
}

static void c100_eml_error(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c100_i1;
  static char_T c100_cv0[31] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'p', 'o', 'w', 'e', 'r', '_', 'd', 'o', 'm', 'a',
    'i', 'n', 'E', 'r', 'r', 'o', 'r' };

  char_T c100_u[31];
  const mxArray *c100_y = NULL;
  for (c100_i1 = 0; c100_i1 < 31; c100_i1++) {
    c100_u[c100_i1] = c100_cv0[c100_i1];
  }

  c100_y = NULL;
  sf_mex_assign(&c100_y, sf_mex_create("y", c100_u, 10, 0U, 1U, 0U, 2, 1, 31),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 1U, 14,
    c100_y));
}

static real_T c100_d_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a)
{
  real_T c100_b_a;
  real_T c100_c_a;
  real_T c100_ak;
  real_T c100_d_a;
  real_T c100_ar;
  c100_b_a = c100_a;
  c100_c_a = c100_b_a;
  c100_eml_scalar_eg(chartInstance);
  c100_ak = c100_c_a;
  if (c100_ak < 0.0) {
    c100_eml_error(chartInstance);
  }

  c100_d_a = c100_ak;
  c100_eml_scalar_eg(chartInstance);
  c100_ar = c100_d_a;
  return muDoubleScalarPower(c100_ar, 3.5);
}

static real_T c100_sign(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_x)
{
  real_T c100_b_x;
  c100_b_x = c100_x;
  c100_b_sign(chartInstance, &c100_b_x);
  return c100_b_x;
}

static real_T c100_e_mpower(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T c100_a)
{
  real_T c100_c;
  real_T c100_b_a;
  real_T c100_c_a;
  real_T c100_ak;
  real_T c100_d_a;
  real_T c100_x;
  c100_b_a = c100_a;
  c100_c_a = c100_b_a;
  c100_eml_scalar_eg(chartInstance);
  c100_ak = c100_c_a;
  if (c100_ak < 0.0) {
    c100_eml_error(chartInstance);
  }

  c100_d_a = c100_ak;
  c100_eml_scalar_eg(chartInstance);
  c100_x = c100_d_a;
  c100_c = c100_x;
  if (c100_c < 0.0) {
    c100_b_eml_error(chartInstance);
  }

  return muDoubleScalarSqrt(c100_c);
}

static void c100_b_eml_error(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance)
{
  int32_T c100_i2;
  static char_T c100_cv1[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i',
    'n', 'E', 'r', 'r', 'o', 'r' };

  char_T c100_u[30];
  const mxArray *c100_y = NULL;
  int32_T c100_i3;
  static char_T c100_cv2[4] = { 's', 'q', 'r', 't' };

  char_T c100_b_u[4];
  const mxArray *c100_b_y = NULL;
  for (c100_i2 = 0; c100_i2 < 30; c100_i2++) {
    c100_u[c100_i2] = c100_cv1[c100_i2];
  }

  c100_y = NULL;
  sf_mex_assign(&c100_y, sf_mex_create("y", c100_u, 10, 0U, 1U, 0U, 2, 1, 30),
                FALSE);
  for (c100_i3 = 0; c100_i3 < 4; c100_i3++) {
    c100_b_u[c100_i3] = c100_cv2[c100_i3];
  }

  c100_b_y = NULL;
  sf_mex_assign(&c100_b_y, sf_mex_create("y", c100_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                FALSE);
  sf_mex_call_debug("error", 0U, 1U, 14, sf_mex_call_debug("message", 1U, 2U, 14,
    c100_y, 14, c100_b_y));
}

static const mxArray *c100_b_sf_marshallOut(void *chartInstanceVoid, void
  *c100_inData)
{
  const mxArray *c100_mxArrayOutData = NULL;
  int32_T c100_u;
  const mxArray *c100_y = NULL;
  SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c100_mxArrayOutData = NULL;
  c100_u = *(int32_T *)c100_inData;
  c100_y = NULL;
  sf_mex_assign(&c100_y, sf_mex_create("y", &c100_u, 6, 0U, 0U, 0U, 0), FALSE);
  sf_mex_assign(&c100_mxArrayOutData, c100_y, FALSE);
  return c100_mxArrayOutData;
}

static int32_T c100_c_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId)
{
  int32_T c100_y;
  int32_T c100_i4;
  sf_mex_import(c100_parentId, sf_mex_dup(c100_u), &c100_i4, 1, 6, 0U, 0, 0U, 0);
  c100_y = c100_i4;
  sf_mex_destroy(&c100_u);
  return c100_y;
}

static void c100_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c100_mxArrayInData, const char_T *c100_varName, void *c100_outData)
{
  const mxArray *c100_b_sfEvent;
  const char_T *c100_identifier;
  emlrtMsgIdentifier c100_thisId;
  int32_T c100_y;
  SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)
    chartInstanceVoid;
  c100_b_sfEvent = sf_mex_dup(c100_mxArrayInData);
  c100_identifier = c100_varName;
  c100_thisId.fIdentifier = c100_identifier;
  c100_thisId.fParent = NULL;
  c100_y = c100_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c100_b_sfEvent),
    &c100_thisId);
  sf_mex_destroy(&c100_b_sfEvent);
  *(int32_T *)c100_outData = c100_y;
  sf_mex_destroy(&c100_mxArrayInData);
}

static uint8_T c100_d_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_b_is_active_c100_laneKeepingArcSplinesFF2013a, const char_T
   *c100_identifier)
{
  uint8_T c100_y;
  emlrtMsgIdentifier c100_thisId;
  c100_thisId.fIdentifier = c100_identifier;
  c100_thisId.fParent = NULL;
  c100_y = c100_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c100_b_is_active_c100_laneKeepingArcSplinesFF2013a), &c100_thisId);
  sf_mex_destroy(&c100_b_is_active_c100_laneKeepingArcSplinesFF2013a);
  return c100_y;
}

static uint8_T c100_e_emlrt_marshallIn
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance, const
   mxArray *c100_u, const emlrtMsgIdentifier *c100_parentId)
{
  uint8_T c100_y;
  uint8_T c100_u0;
  sf_mex_import(c100_parentId, sf_mex_dup(c100_u), &c100_u0, 1, 3, 0U, 0, 0U, 0);
  c100_y = c100_u0;
  sf_mex_destroy(&c100_u);
  return c100_y;
}

static void c100_b_sign(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct
  *chartInstance, real_T *c100_x)
{
  *c100_x = muDoubleScalarSign(*c100_x);
}

static void init_dsm_address_info
  (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c100_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2673191558U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4039794039U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4132069516U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(338304628U);
}

mxArray *sf_c100_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("gJWTKjM0iFb0wpnQLjrjqC");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,23,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,8,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,8,"type",mxType);
    }

    mxSetField(mxData,8,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,9,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,9,"type",mxType);
    }

    mxSetField(mxData,9,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,10,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,10,"type",mxType);
    }

    mxSetField(mxData,10,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,11,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,11,"type",mxType);
    }

    mxSetField(mxData,11,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,12,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,12,"type",mxType);
    }

    mxSetField(mxData,12,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,13,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,13,"type",mxType);
    }

    mxSetField(mxData,13,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,14,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,14,"type",mxType);
    }

    mxSetField(mxData,14,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,15,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,15,"type",mxType);
    }

    mxSetField(mxData,15,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,16,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,16,"type",mxType);
    }

    mxSetField(mxData,16,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,17,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,17,"type",mxType);
    }

    mxSetField(mxData,17,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,18,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,18,"type",mxType);
    }

    mxSetField(mxData,18,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,19,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,19,"type",mxType);
    }

    mxSetField(mxData,19,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,20,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,20,"type",mxType);
    }

    mxSetField(mxData,20,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,21,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,21,"type",mxType);
    }

    mxSetField(mxData,21,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,22,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,22,"type",mxType);
    }

    mxSetField(mxData,22,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c100_laneKeepingArcSplinesFF2013a_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

static const mxArray *sf_get_sim_state_info_c100_laneKeepingArcSplinesFF2013a
  (void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"T\",},{M[8],M[0],T\"is_active_c100_laneKeepingArcSplinesFF2013a\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c100_laneKeepingArcSplinesFF2013a_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
    chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _laneKeepingArcSplinesFF2013aMachineNumber_,
           100,
           1,
           1,
           24,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _laneKeepingArcSplinesFF2013aMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _laneKeepingArcSplinesFF2013aMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"r");
          _SFD_SET_DATA_PROPS(1,1,1,0,"Flf");
          _SFD_SET_DATA_PROPS(2,1,1,0,"Flf_dot");
          _SFD_SET_DATA_PROPS(3,1,1,0,"delta_dot");
          _SFD_SET_DATA_PROPS(4,1,1,0,"r_dot");
          _SFD_SET_DATA_PROPS(5,1,1,0,"dy");
          _SFD_SET_DATA_PROPS(6,1,1,0,"delta");
          _SFD_SET_DATA_PROPS(7,1,1,0,"alpha");
          _SFD_SET_DATA_PROPS(8,1,1,0,"dx");
          _SFD_SET_DATA_PROPS(9,1,1,0,"VOmegax");
          _SFD_SET_DATA_PROPS(10,1,1,0,"VOmega");
          _SFD_SET_DATA_PROPS(11,1,1,0,"IOmega");
          _SFD_SET_DATA_PROPS(12,1,1,0,"df_D_lambda");
          _SFD_SET_DATA_PROPS(13,1,1,0,"ddx");
          _SFD_SET_DATA_PROPS(14,1,1,0,"df_D_dalpha");
          _SFD_SET_DATA_PROPS(15,1,1,0,"ddy");
          _SFD_SET_DATA_PROPS(16,1,1,0,"VOmegay");
          _SFD_SET_DATA_PROPS(17,1,1,0,"mup");
          _SFD_SET_DATA_PROPS(18,1,1,0,"Fz0");
          _SFD_SET_DATA_PROPS(19,1,1,0,"VOmegaa");
          _SFD_SET_DATA_PROPS(20,1,1,0,"Omega");
          _SFD_SET_DATA_PROPS(21,1,1,0,"Fa");
          _SFD_SET_DATA_PROPS(22,1,1,0,"lambda");
          _SFD_SET_DATA_PROPS(23,2,0,1,"T");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,4,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,2514);
        _SFD_CV_INIT_EML_IF(0,1,0,2048,2062,-1,2100);
        _SFD_CV_INIT_EML_IF(0,1,1,2102,2115,-1,2153);
        _SFD_CV_INIT_EML_IF(0,1,2,2164,2178,-1,2215);
        _SFD_CV_INIT_EML_IF(0,1,3,2217,2230,-1,2267);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(18,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(19,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(20,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(21,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(22,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(23,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c100_sf_marshallOut,(MexInFcnForType)c100_sf_marshallIn);

        {
          real_T *c100_r;
          real_T *c100_Flf;
          real_T *c100_Flf_dot;
          real_T *c100_delta_dot;
          real_T *c100_r_dot;
          real_T *c100_dy;
          real_T *c100_delta;
          real_T *c100_alpha;
          real_T *c100_dx;
          real_T *c100_VOmegax;
          real_T *c100_VOmega;
          real_T *c100_IOmega;
          real_T *c100_df_D_lambda;
          real_T *c100_ddx;
          real_T *c100_df_D_dalpha;
          real_T *c100_ddy;
          real_T *c100_VOmegay;
          real_T *c100_mup;
          real_T *c100_Fz0;
          real_T *c100_VOmegaa;
          real_T *c100_Omega;
          real_T *c100_Fa;
          real_T *c100_lambda;
          real_T *c100_T;
          c100_T = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c100_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 22);
          c100_Fa = (real_T *)ssGetInputPortSignal(chartInstance->S, 21);
          c100_Omega = (real_T *)ssGetInputPortSignal(chartInstance->S, 20);
          c100_VOmegaa = (real_T *)ssGetInputPortSignal(chartInstance->S, 19);
          c100_Fz0 = (real_T *)ssGetInputPortSignal(chartInstance->S, 18);
          c100_mup = (real_T *)ssGetInputPortSignal(chartInstance->S, 17);
          c100_VOmegay = (real_T *)ssGetInputPortSignal(chartInstance->S, 16);
          c100_ddy = (real_T *)ssGetInputPortSignal(chartInstance->S, 15);
          c100_df_D_dalpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 14);
          c100_ddx = (real_T *)ssGetInputPortSignal(chartInstance->S, 13);
          c100_df_D_lambda = (real_T *)ssGetInputPortSignal(chartInstance->S, 12);
          c100_IOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 11);
          c100_VOmega = (real_T *)ssGetInputPortSignal(chartInstance->S, 10);
          c100_VOmegax = (real_T *)ssGetInputPortSignal(chartInstance->S, 9);
          c100_dx = (real_T *)ssGetInputPortSignal(chartInstance->S, 8);
          c100_alpha = (real_T *)ssGetInputPortSignal(chartInstance->S, 7);
          c100_delta = (real_T *)ssGetInputPortSignal(chartInstance->S, 6);
          c100_dy = (real_T *)ssGetInputPortSignal(chartInstance->S, 5);
          c100_r_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 4);
          c100_delta_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c100_Flf_dot = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c100_Flf = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c100_r = (real_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c100_r);
          _SFD_SET_DATA_VALUE_PTR(1U, c100_Flf);
          _SFD_SET_DATA_VALUE_PTR(2U, c100_Flf_dot);
          _SFD_SET_DATA_VALUE_PTR(3U, c100_delta_dot);
          _SFD_SET_DATA_VALUE_PTR(4U, c100_r_dot);
          _SFD_SET_DATA_VALUE_PTR(5U, c100_dy);
          _SFD_SET_DATA_VALUE_PTR(6U, c100_delta);
          _SFD_SET_DATA_VALUE_PTR(7U, c100_alpha);
          _SFD_SET_DATA_VALUE_PTR(8U, c100_dx);
          _SFD_SET_DATA_VALUE_PTR(9U, c100_VOmegax);
          _SFD_SET_DATA_VALUE_PTR(10U, c100_VOmega);
          _SFD_SET_DATA_VALUE_PTR(11U, c100_IOmega);
          _SFD_SET_DATA_VALUE_PTR(12U, c100_df_D_lambda);
          _SFD_SET_DATA_VALUE_PTR(13U, c100_ddx);
          _SFD_SET_DATA_VALUE_PTR(14U, c100_df_D_dalpha);
          _SFD_SET_DATA_VALUE_PTR(15U, c100_ddy);
          _SFD_SET_DATA_VALUE_PTR(16U, c100_VOmegay);
          _SFD_SET_DATA_VALUE_PTR(17U, c100_mup);
          _SFD_SET_DATA_VALUE_PTR(18U, c100_Fz0);
          _SFD_SET_DATA_VALUE_PTR(19U, c100_VOmegaa);
          _SFD_SET_DATA_VALUE_PTR(20U, c100_Omega);
          _SFD_SET_DATA_VALUE_PTR(21U, c100_Fa);
          _SFD_SET_DATA_VALUE_PTR(22U, c100_lambda);
          _SFD_SET_DATA_VALUE_PTR(23U, c100_T);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _laneKeepingArcSplinesFF2013aMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "r7v1MFHkteIICz8lJkTkoC";
}

static void sf_opaque_initialize_c100_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  chart_debug_initialization(((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
  initialize_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c100_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  enable_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c100_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  disable_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c100_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  sf_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern const mxArray*
  sf_internal_get_sim_state_c100_laneKeepingArcSplinesFF2013a(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*)
     chartInfo->chartInstance);        /* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c100_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SimStruct* S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c100_laneKeepingArcSplinesFF2013a();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*)
     chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c100_laneKeepingArcSplinesFF2013a
  (SimStruct* S)
{
  return sf_internal_get_sim_state_c100_laneKeepingArcSplinesFF2013a(S);
}

static void sf_opaque_set_sim_state_c100_laneKeepingArcSplinesFF2013a(SimStruct*
  S, const mxArray *st)
{
  sf_internal_set_sim_state_c100_laneKeepingArcSplinesFF2013a(S, st);
}

static void sf_opaque_terminate_c100_laneKeepingArcSplinesFF2013a(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_laneKeepingArcSplinesFF2013a_optimization_info();
    }

    finalize_c100_laneKeepingArcSplinesFF2013a
      ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
    utFree((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc100_laneKeepingArcSplinesFF2013a
    ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c100_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c100_laneKeepingArcSplinesFF2013a
      ((SFc100_laneKeepingArcSplinesFF2013aInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c100_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_laneKeepingArcSplinesFF2013a_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,sf_get_instance_specialization(),infoStruct,
      100);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,sf_get_instance_specialization(),
                infoStruct,100,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,
      sf_get_instance_specialization(),infoStruct,100,
      "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(S,sf_get_instance_specialization(),infoStruct,100);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 7, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 8, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 9, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 10, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 11, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 12, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 13, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 14, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 15, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 16, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 17, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 18, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 19, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 20, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 21, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 22, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,100,23);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,100,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 23; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,100);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(4043927683U));
  ssSetChecksum1(S,(3344300765U));
  ssSetChecksum2(S,(3439005895U));
  ssSetChecksum3(S,(3619973032U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c100_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c100_laneKeepingArcSplinesFF2013a(SimStruct *S)
{
  SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *chartInstance;
  chartInstance = (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct *)utMalloc
    (sizeof(SFc100_laneKeepingArcSplinesFF2013aInstanceStruct));
  memset(chartInstance, 0, sizeof
         (SFc100_laneKeepingArcSplinesFF2013aInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlStart = mdlStart_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c100_laneKeepingArcSplinesFF2013a;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c100_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c100_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c100_laneKeepingArcSplinesFF2013a(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c100_laneKeepingArcSplinesFF2013a(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c100_laneKeepingArcSplinesFF2013a_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
