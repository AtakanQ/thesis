/* Include files */

#include "laneKeepingArcSplinesFF2013a_sfun.h"
#include "laneKeepingArcSplinesFF2013a_sfun_debug_macros.h"
#include "c1_laneKeepingArcSplinesFF2013a.h"
#include "c2_laneKeepingArcSplinesFF2013a.h"
#include "c3_laneKeepingArcSplinesFF2013a.h"
#include "c4_laneKeepingArcSplinesFF2013a.h"
#include "c5_laneKeepingArcSplinesFF2013a.h"
#include "c6_laneKeepingArcSplinesFF2013a.h"
#include "c7_laneKeepingArcSplinesFF2013a.h"
#include "c8_laneKeepingArcSplinesFF2013a.h"
#include "c9_laneKeepingArcSplinesFF2013a.h"
#include "c98_laneKeepingArcSplinesFF2013a.h"
#include "c99_laneKeepingArcSplinesFF2013a.h"
#include "c100_laneKeepingArcSplinesFF2013a.h"
#include "c101_laneKeepingArcSplinesFF2013a.h"
#include "c102_laneKeepingArcSplinesFF2013a.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
uint32_T _laneKeepingArcSplinesFF2013aMachineNumber_;
real_T _sfTime_;

/* Function Declarations */

/* Function Definitions */
void laneKeepingArcSplinesFF2013a_initializer(void)
{
}

void laneKeepingArcSplinesFF2013a_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_laneKeepingArcSplinesFF2013a_method_dispatcher(SimStruct
  *simstructPtr, unsigned int chartFileNumber, const char* specsCksum, int_T
  method, void *data)
{
  if (chartFileNumber==1) {
    c1_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==2) {
    c2_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==3) {
    c3_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==4) {
    c4_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==5) {
    c5_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==6) {
    c6_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==7) {
    c7_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==8) {
    c8_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==9) {
    c9_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==98) {
    c98_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method,
      data);
    return 1;
  }

  if (chartFileNumber==99) {
    c99_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method,
      data);
    return 1;
  }

  if (chartFileNumber==100) {
    c100_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method,
      data);
    return 1;
  }

  if (chartFileNumber==101) {
    c101_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method,
      data);
    return 1;
  }

  if (chartFileNumber==102) {
    c102_laneKeepingArcSplinesFF2013a_method_dispatcher(simstructPtr, method,
      data);
    return 1;
  }

  return 0;
}

unsigned int sf_laneKeepingArcSplinesFF2013a_process_check_sum_call( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>1 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"machine")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2748362305U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(699282516U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(813098936U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3667565889U);
    } else if (!strcmp(commandName,"exportedFcn")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0U);
    } else if (!strcmp(commandName,"makefile")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3010391962U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2031079222U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(60071666U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3449168816U);
    } else if (nrhs==3 && !strcmp(commandName,"chart")) {
      unsigned int chartFileNumber;
      chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
      switch (chartFileNumber) {
       case 1:
        {
          extern void sf_c1_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c1_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 2:
        {
          extern void sf_c2_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c2_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 3:
        {
          extern void sf_c3_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c3_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 4:
        {
          extern void sf_c4_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c4_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 5:
        {
          extern void sf_c5_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c5_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 6:
        {
          extern void sf_c6_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c6_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 7:
        {
          extern void sf_c7_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c7_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 8:
        {
          extern void sf_c8_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c8_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 9:
        {
          extern void sf_c9_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c9_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 98:
        {
          extern void sf_c98_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *
            plhs[]);
          sf_c98_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 99:
        {
          extern void sf_c99_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray *
            plhs[]);
          sf_c99_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 100:
        {
          extern void sf_c100_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c100_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 101:
        {
          extern void sf_c101_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c101_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       case 102:
        {
          extern void sf_c102_laneKeepingArcSplinesFF2013a_get_check_sum(mxArray
            *plhs[]);
          sf_c102_laneKeepingArcSplinesFF2013a_get_check_sum(plhs);
          break;
        }

       default:
        ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
      }
    } else if (!strcmp(commandName,"target")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3564696471U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(678668628U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1090454852U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3896867807U);
    } else {
      return 0;
    }
  } else {
    ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3124618769U);
    ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1323114396U);
    ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(566196705U);
    ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3233605266U);
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_laneKeepingArcSplinesFF2013a_autoinheritance_info( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  char aiChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the autoinheritance_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_autoinheritance_info"))
    return 0;
  mxGetString(prhs[2], aiChksum,sizeof(aiChksum)/sizeof(char));
  aiChksum[(sizeof(aiChksum)/sizeof(char)-1)] = '\0';

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(aiChksum, "UmF9Xv5FbVsWd2zOJWXTfF") == 0) {
          extern mxArray
            *sf_c1_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c1_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 2:
      {
        if (strcmp(aiChksum, "a6vRrWeFIZYqfDsPNnzaq") == 0) {
          extern mxArray
            *sf_c2_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c2_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 3:
      {
        if (strcmp(aiChksum, "dTaei0OrSIp1jneDOt2kbB") == 0) {
          extern mxArray
            *sf_c3_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c3_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 4:
      {
        if (strcmp(aiChksum, "5tI2S76Rp0FP2EenFdo4KD") == 0) {
          extern mxArray
            *sf_c4_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c4_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 5:
      {
        if (strcmp(aiChksum, "q8xE5MPdWaoHMO4PZkYTHF") == 0) {
          extern mxArray
            *sf_c5_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c5_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 6:
      {
        if (strcmp(aiChksum, "EMKZmu8BdsMJ4KkdQbTSQE") == 0) {
          extern mxArray
            *sf_c6_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c6_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 7:
      {
        if (strcmp(aiChksum, "gJWTKjM0iFb0wpnQLjrjqC") == 0) {
          extern mxArray
            *sf_c7_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c7_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 8:
      {
        if (strcmp(aiChksum, "1J8QTRsEEQEZW6IIQi404C") == 0) {
          extern mxArray
            *sf_c8_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c8_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 9:
      {
        if (strcmp(aiChksum, "DBqHpvZMwRuIrZhU6xaJm") == 0) {
          extern mxArray
            *sf_c9_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c9_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 98:
      {
        if (strcmp(aiChksum, "q8xE5MPdWaoHMO4PZkYTHF") == 0) {
          extern mxArray
            *sf_c98_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c98_laneKeepingArcSplinesFF2013a_get_autoinheritance_info
            ();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 99:
      {
        if (strcmp(aiChksum, "EMKZmu8BdsMJ4KkdQbTSQE") == 0) {
          extern mxArray
            *sf_c99_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] = sf_c99_laneKeepingArcSplinesFF2013a_get_autoinheritance_info
            ();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 100:
      {
        if (strcmp(aiChksum, "gJWTKjM0iFb0wpnQLjrjqC") == 0) {
          extern mxArray
            *sf_c100_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] =
            sf_c100_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 101:
      {
        if (strcmp(aiChksum, "1J8QTRsEEQEZW6IIQi404C") == 0) {
          extern mxArray
            *sf_c101_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] =
            sf_c101_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     case 102:
      {
        if (strcmp(aiChksum, "DBqHpvZMwRuIrZhU6xaJm") == 0) {
          extern mxArray
            *sf_c102_laneKeepingArcSplinesFF2013a_get_autoinheritance_info(void);
          plhs[0] =
            sf_c102_laneKeepingArcSplinesFF2013a_get_autoinheritance_info();
          break;
        }

        plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
  ( int nlhs, mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  if (nrhs<2 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        extern const mxArray
          *sf_c1_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c1_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 2:
      {
        extern const mxArray
          *sf_c2_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c2_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 3:
      {
        extern const mxArray
          *sf_c3_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c3_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 4:
      {
        extern const mxArray
          *sf_c4_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c4_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 5:
      {
        extern const mxArray
          *sf_c5_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c5_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 6:
      {
        extern const mxArray
          *sf_c6_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c6_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 7:
      {
        extern const mxArray
          *sf_c7_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c7_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 8:
      {
        extern const mxArray
          *sf_c8_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c8_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 9:
      {
        extern const mxArray
          *sf_c9_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c9_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 98:
      {
        extern const mxArray
          *sf_c98_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c98_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 99:
      {
        extern const mxArray
          *sf_c99_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c99_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 100:
      {
        extern const mxArray
          *sf_c100_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c100_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 101:
      {
        extern const mxArray
          *sf_c101_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c101_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 102:
      {
        extern const mxArray
          *sf_c102_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info
          (void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c102_laneKeepingArcSplinesFF2013a_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_laneKeepingArcSplinesFF2013a_third_party_uses_info( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{
  char commandName[64];
  char tpChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the third_party_uses_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  mxGetString(prhs[2], tpChksum,sizeof(tpChksum)/sizeof(char));
  tpChksum[(sizeof(tpChksum)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_third_party_uses_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(tpChksum, "Nrslcr9SmjgbCMabeFSogF") == 0) {
          extern mxArray
            *sf_c1_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c1_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 2:
      {
        if (strcmp(tpChksum, "UxZTR14kCa94lMRHI97mxF") == 0) {
          extern mxArray
            *sf_c2_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c2_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 3:
      {
        if (strcmp(tpChksum, "tgC2FZ6yoLgqShxLr5FcrC") == 0) {
          extern mxArray
            *sf_c3_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c3_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 4:
      {
        if (strcmp(tpChksum, "3zmJNd7LYqZn8w3t5nDpBD") == 0) {
          extern mxArray
            *sf_c4_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c4_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 5:
      {
        if (strcmp(tpChksum, "ZUYIpguPfIcuSu5GSxkMw") == 0) {
          extern mxArray
            *sf_c5_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c5_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 6:
      {
        if (strcmp(tpChksum, "V2rLoMQ482onA7CrYJ7fP") == 0) {
          extern mxArray
            *sf_c6_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c6_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 7:
      {
        if (strcmp(tpChksum, "r7v1MFHkteIICz8lJkTkoC") == 0) {
          extern mxArray
            *sf_c7_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c7_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 8:
      {
        if (strcmp(tpChksum, "435wZtGPT8JZRGR0Yva3OF") == 0) {
          extern mxArray
            *sf_c8_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c8_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 9:
      {
        if (strcmp(tpChksum, "e6NgW7j7XGCpT1t0UPeSM") == 0) {
          extern mxArray
            *sf_c9_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c9_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 98:
      {
        if (strcmp(tpChksum, "ZUYIpguPfIcuSu5GSxkMw") == 0) {
          extern mxArray
            *sf_c98_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c98_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 99:
      {
        if (strcmp(tpChksum, "V2rLoMQ482onA7CrYJ7fP") == 0) {
          extern mxArray
            *sf_c99_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c99_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 100:
      {
        if (strcmp(tpChksum, "r7v1MFHkteIICz8lJkTkoC") == 0) {
          extern mxArray
            *sf_c100_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c100_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 101:
      {
        if (strcmp(tpChksum, "435wZtGPT8JZRGR0Yva3OF") == 0) {
          extern mxArray
            *sf_c101_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c101_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     case 102:
      {
        if (strcmp(tpChksum, "e6NgW7j7XGCpT1t0UPeSM") == 0) {
          extern mxArray
            *sf_c102_laneKeepingArcSplinesFF2013a_third_party_uses_info(void);
          plhs[0] = sf_c102_laneKeepingArcSplinesFF2013a_third_party_uses_info();
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;
}

void laneKeepingArcSplinesFF2013a_debug_initialize(struct SfDebugInstanceStruct*
  debugInstance)
{
  _laneKeepingArcSplinesFF2013aMachineNumber_ = sf_debug_initialize_machine
    (debugInstance,"laneKeepingArcSplinesFF2013a","sfun",0,14,0,0,0);
  sf_debug_set_machine_event_thresholds(debugInstance,
    _laneKeepingArcSplinesFF2013aMachineNumber_,0,0);
  sf_debug_set_machine_data_thresholds(debugInstance,
    _laneKeepingArcSplinesFF2013aMachineNumber_,0);
}

void laneKeepingArcSplinesFF2013a_register_exported_symbols(SimStruct* S)
{
}

static mxArray* sRtwOptimizationInfoStruct= NULL;
mxArray* load_laneKeepingArcSplinesFF2013a_optimization_info(void)
{
  if (sRtwOptimizationInfoStruct==NULL) {
    sRtwOptimizationInfoStruct = sf_load_rtw_optimization_info(
      "laneKeepingArcSplinesFF2013a", "laneKeepingArcSplinesFF2013a");
    mexMakeArrayPersistent(sRtwOptimizationInfoStruct);
  }

  return(sRtwOptimizationInfoStruct);
}

void unload_laneKeepingArcSplinesFF2013a_optimization_info(void)
{
  if (sRtwOptimizationInfoStruct!=NULL) {
    mxDestroyArray(sRtwOptimizationInfoStruct);
    sRtwOptimizationInfoStruct = NULL;
  }
}
