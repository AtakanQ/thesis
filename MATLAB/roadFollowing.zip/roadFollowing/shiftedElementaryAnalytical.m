
% Approximation
Dintegrand =  @(x,alphaSym,betaSym) cos(2*alphaSym*(x.^2-1/4)+betaSym*(x-.5) );
alphaVec = [0:.05:pi/4 pi/4];
betaVec = [0:.05:pi/2 pi/2];

DalphaVec = [];
DalphaMat = [];
alphabetaVec = [];

for jj = 1:length(alphaVec)
    for kk = 1:length(betaVec)
        alphaSym = alphaVec(jj);
        betaSym = betaVec(kk);
        DalphaMat(jj,kk) = 2*integral(@(x)Dintegrand(x,alphaSym,betaSym),0,.5);
        alphabetaVec = [alphabetaVec; [alphaSym betaSym] ];
        DalphaVec = [DalphaVec; DalphaMat(jj,kk)];
    end
end

f = fit( alphabetaVec, DalphaVec, 'poly33' );
syms alpha beta;

Dalphabeta_poly = f.p00 + f.p10*alpha + f.p01*beta + f.p20*alpha.^2 + f.p11*alpha.*beta + f.p02*beta.^2 ...
    + f.p30*alpha.^3 + f.p21*alpha.^2.*beta + f.p12*alpha.*beta.^2 + f.p03*beta.^3;

% computation

syms S lambda alpha1 k1 tau ; 

S = 2*alpha1/lambda/k1;
beta1 = 2*tau*alpha1/k1;
alpha2 = -alpha1;
beta2 = (1-lambda)*tau*2*alpha1/lambda/k1;
thetaS = alpha1+beta1;

Dalphabeta1 = simplify(subs(Dalphabeta_poly,[alpha beta], [alpha1 beta1]) );
Dalphabeta2 = simplify(subs(Dalphabeta_poly,[alpha beta],[alpha2 beta2]) );

deltaY = lambda*S*Dalphabeta1*sin((alpha1+beta1)/2) + ...
    (1-lambda)*S*Dalphabeta2*sin((thetaS+(alpha2+beta2)/2));

tauVal = 1/200;
k1Val = 0.005;
lambdaVal = .3;
deltaYsubs = simplify(subs(deltaY,[tau k1 lambda],[tauVal k1Val lambdaVal]) );
alpha1Val = vpasolve(deltaYsubs - subs(1/tauVal*(1-cos(S*tauVal) ),[lambda k1],[lambdaVal k1Val] ) ...
    == 3.7,alpha1,[0;pi/18]);
%*subs(cos(S*tauVal),[lambda k1],[lambdaVal k1Val] )
% ============================================
% Road plot
% ============================================
% Example Road and first part of lane change
R = 1/tauVal;
Sval = double(subs(S,[alpha1 k1 lambda],[alpha1Val k1Val lambdaVal]) );
angleRange = [0:.01:5*Sval/R 5*Sval/R];
plot(R*sin(angleRange),R*(1-cos(angleRange)))
hold all; 
grid;


% First shifted elementary path
tauVal = 1/R;
S1val = lambdaVal*Sval;
beta1Val = tauVal*S1val;
sigmaVal = 2*k1Val/S1val;
% alpha1Val = sigmaVal*S1val^2/4;

sinPsi1mu = @(x,sigmaSym,tauSym) sin((sigmaSym*x.^2)/2 + tauSym*x); 
sinPsi2mu = @(x,sigmaSym,tauSym) sin(x*tauSym - (S1val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S1val*x*sigmaSym);

cosPsi1mu = @(x,sigmaSym,tauSym) cos((sigmaSym*x.^2)/2 + tauSym*x); 
cosPsi2mu = @(x,sigmaSym,tauSym) cos(x*tauSym - (S1val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S1val*x*sigmaSym);

sVec = 0:.05:S1val;
XVec = [];
YVec = [];
for jj = 1:length(sVec)
   if sVec(jj) <= S1val/2
        YVec(jj) = integral(@(x)sinPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        XVec(jj) = integral(@(x)cosPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        Y1end = YVec(jj);
        X1end = XVec(jj);
   else
       YVec(jj) = Y1end + integral(@(x)sinPsi2mu(x,sigmaVal,tauVal),S1val/2,sVec(jj));
       XVec(jj) = X1end + integral(@(x)cosPsi2mu(x,sigmaVal,tauVal),S1val/2,sVec(jj));
   end
end

plot(XVec,YVec)
Xend = XVec(end);
Yend = YVec(end);
plot([0 Xend],[0 Yend])
thetaSval = double(alpha1Val+beta1Val);

DalphabetaVal = double(subs(Dalphabeta_poly,[alpha beta],[alpha1Val beta1Val]) );
Deltay1 = S1val*DalphabetaVal*sin(alpha1Val/2+beta1Val/2);
Deltax1 = S1val*DalphabetaVal*cos(alpha1Val/2+beta1Val/2);

% Second shifted elementary path
tauVal = 1/R;
S2val = (1-lambdaVal)*Sval;
beta2Val = tauVal*S2val;
k2Val = -lambdaVal*k1Val/(1-lambdaVal);
sigmaVal = 2*k2Val/S2val;
alpha2Val = -double(alpha1Val);

sinPsi1mu = @(x,sigmaSym,tauSym) sin((sigmaSym*x.^2)/2 + tauSym*x+thetaSval); 
sinPsi2mu = @(x,sigmaSym,tauSym) sin(x*tauSym - (S2val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S2val*x*sigmaSym+thetaSval);

cosPsi1mu = @(x,sigmaSym,tauSym) cos((sigmaSym*x.^2)/2 + tauSym*x+thetaSval); 
cosPsi2mu = @(x,sigmaSym,tauSym) cos(x*tauSym - (S2val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S2val*x*sigmaSym+thetaSval);

sVec = 0:.05:S2val;
XVec = [];
YVec = [];
for jj = 1:length(sVec)
   if sVec(jj) <= S2val/2
        YVec(jj) = integral(@(x)sinPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        XVec(jj) = integral(@(x)cosPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        Y1end = YVec(jj);
        X1end = XVec(jj);
   else
       YVec(jj) = Y1end + integral(@(x)sinPsi2mu(x,sigmaVal,tauVal),S2val/2,sVec(jj));
       XVec(jj) = X1end + integral(@(x)cosPsi2mu(x,sigmaVal,tauVal),S2val/2,sVec(jj));
   end
end

plot(Xend+XVec,Yend+YVec)
plot([Xend XVec(end)+Xend],[Yend YVec(end)+Yend])
DalphabetaVal = double(subs(Dalphabeta_poly,[alpha beta],[alpha2Val beta2Val]) );
Deltay2 = S2val*DalphabetaVal*sin(alpha2Val/2+beta2Val/2+thetaSval);
Deltax2 = S2val*DalphabetaVal*cos(alpha2Val/2+beta2Val/2+thetaSval);

Deltay = Deltay1 + Deltay2
Deltax = Deltax1 + Deltax2

Rin = R-3.7;
CR = [0;R];
Pend = [Xend+XVec(end);Yend+YVec(end)]
scatter(Pend(1),Pend(2));
v = Pend-CR;
thetaf = acos((v'*-CR)/norm(v)/norm(CR));
angleIn = [thetaf:.01:5*Sval/R 5*Sval/R];
plot(Rin*sin(angleIn),R-Rin*cos(angleIn))
plot([0 R*sin(angleIn(1))],[200 R-R*cos(angleIn(1))])

