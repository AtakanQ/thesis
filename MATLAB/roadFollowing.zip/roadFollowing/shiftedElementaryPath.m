syms p k1 S ks z mu sigma tau

Psi1 = int(sigma*p+tau,p);
Psi1_f = subs(Psi1,p,S/2);
Psi2 = Psi1_f + int(sigma*(S-z)+tau,z,S/2,p);
Psi2_f = subs(Psi2,p,S);

Sval = 100; 
k1 = .001;
sigmaSym = k1*2/Sval;
tauSym = 0.00;


sinPsi1mu = @(x,sigmaSym,tauSym,alphaSym,thetaSSym) sin((sigmaSym*x.^2)/2 + tauSym*x-alphaSym/2+thetaSSym); 
sinPsi2mu = @(x,sigmaSym,tauSym,alphaSym,thetaSSym) sin(x*tauSym - (Sval^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + Sval*x*sigmaSym - alphaSym/2+thetaSSym);


cosPsi1mu = @(x,sigmaSym,tauSym,alphaSym,thetaSSym) cos((sigmaSym*x.^2)/2 + tauSym*x -alphaSym/2+thetaSSym); 
cosPsi2mu = @(x,sigmaSym,tauSym,alphaSym,thetaSSym) cos(x*tauSym - (Sval^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + Sval*x*sigmaSym - alphaSym/2+thetaSSym);

sigmaSym = k1*2/Sval;
tauSym = 0.0;
alphaSym = double(subs(Psi2_f,[tau sigma S],[tauSym k1*2/Sval Sval]));
thetaSSym = .02;


Y1 = integral(@(x)sinPsi1mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),0,Sval/2);
Y2 = integral(@(x)sinPsi2mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),Sval/2,Sval);

X1 = integral(@(x)cosPsi1mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),0,Sval/2);
X2 = integral(@(x)cosPsi2mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),Sval/2,Sval);

sVec = 0:.1:Sval;
for jj = 1:length(sVec)
   if sVec(jj) <= Sval/2
        YVec(jj) = integral(@(x)sinPsi1mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),0,sVec(jj));
        XVec(jj) = integral(@(x)cosPsi1mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),0,sVec(jj));
        Y1end = YVec(jj);
        X1end = XVec(jj);
   else
       YVec(jj) = Y1end + integral(@(x)sinPsi2mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),Sval/2,sVec(jj));
       XVec(jj) = X1end + integral(@(x)cosPsi2mu(x,sigmaSym,tauSym,alphaSym,thetaSSym),Sval/2,sVec(jj));
   end
end

alphaSym = 0;
Rot = [cos(-alphaSym/2-thetaSSym) -sin(-alphaSym/2-thetaSSym) ; sin(-alphaSym/2-thetaSSym) cos(-alphaSym/2-thetaSSym)];

for jj = 1:length(sVec)
   XVecRot(jj) = Rot(1,:)*[XVec(jj); YVec(jj)];
   YVecRot(jj) = Rot(2,:)*[XVec(jj); YVec(jj)]; 
end

Dintegrand =  @(x,alphaSym,betaSym) cos(2*alphaSym*(x.^2-1/4)+betaSym*(x-.5) );
alphaVec = [0:.01:pi/4 pi/4];
betaVec = [0:.01:pi/2 pi/2];

DalphaVec = [];
DalphaMat = [];
alphabetaVec = [];

for jj = 1:length(alphaVec)
    for kk = 1:length(betaVec)
        alphaSym = alphaVec(jj);
        betaSym = betaVec(kk);
        DalphaMat(jj,kk) = 2*integral(@(x)Dintegrand(x,alphaSym,betaSym),0,.5);
        alphabetaVec = [alphabetaVec; [alphaSym betaSym] ];
        DalphaVec = [DalphaVec; DalphaMat(jj,kk)];
    end
end

f = fit( alphabetaVec, DalphaVec, 'poly33' );
syms alpha beta;

Dalphabeta_poly = f.p00 + f.p10*alpha + f.p01*beta + f.p20*alpha.^2 + f.p11*alpha.*beta + f.p02*beta.^2 ...
    + f.p30*alpha.^3 + f.p21*alpha.^2.*beta + f.p12*alpha.*beta.^2 + f.p03*beta.^3;

tauSym = 0;
Dalpha_poly = subs(Dalphabeta_poly,beta,tauSym*Sval);
plot(alphaVec,double(subs(Dalpha_poly,alpha,alphaVec) ) )
hold all;


syms alphaSym z;

Dintegrand =  @(x,alphaSym) cos(2*alphaSym*(-x.^2+x) );
alphaVec = 0:.01:pi/4;
DalphaVec = [];
DalphaSinVec = [];
for jj = 1:length(alphaVec)
    alphaSym = alphaVec(jj);
    DalphaVec(jj) = 2*integral(@(x)Dintegrand(x,alphaSym),0,.5);
    DalphaSinVec(jj) = DalphaVec(jj)*sin(alphaSym/2);
end
P = polyfit(alphaVec,DalphaVec,3);
DalphaPoly = @(alph)(P(4) + P(3)*alph + P(2)*alph.^2 + P(1)*alph.^3);
diffDalphaPoly = @(alph)(P(3)+2*P(2)*alph+3*P(1)*alph.^2);
plot(alphaVec,DalphaPoly(alphaVec) )

% P = polyfit(alphaVec,DalphaVec,3);
% DalphaPoly = @(alph)(P(4) + P(3)*alph + P(2)*alph.^2 + P(1)*alph.^3);
% diffDalphaPoly = @(alph)(P(3)+2*P(2)*alph+3*P(1)*alph.^2);

% Example Road and first part of lane change
R = 200;
C = [0;200];
Sval = 100;
lambda = .6;
angleRange = [0:.01:Sval/R];
plot(R*sin(angleRange),R*(1-cos(angleRange)))
hold all; 
grid;


% First shifted elementary path
tauVal = 1/R;
S1val = lambda*Sval;
beta1Val = tauVal*S1val;
k1 = .001;
sigmaVal = 2*k1/S1val;
alpha1Val = sigmaVal*S1val^2/4;

sinPsi1mu = @(x,sigmaSym,tauSym) sin((sigmaSym*x.^2)/2 + tauSym*x); 
sinPsi2mu = @(x,sigmaSym,tauSym) sin(x*tauSym - (S1val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S1val*x*sigmaSym);

cosPsi1mu = @(x,sigmaSym,tauSym) cos((sigmaSym*x.^2)/2 + tauSym*x); 
cosPsi2mu = @(x,sigmaSym,tauSym) cos(x*tauSym - (S1val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S1val*x*sigmaSym);

sVec = 0:.1:S1val;
XVec = [];
YVec = [];
for jj = 1:length(sVec)
   if sVec(jj) <= S1val/2
        YVec(jj) = integral(@(x)sinPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        XVec(jj) = integral(@(x)cosPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        Y1end = YVec(jj);
        X1end = XVec(jj);
   else
       YVec(jj) = Y1end + integral(@(x)sinPsi2mu(x,sigmaVal,tauVal),S1val/2,sVec(jj));
       XVec(jj) = X1end + integral(@(x)cosPsi2mu(x,sigmaVal,tauVal),S1val/2,sVec(jj));
   end
end

plot(XVec,YVec)
Xend = XVec(end);
Yend = YVec(end);
plot([0 Xend],[0 Yend])
thetaSval = alpha1Val+beta1Val;

DalphabetaVal = double(subs(Dalphabeta_poly,[alpha beta],[alpha1Val beta1Val]) );
Deltay1 = S1val*DalphabetaVal*sin(alpha1Val/2+beta1Val/2);

% Second shifted elementary path
tauVal = 1/R;
S2val = (1-lambda)*Sval;
beta2Val = tauVal*S2val;
k2 = -lambda*k1/(1-lambda);
sigmaVal = 2*k2/S2val;
alpha2Val = sigmaVal*S2val^2/4;

sinPsi1mu = @(x,sigmaSym,tauSym) sin((sigmaSym*x.^2)/2 + tauSym*x+thetaSval); 
sinPsi2mu = @(x,sigmaSym,tauSym) sin(x*tauSym - (S2val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S2val*x*sigmaSym+thetaSval);

cosPsi1mu = @(x,sigmaSym,tauSym) cos((sigmaSym*x.^2)/2 + tauSym*x+thetaSval); 
cosPsi2mu = @(x,sigmaSym,tauSym) cos(x*tauSym - (S2val^2*sigmaSym)/4 - (x.^2*sigmaSym)/2 + S2val*x*sigmaSym+thetaSval);

sVec = 0:.1:S2val;
XVec = [];
YVec = [];
for jj = 1:length(sVec)
   if sVec(jj) <= S2val/2
        YVec(jj) = integral(@(x)sinPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        XVec(jj) = integral(@(x)cosPsi1mu(x,sigmaVal,tauVal),0,sVec(jj));
        Y1end = YVec(jj);
        X1end = XVec(jj);
   else
       YVec(jj) = Y1end + integral(@(x)sinPsi2mu(x,sigmaVal,tauVal),S2val/2,sVec(jj));
       XVec(jj) = X1end + integral(@(x)cosPsi2mu(x,sigmaVal,tauVal),S2val/2,sVec(jj));
   end
end

plot(Xend+XVec,Yend+YVec)
plot([Xend XVec(end)+Xend],[Yend YVec(end)+Yend])
DalphabetaVal = double(subs(Dalphabeta_poly,[alpha beta],[alpha2Val beta2Val]) );
Deltay2 = S2val*DalphabetaVal*sin(alpha2Val/2+beta2Val/2+thetaSval);

Deltay = Deltay1 + Deltay2